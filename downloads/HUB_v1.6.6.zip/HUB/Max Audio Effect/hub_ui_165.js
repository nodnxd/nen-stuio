// HUB — UI (v8ui) v1.6 (Live 테마 따라가기 + 세트 미리보기). jsarguments: "compact" (디바이스 뷰: OPEN 버튼) | "window" (플로팅 창: 큰 Recent / Templates 리스트)
// 리스트는 hub_engine.js가 에이블톤 파일에서 읽어 보내고, 클릭은 다시 엔진으로 간다.
//   window  : outlet 0 → thispatcher(창 플래그), outlet 1 → 엔진 명령
//   compact : outlet 0 → 엔진 명령
// 입력 메시지: recent / templates / meta / root / status / setfilter(검색창) / openurl(포털 링크) / showwin
autowatch = 1; inlets = 1; outlets = 2;
mgraphics.init(); mgraphics.relative_coords = 0; mgraphics.autofill = 0;
var g = mgraphics;
var MODE = (jsarguments.length > 1) ? String(jsarguments[1]) : "compact";
var WIN = (MODE === "window");
var PAT = this.patcher;
var SELF_BOX = this.box;     // 로드 시점에 잡아둠 (Task 콜백 안에선 this가 달라짐)

// ---------- theme: 오른쪽 NEN 패널과 같은 색, 라이트/다크 ----------
function hx(h, a) { return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255, a === undefined ? 1 : a]; }
var PALS = {
    dark:  { bg: hx("0e0e0e"), panel: hx("171716"), well: hx("121211"), line: hx("2a2a28"), dim: hx("8d8b85"), txt: hx("ecebe7"), hi: hx("f4a62a"), on: hx("f4a62a"), black: hx("0e0e0e") },
    light: { bg: hx("ecebe7"), panel: hx("e1e0db"), well: hx("f6f5f2"), line: hx("cfcdc6"), dim: hx("6b6a65"), txt: hx("0e0e0e"), hi: hx("b86f00"), on: hx("f4a62a"), black: hx("0e0e0e") }
};
var NEN = PALS.dark, THEME = "dark";
var C = {}; for (var k0 in NEN) C[k0] = NEN[k0].slice(0);
var BRAND = hx("f4a62a");   // 로고는 항상 NEN 노랑
function lum(c) { return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, 1]; }
function livecolor() {}          // 예전 패치(live.colors)에서 오는 메시지는 무시 — 이제 HUB 자체 테마
function theme(m) {               // 엔진이 보냄: "theme light|dark"
    m = String(m) === "light" ? "light" : "dark";
    var changed = m !== THEME; THEME = m; NEN = PALS[m];
    for (var k in NEN) C[k] = NEN[k].slice(0);
    styleFilter();
    if (changed) reloadPanels();
    mgraphics.redraw();
}
function toggleTheme() { cmd("theme", THEME === "dark" ? "light" : "dark"); }
function styleFilter() {     // 창의 검색칸(textedit)도 같은 색으로
    if (!WIN) return;
    try { var o = PAT.getnamed("hubfilter"); if (!o) return;
        var fb = THEME === "light" ? C.well : C.panel;
        o.message("bgcolor", fb[0], fb[1], fb[2], 1);
        o.message("textcolor", C.txt[0], C.txt[1], C.txt[2], 1);
        o.message("bordercolor", C.dim[0], C.dim[1], C.dim[2], 1);
        o.message("hidden", 0);
    } catch (e) {}
}

// ---------- 업데이트 알림 ([maxurl] → "upd dictionary <name>", 내용 {"latest":"x.y.z"}) ----------
var HUBVER = "1.6.5", UPD = null, UPDURL = "https://app.gumroad.com/library";
function vnum(s) { var p = String(s).split("."); return (parseInt(p[0], 10) || 0) * 1e6 + (parseInt(p[1], 10) || 0) * 1e3 + (parseInt(p[2], 10) || 0); }
function upd() {
    try {
        var a = Array.prototype.slice.call(arguments);
        if (a[0] !== "dictionary") return;
        var d = new Dict(String(a[1])), v = d.get("latest");
        if (v && vnum(v) > vnum(HUBVER)) { UPD = String(v); post("[HUB] update " + UPD + " available\n"); mgraphics.redraw(); }
    } catch (e) { post("[HUB] update check failed " + e + "\n"); }
}
function openUpdate() { cmd("openurl", encodeURIComponent(UPDURL)); }
function hubupd(v, enc) {          // 엔진이 버전 파일을 읽고 보냄: "hubupd <ver> <urlenc>" 또는 "hubupd none"
    if (v === undefined || String(v) === "none") UPD = null;
    else { UPD = String(v); try { UPDURL = decodeURIComponent(String(enc || "")) || UPDURL; } catch (e) {} }
    mgraphics.redraw();
}
function skipUpdate() { if (UPD) { cmd("skipver", UPD); UPD = null; mgraphics.redraw(); } }
// 노란 배너: "UPDATE vX.Y.Z is available"  [DOWNLOAD ↗]  [SKIP THIS VERSION]
function updBanner(x, y, w, h, fs) {
    rect(x, y, w, h, BRAND);
    var ink = [0.07, 0.07, 0.07, 1], ty = y + h / 2 + fs * 0.36;
    font(fs, true); text("UPDATE v" + UPD + " is available", x + 8, ty, ink);
    font(fs - 0.5, true);
    var sk = "SKIP THIS VERSION", dl = "DOWNLOAD \u2197", skw = tw(sk) + 12, dlw = tw(dl) + 12;
    var sx = x + w - 6 - skw, dx = sx - 6 - dlw, by = y + 3, bh = h - 6;
    rect(dx, by, dlw, bh, ink); text(dl, dx + 6, ty, BRAND);
    rect(sx, by, skw, bh, [0, 0, 0, 0.12]); text(sk, sx + 6, ty, ink);
    hit(dx, by, dlw, bh, function () { openUpdate(); });
    hit(sx, by, skw, bh, function () { skipUpdate(); });
}
// 내 컴퓨터의 NEN 디바이스 버전 → 패널 주소의 # 뒤 (서버로 전송되지 않음)
var NENFRAG = "";
function nen(s) {
    NENFRAG = (s === undefined || String(s) === "none") ? "" : String(s);
    if (web) { try { web.message("url", portalUrl()); } catch (e) {} }
}
function portalUrl() { return PORTAL_URL + "&theme=" + THEME + (NENFRAG ? "#have=" + encodeURIComponent(NENFRAG) : ""); }
function adUrl() { return AD_URL + "&theme=" + THEME; }
function reloadPanels() {
    if (web) { try { web.message("url", portalUrl()); } catch (e) {} }
    if (web2) { try { web2.message("url", adUrl()); } catch (e) {} }
}

// ---------- layout ----------
var W, H, LISTB, TOP, HEAD, ROWH, BOT, NAMEF, SUBF, COLS;
if (WIN) {
    W = 692; H = 740; LISTB = 560; TOP = 96; HEAD = 32; ROWH = 30; BOT = 12; NAMEF = 15; SUBF = 10;   // 560 아래 = 미리보기 띠
    COLS = [{ id: "recent", title: "RECENT", x: 12, w: 330 }, { id: "tpl", title: "TEMPLATES", x: 350, w: 330 }];
} else {
    W = 330; H = 169; LISTB = 169; TOP = 0; HEAD = 0; ROWH = 0; BOT = 0; NAMEF = 0; SUBF = 0; COLS = [];
}

// ---------- state ----------
var DATA = { recent: [], tpl: [] };
var META = {};                 // path -> [mtimeMs, offline(0/1)]
var ROOT = "";                 // 새 프로젝트 저장 폴더
var FILTER = [];               // 검색어 토큰(소문자)
var sel = null;                // { col, path }
var scroll = { recent: 0, tpl: 0 }, scrollMax = { recent: 0, tpl: 0 };
var lastClick = { t: 0, col: "", path: "" };
var statusTxt = "starting...";
var PATCHOK = 0, patchTask = null;   // 패치가 보내는 'patchok 2' — 없으면 세트 안에 옛 디바이스가 남은 것
function patchok(v) { PATCHOK = Number(v) || 1; mgraphics.redraw(); }
var hits = [];

function cmd() { outlet(WIN ? 1 : 0, Array.prototype.slice.call(arguments)); }

// ---------- data ----------
function nfc(s) { try { return String(s).normalize("NFC"); } catch (e) { return String(s); } }
function mk(path, isDef) {
    var parts = path.split("/"), file = parts[parts.length - 1], name = file.replace(/\.als$/i, "");
    var par = parts[parts.length - 2] || "", gp = parts[parts.length - 3] || "", sub = par;
    var m = par.match(/^(.*) Project(?:-\d+)?$/);
    if (m) sub = (m[1] === name || m[1] === "Untitled") ? gp : m[1];
    return { name: nfc(name).replace(/^\s+|\s+$/g, ""), sub: isDef ? "DEFAULT" : nfc(sub), path: path, def: !!isDef };
}
function parse(s) { try { return JSON.parse(decodeURIComponent(String(s))); } catch (e) { return null; } }
function keepSel(id) {
    if (!sel || sel.col !== id) return;
    for (var i = 0; i < DATA[id].length; i++) if (DATA[id][i].path === sel.path) return;
    sel = null;
}
var RAWREC = [], RAWTPL = { def: "", list: [] }, PINS = [];
function rebuildRecent() {          // 즐겨찾기(★)는 각 목록 맨 위 (템플릿은 DEFAULT 다음)
    var tplSet = {}, i;
    if (RAWTPL.def) tplSet[RAWTPL.def] = 1;
    for (i = 0; i < RAWTPL.list.length; i++) tplSet[RAWTPL.list[i]] = 1;
    var rec = [], seen = {};
    PINS.forEach(function (p) { if (tplSet[p]) return; var it = mk(p, false); it.pin = true; rec.push(it); seen[p] = 1; });
    RAWREC.forEach(function (p) { if (!seen[p]) rec.push(mk(p, false)); });
    DATA.recent = rec; keepSel("recent");
    var tpl = [], tseen = {};
    if (RAWTPL.def) { var d = mk(RAWTPL.def, true); d.pin = PINS.indexOf(RAWTPL.def) >= 0; tpl.push(d); tseen[RAWTPL.def] = 1; }
    PINS.forEach(function (p) { if (!tplSet[p] || tseen[p]) return; var it = mk(p, false); it.pin = true; tpl.push(it); tseen[p] = 1; });
    RAWTPL.list.forEach(function (p) { if (!tseen[p]) tpl.push(mk(p, false)); });
    DATA.tpl = tpl; keepSel("tpl");
}
function recent(s) {
    var a = parse(s); if (!a || !a.map) return;
    RAWREC = a; scroll.recent = 0; rebuildRecent(); mgraphics.redraw();
}
function pins(s) {
    var a = parse(s); if (!a || !a.map) return;
    PINS = a; rebuildRecent(); mgraphics.redraw();
}
function togglePin(item) { PINS = item.pin ? PINS.filter(function (p) { return p !== item.path; }) : [item.path].concat(PINS); rebuildRecent(); cmd("pin", encodeURIComponent(item.path)); }
function star(cx, cy, r, c, filled) {
    col(c); g.set_line_width(1.2);
    for (var k = 0; k < 10; k++) {
        var a = -Math.PI / 2 + k * Math.PI / 5, rr = (k % 2) ? r * 0.45 : r;
        var px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
        if (k === 0) g.move_to(px, py); else g.line_to(px, py);
    }
    g.close_path(); if (filled) g.fill(); else g.stroke();
}
function templates(s) {
    var o = parse(s); if (!o) return;
    RAWTPL = { def: o.def || "", list: o.list || [] };
    scroll.tpl = 0; rebuildRecent(); mgraphics.redraw();
}
function meta(s) { var o = parse(s); if (!o) return; META = o; mgraphics.redraw(); }
function root(s) { try { ROOT = decodeURIComponent(String(s)); } catch (e) { ROOT = ""; } mgraphics.redraw(); }
function status() {
    var s = Array.prototype.slice.call(arguments).join(" ");
    try { s = decodeURIComponent(s); } catch (e) {}
    statusTxt = s; mgraphics.redraw();
}
// 검색창([textedit] → route text → prepend setfilter)에서 온다. 빈 문자열이면 bang이 붙어 온다.
function setfilter() {
    var a = Array.prototype.slice.call(arguments);
    if (a.length && String(a[0]) === "bang") a = [];
    var q = nfc(a.join(" ")).toLowerCase().split(/\s+/);
    FILTER = q.filter(function (t) { return t.length > 0; });
    scroll.recent = 0; scroll.tpl = 0;
    mgraphics.redraw();
}
function view(id) {
    var arr = DATA[id];
    if (!FILTER.length) return arr;
    return arr.filter(function (it) {
        var h = (it.name + " " + it.sub).toLowerCase();
        for (var k = 0; k < FILTER.length; k++) if (h.indexOf(FILTER[k]) < 0) return false;
        return true;
    });
}
function ago(t) {
    var d = (new Date().getTime() - t) / 1000;
    if (d < 0) d = 0;
    if (d < 3600) return Math.max(1, Math.floor(d / 60)) + "m";
    if (d < 86400) return Math.floor(d / 3600) + "h";
    if (d < 86400 * 14) return Math.floor(d / 86400) + "d";
    if (d < 86400 * 60) return Math.floor(d / 604800) + "w";
    if (d < 86400 * 730) return Math.floor(d / 2592000) + "mo";
    return Math.floor(d / 31536000) + "y";
}

// ---------- window setup (window instance only) ----------
// 포털(jweb)은 창을 처음 열 때 만든다 — 디바이스 로드 때마다 브라우저 엔진이 뜨지 않게
var PORTAL_URL = "https://nen-stuio.vercel.app/hub/?src=hub&side=2", web = null, webTask = null;
var AD_URL = "https://nen-stuio.vercel.app/hub/ad.html?src=hub", web2 = null;
var PW = 400;                                   // 오른쪽 칸 폭 (두 칸 모두 같은 크기)
function makePortal() {
    if (web) return;
    try {
        web = PAT.newdefault(W + 4, 4, "jweb");
        try { web.setboxattr("presentation", 1); web.setboxattr("presentation_rect", [W + 4, 4, PW, H - 8]); } catch (e1) {}
        try { web.message("url", portalUrl()); } catch (e2) {}
        // 포털 페이지의 링크 클릭(window.max.outlet("openurl", url)) → 이 UI → 엔진 → 기본 브라우저
        try { PAT.connect(web, 0, SELF_BOX, 0); } catch (e3) { post("[HUB] portal link connect ERR " + e3 + "\n"); }
        // 오른쪽 끝 광고 칸 — 같은 크기, 홍보할 제품 하나만
        web2 = PAT.newdefault(W + 8 + PW, 4, "jweb");
        try { web2.setboxattr("presentation", 1); web2.setboxattr("presentation_rect", [W + 8 + PW, 4, PW, H - 8]); } catch (e4) {}
        try { web2.message("url", adUrl()); } catch (e5) {}
        try { PAT.connect(web2, 0, SELF_BOX, 0); } catch (e6) { post("[HUB] ad link connect ERR " + e6 + "\n"); }
    } catch (e) { post("[HUB] portal ERR " + e + "\n"); }
}
function openurl() {
    var u = Array.prototype.slice.call(arguments).join(" ");
    if (u) cmd("openurl", encodeURIComponent(u));
}
function showwin() {
    if (!WIN) return;
    try { PAT.locked = 1; } catch (e) {}
    outlet(0, "window", "flags", "float");
    outlet(0, "window", "flags", "nogrow");
    outlet(0, "window", "exec");
    outlet(0, "front");
    mgraphics.redraw();
    if (!patchTask) { patchTask = new Task(function () { mgraphics.redraw(); }, this); patchTask.schedule(2500); }
    if (!web && !webTask) { webTask = new Task(makePortal, this); webTask.schedule(800); }   // 리스트 먼저, 포털은 나중에
}

// ---------- drawing helpers ----------
function col(c) { g.set_source_rgba(c[0], c[1], c[2], c[3]); }
function rect(x, y, w, h, c) { col(c); g.rectangle(x, y, w, h); g.fill(); }
function frame(x, y, w, h, c) { col(c); g.set_line_width(1); g.rectangle(x + 0.5, y + 0.5, w - 1, h - 1); g.stroke(); }
function font(sz, b) { g.select_font_face(b ? "Arial Bold" : "Arial"); g.set_font_size(sz); }
function tw(s) { return g.text_measure(s)[0]; }
function text(s, x, y, c, al, w) { col(c); var xx = x; if (al === "r") xx = x - tw(s); else if (al === "c") xx = x + (w - tw(s)) / 2; g.move_to(xx, y); g.show_text(String(s)); }
function fit(s, w) { s = String(s); if (tw(s) <= w) return s; while (s.length > 1 && tw(s + "…") > w) s = s.slice(0, -1); return s + "…"; }
function glow(s, x, y, c) { var a = [c[0], c[1], c[2], 0.16]; text(s, x - 1, y, a); text(s, x + 1, y, a); text(s, x, y - 1, a); text(s, x, y + 1, a); text(s, x, y, c); }
function hit(x, y, w, h, fn) { hits.push({ x: x, y: y, w: w, h: h, fn: fn }); }
function button(label, x, y, w, h, on, fn, fs, big) {
    if (on) rect(x, y, w, h, C.on); else frame(x, y, w, h, C.dim);
    font(fs, big || on);
    text(label, x, y + h / 2 + fs * 0.36, on ? C.black : C.txt, "c", w);
    hit(x, y, w, h, fn);
}
function wrap(s, x, y, w, lh, maxLines, fs, c) {
    font(fs, false);
    var words = String(s).split(" "), line = "", ly = y, lines = 0;
    for (var i = 0; i < words.length && lines < maxLines; i++) {
        var t = line ? line + " " + words[i] : words[i];
        if (tw(t) > w && line) { text(line, x, ly, c); ly += lh; lines++; line = words[i]; } else line = t;
    }
    if (line && lines < maxLines) text(fit(line, w), x, ly, c);
}

// ---------- paint ----------
function paint() {
    hits = [];
    rect(0, 0, W, H, C.bg);
    if (WIN) paintWindow(); else paintCompact();
}
function selItem() {
    if (!sel) return null;
    var arr = DATA[sel.col] || [];
    for (var i = 0; i < arr.length; i++) if (arr[i].path === sel.path) return arr[i];
    return null;
}

function paintCompact() {
    var PAPER = C.txt, AMBER = C.on, INK = C.bg, MUTE = C.dim;
    rect(0, 0, W, H, INK);
    // 로고 칸 + 이름
    rect(14, 14, 34, 34, PAPER);
    font(11, true); text("NEN", 14, 14 + 17 + 4, INK, "c", 34);   // 로고칸 = 글자색 바탕 + 배경색 글자
    font(30, true); text("HUB", 58, 44, PAPER);
    // 한 줄 상태 (길면 두 줄까지)
    wrap(statusTxt, 14, 66, W - 28, 11, 2, 9, MUTE);
    // 주 버튼: 호박색 판
    rect(14, 98, W - 28, 46, AMBER);
    font(21, true); text("Open HUB", 14, 98 + 23 + 7.5, C.black, "c", W - 28);
    hit(14, 98, W - 28, 46, function () { cmd("openwin"); });
    if (UPD) updBanner(0, H - 22, W, 22, 8.5);
    else { font(8, false); text("Opens when Live starts and on new sets", 14, 160, MUTE); }
}

function paintWindow() {
    // top bar
    rect(0, 0, W, TOP - 8, C.panel);
    font(58, true); glow("HUB", 22, 64, BRAND);   // 로고는 테마와 상관없이 NEN 노랑
    font(8, true); text("NEN AUDIO", 24, 82, C.dim);
    font(8.5, true); var tl = THEME === "dark" ? "LIGHT MODE" : "DARK MODE";
    frame(108, 70, 72, 18, C.dim); text(tl, 108, 82.5, C.txt, "c", 72); hit(108, 70, 72, 18, function () { toggleTheme(); });
    font(8.5, true); text("FILTER", 200, 26, C.dim);                      // [textedit]이 x=250에 얹힌다
    if (PATCHOK < 4 && patchTask) {
        wrap("OLD HUB DEVICE: delete HUB from the track, drag it in again, then Save Current Set as Default.", 200, 44, 215, 12, 3, 9.5, C.hi);
    } else wrap(statusTxt, 200, 50, 215, 13, 2, 9.5, C.dim);
    var rootTxt = ROOT ? ROOT.replace(/^\/Users\/[^\/]+/, "~") : "not set";
    font(8.5, false);
    text(fit("NEW PROJECTS → " + rootTxt + "   [CHANGE]", 215), 200, 82, ROOT ? C.dim : C.hi);
    hit(200, 70, 215, 16, function () { cmd("chooseroot"); });
    button("REVEAL", 422, 14, 108, 26, false, function () { revealSel(); }, 10, false);
    button("REFRESH", 422, 46, 108, 30, false, function () { statusTxt = "scanning..."; cmd("rescan"); }, 11, false);
    var it = selItem(), isTpl = !!it && sel.col === "tpl";
    button(isTpl ? "NEW" : "OPEN", 542, 10, 138, 50, !!it, function () { openSel(); }, 24, true);
    if (isTpl) button("OPEN ORIGINAL", 542, 64, 138, 20, false, function () { openOrig(); }, 9, false);
    for (var i = 0; i < COLS.length; i++) paintCol(COLS[i]);
    paintPreview();
    if (UPD) updBanner(12, H - 30, W - 24, 24, 10);
}
function paintCol(c) {
    var items = view(c.id), total = DATA[c.id].length, y0 = TOP + HEAD, lh = LISTB - y0 - BOT, n = items.length;
    scrollMax[c.id] = Math.max(0, n * ROWH - lh);
    scroll[c.id] = Math.max(0, Math.min(scrollMax[c.id], scroll[c.id]));
    rect(c.x, y0, c.w, lh, C.well);
    if (!n) { font(11, false); text(total ? "no match" : "none found", c.x, y0 + lh / 2 + 4, C.dim, "c", c.w); }
    for (var i = 0; i < n; i++) {
        var it = items[i], ry = y0 + i * ROWH - scroll[c.id];
        if (ry + ROWH < y0 || ry > y0 + lh) continue;
        var on = sel && sel.col === c.id && sel.path === it.path;
        var m = META[it.path], off = !!(m && m[1]);
        if (on) rect(c.x, ry, c.w, ROWH, C.on); else if (i % 2) rect(c.x, ry, c.w, ROWH, [C.panel[0], C.panel[1], C.panel[2], 0.45]);
        var nameC = on ? C.black : (off ? C.dim : C.txt);
        var dateTxt = off ? "OFFLINE" : (m && m[0] ? ago(m[0]) : "");
        var dateW = 46, dateX = c.x + c.w - 14;
        if (dateTxt) { font(SUBF - 1, off); text(dateTxt, dateX, ry + ROWH / 2 + SUBF * 0.34, on ? C.black : (off ? C.hi : C.dim), "r"); }
        font(SUBF, it.def);
        var subMax = c.w * 0.3, subW = it.sub ? Math.min(tw(it.sub) + 2, subMax) : 0;
        if (it.sub) { font(SUBF, it.def); text(fit(it.sub, subMax), dateX - dateW - 4, ry + ROWH / 2 + SUBF * 0.34, on ? C.black : (it.def ? C.hi : C.dim), "r"); }
        var nx = c.x + 10, isRec = true;   // 두 목록 모두 별
        if (isRec) {
            star(c.x + 15, ry + ROWH / 2, 6, it.pin ? (on ? C.black : BRAND) : (on ? C.black : [C.dim[0], C.dim[1], C.dim[2], 0.55]), !!it.pin);
            nx = c.x + 28;
        }
        font(NAMEF, it.def || on);
        text(fit(it.name, c.w - subW - dateW - 38 - (isRec ? 18 : 0)), nx, ry + ROWH / 2 + NAMEF * 0.34, nameC);
        var hy = Math.max(ry, y0), hb = Math.min(ry + ROWH, y0 + lh);
        if (hb - hy > 8) hit(c.x, hy, c.w - 8, hb - hy, (function (id, item) { return function () { pick(id, item); }; })(c.id, it));
        if (isRec && hb - hy > 8) hit(c.x, hy, 26, hb - hy, (function (item) { return function () { togglePin(item); }; })(it));
    }
    // 위/아래로 삐져나온 행 가리기 + 헤더
    rect(c.x, TOP - 8, c.w, HEAD + 8, C.bg);
    rect(c.x, LISTB - BOT, c.w, BOT, C.bg);
    rect(c.x, TOP, c.w, HEAD - 4, C.panel);
    font(11, true); text(c.title, c.x + 10, TOP + 18, C.txt);
    font(10, false); text(FILTER.length ? (n + "/" + total) : String(total), c.x + c.w - 10, TOP + 18, C.dim, "r");
    if (scrollMax[c.id] > 0) { var sh = lh * lh / (lh + scrollMax[c.id]); rect(c.x + c.w - 6, y0 + (lh - sh) * scroll[c.id] / scrollMax[c.id], 4, sh, C.dim); }
}


// ======================= 세트 미리보기 (v1.6) =======================
// .als(gzip XML)를 조금씩 풀면서 템포·박자·키·길이·트랙·어레인지먼트 클립·플러그인을 읽는다.
// Task로 ~12ms씩 나눠 돌려서 Live 화면이 멈추지 않게 한다. 결과는 경로+크기 기준으로 메모리 캐시.
// HUB — set preview core (gzip inflate + .als scanner), resumable via generators.
// Runs in Max 9 [v8] and in Node for testing. No dependencies.

// ---------------- inflate (RFC 1951), generator: yields every ~SLICE output bytes ----------------
const LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
const LEN_EXTRA = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
const DIST_BASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
const DIST_EXTRA = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
const CL_ORDER = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];

// fast table decoder: lookup by up to 15 reversed bits -> (sym<<4)|len
function buildTable(lengths, n) {
  let max = 0; for (let i = 0; i < n; i++) if (lengths[i] > max) max = lengths[i];
  if (max === 0) return { table: new Int32Array(1), bits: 1 };
  const bl_count = new Uint16Array(16); for (let i = 0; i < n; i++) bl_count[lengths[i]]++;
  bl_count[0] = 0;
  const next = new Uint16Array(16); let code = 0;
  for (let b = 1; b <= 15; b++) { code = (code + bl_count[b - 1]) << 1; next[b] = code; }
  const size = 1 << max, table = new Int32Array(size).fill(-1);
  for (let s = 0; s < n; s++) {
    const len = lengths[s]; if (!len) continue;
    let c = next[len]++, r = 0;
    for (let i = 0; i < len; i++) { r = (r << 1) | (c & 1); c >>= 1; }   // reverse
    for (let k = r; k < size; k += 1 << len) table[k] = (s << 4) | len;
  }
  return { table, bits: max };
}
let FIXED_L = null, FIXED_D = null;
function fixedTables() {
  if (FIXED_L) return;
  const l = new Uint8Array(288); l.fill(8, 0, 144); l.fill(9, 144, 256); l.fill(7, 256, 280); l.fill(8, 280, 288);
  FIXED_L = buildTable(l, 288);
  const d = new Uint8Array(30).fill(5); FIXED_D = buildTable(d, 30);
}

function* inflateGen(src, start, out, SLICE) {
  let pos = start, bitbuf = 0, bitcnt = 0, op = 0, nextYield = SLICE;
  const need = (n) => { while (bitcnt < n) { bitbuf |= (src[pos++] | 0) << bitcnt; bitcnt += 8; } };
  const bits = (n) => { need(n); const v = bitbuf & ((1 << n) - 1); bitbuf >>>= n; bitcnt -= n; return v; };
  const decode = (t) => {
    need(t.bits);
    const e = t.table[bitbuf & ((1 << t.bits) - 1)];
    if (e < 0) throw new Error("bad code");
    const len = e & 15; bitbuf >>>= len; bitcnt -= len; return e >> 4;
  };
  let final = 0;
  while (!final) {
    final = bits(1); const type = bits(2);
    if (type === 0) {
      bitbuf = 0; bitcnt = 0;
      const len = src[pos] | (src[pos + 1] << 8); pos += 4;
      out.set(src.subarray(pos, pos + len), op); pos += len; op += len;
    } else {
      let lt, dt;
      if (type === 1) { fixedTables(); lt = FIXED_L; dt = FIXED_D; }
      else {
        const hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
        const cl = new Uint8Array(19); for (let i = 0; i < hclen; i++) cl[CL_ORDER[i]] = bits(3);
        const ct = buildTable(cl, 19);
        const lens = new Uint8Array(hlit + hdist); let i = 0;
        while (i < hlit + hdist) {
          const s = decode(ct);
          if (s < 16) lens[i++] = s;
          else if (s === 16) { const p = lens[i - 1]; let r = 3 + bits(2); while (r--) lens[i++] = p; }
          else if (s === 17) { let r = 3 + bits(3); while (r--) lens[i++] = 0; }
          else { let r = 11 + bits(7); while (r--) lens[i++] = 0; }
        }
        lt = buildTable(lens.subarray(0, hlit), hlit); dt = buildTable(lens.subarray(hlit), hdist);
      }
      for (;;) {
        const s = decode(lt);
        if (s < 256) { out[op++] = s; }
        else if (s === 256) break;
        else {
          const li = s - 257; let len = LEN_BASE[li] + (LEN_EXTRA[li] ? bits(LEN_EXTRA[li]) : 0);
          const di = decode(dt); const dist = DIST_BASE[di] + (DIST_EXTRA[di] ? bits(DIST_EXTRA[di]) : 0);
          let from = op - dist;
          if (dist >= len) { out.copyWithin(op, from, from + len); op += len; }
          else while (len--) out[op++] = out[from++];
        }
        if (op >= nextYield) { nextYield = op + SLICE; yield op; }
      }
    }
  }
  return op;
}

function gunzipInfo(src) {
  if (src[0] !== 0x1f || src[1] !== 0x8b) return null;           // not gzip: maybe plain XML
  const flg = src[3]; let p = 10;
  if (flg & 4) { const xlen = src[p] | (src[p + 1] << 8); p += 2 + xlen; }
  if (flg & 8) { while (src[p++]); }
  if (flg & 16) { while (src[p++]); }
  if (flg & 2) p += 2;
  const n = src.length, isize = (src[n - 4] | (src[n - 3] << 8) | (src[n - 2] << 16) | (src[n - 1] << 24)) >>> 0;
  return { start: p, size: isize };
}

// ---------------- scanner over the XML bytes ----------------
function utf8(bytes, a, b) {
  let s = "", i = a;
  while (i < b) {
    const c = bytes[i++];
    if (c < 0x80) s += String.fromCharCode(c);
    else if (c < 0xe0) s += String.fromCharCode(((c & 31) << 6) | (bytes[i++] & 63));
    else if (c < 0xf0) s += String.fromCharCode(((c & 15) << 12) | ((bytes[i++] & 63) << 6) | (bytes[i++] & 63));
    else { const cp = ((c & 7) << 18) | ((bytes[i++] & 63) << 12) | ((bytes[i++] & 63) << 6) | (bytes[i++] & 63);
           const u = cp - 0x10000; s += String.fromCharCode(0xd800 + (u >> 10), 0xdc00 + (u & 1023)); }
  }
  return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}
const enc = (s) => { const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; };
function startsAt(b, i, pat) { for (let k = 0; k < pat.length; k++) if (b[i + k] !== pat[k]) return false; return true; }
// value of the next Value="…" after position i (within lim bytes)
function valueAfter(b, i, lim) {
  const end = Math.min(b.length, i + (lim || 400));
  for (let k = i; k < end - 7; k++) {
    if (b[k] === 86 && b[k+1] === 97 && b[k+2] === 108 && b[k+3] === 117 && b[k+4] === 101 && b[k+5] === 61 && b[k+6] === 34) {
      const s = k + 7; let e = s; while (e < b.length && b[e] !== 34) e++;
      return { v: utf8(b, s, e), at: e };
    }
  }
  return null;
}
function manualAfter(b, i) {            // <Tempo>/<TimeSignature> → first <Manual Value="…"> (skips <LomId Value=…>)
  for (let k = i; k < Math.min(b.length, i + 600); k++) if (b[k] === 60 && startsAt(b, k, P.manual)) return valueAfter(b, k, 60);
  return null;
}
function attrAfter(b, i, name, lim) {   // name="…" in the same tag
  const pat = enc(name + '="'); const end = Math.min(b.length, i + (lim || 120));
  for (let k = i; k < end; k++) { if (b[k] === 62) return null; if (startsAt(b, k, pat)) { const s = k + pat.length; let e = s; while (b[e] !== 34) e++; return utf8(b, s, e); } }
  return null;
}

const P = {
  audio: enc("<AudioTrack Id"), midi: enc("<MidiTrack Id"), group: enc("<GroupTrack Id"), ret: enc("<ReturnTrack Id"),
  main: enc("<MainTrack"), master: enc("<MasterTrack"), prehear: enc("<PreHearTrack"),
  effName: enc("<EffectiveName "), color: enc("<Color "), groupId: enc("<TrackGroupId "),
  arrOpen: enc("<ArrangerAutomation>"), arrClose: enc("</ArrangerAutomation>"),
  aclip: enc("<AudioClip Id"), mclip: enc("<MidiClip Id"),
  cStart: enc("<CurrentStart "), cEnd: enc("<CurrentEnd "), name: enc("<Name "),
  tempo: enc("<Tempo>"), manual: enc("<Manual "), tsig: enc("<TimeSignature>"),
  plug: enc("<PlugName "), au: enc("<AuPluginInfo>"), vst3: enc("<Vst3PluginInfo"),
  scale: enc("<ScaleInformation>"), root: enc("<Root "), inKey: enc("<InKey "),
  locator: enc("<Locator Id"), time: enc("<Time "), sample: enc("<SampleRef>"),
};

function* scanGen(b, total, SLICE) {
  const info = { tempo: null, sig: null, key: null, tracks: [], plugins: {}, locators: [], length: 0, clips: 0, samples: 0 };
  let tr = null, inArr = false, nextYield = SLICE, sawTempo = false, sawSig = false, lastScale = null, inPrehear = false;
  const n = total;
  for (let i = 0; i < n; i++) {
    if (b[i] !== 60) continue;                                   // '<'
    if (i >= nextYield) { nextYield = i + SLICE; yield i; }
    const c1 = b[i + 1];
    if (c1 === 65 && startsAt(b, i, P.audio) || c1 === 77 && startsAt(b, i, P.midi) || c1 === 71 && startsAt(b, i, P.group) ||
        c1 === 82 && startsAt(b, i, P.ret) || c1 === 77 && (startsAt(b, i, P.main) || startsAt(b, i, P.master))) {
      const kind = c1 === 65 ? "audio" : c1 === 71 ? "group" : c1 === 82 ? "return" : startsAt(b, i, P.midi) ? "midi" : "main";
      tr = { kind, name: null, color: null, group: null, id: attrAfter(b, i, "Id"), clips: [] };
      info.tracks.push(tr); inArr = false; inPrehear = false; continue;
    }
    if (c1 === 80 && startsAt(b, i, P.prehear)) { inPrehear = true; tr = null; continue; }
    if (!tr || tr.kind === "main") {      // tempo / time signature live in the Main track's mixer
      if (!sawTempo && c1 === 84 && startsAt(b, i, P.tempo)) { const m = manualAfter(b, i); if (m) { info.tempo = +m.v; sawTempo = true; } continue; }
      if (!sawSig && c1 === 84 && startsAt(b, i, P.tsig)) { const m = manualAfter(b, i); if (m) { const v = +m.v; info.sig = [(v % 99) + 1, Math.pow(2, Math.floor(v / 99))]; sawSig = true; } continue; }
      if (!tr) continue;
    }
    if (tr.name === null && c1 === 69 && startsAt(b, i, P.effName)) { const m = valueAfter(b, i); tr.name = m ? m.v : ""; continue; }
    if (tr.name !== null && tr.color === null && c1 === 67 && startsAt(b, i, P.color)) { const m = valueAfter(b, i); tr.color = m ? +m.v : 0; continue; }
    if (tr.group === null && c1 === 84 && startsAt(b, i, P.groupId)) { const m = valueAfter(b, i); tr.group = m ? m.v : "-1"; continue; }
    if (c1 === 65 && startsAt(b, i, P.arrOpen)) { inArr = true; continue; }
    if (c1 === 47 && startsAt(b, i, P.arrClose)) { inArr = false; continue; }
    if (inArr && (c1 === 65 && startsAt(b, i, P.aclip) || c1 === 77 && startsAt(b, i, P.mclip))) {
      const t0 = +attrAfter(b, i, "Time");
      let s = null, e = null, nm = "", col = null, k = i + 10;
      const lim = i + 4000;
      for (; k < lim && (s === null || e === null || col === null); k++) {
        if (b[k] !== 60) continue;
        if (s === null && startsAt(b, k, P.cStart)) s = +valueAfter(b, k).v;
        else if (e === null && startsAt(b, k, P.cEnd)) e = +valueAfter(b, k).v;
        else if (!nm && startsAt(b, k, P.name)) nm = valueAfter(b, k).v;
        else if (col === null && startsAt(b, k, P.color)) col = +valueAfter(b, k).v;
      }
      const len = (e !== null && s !== null) ? e - s : 0;
      tr.clips.push([t0, t0 + len, col === null ? tr.color : col, nm, c1 === 77 ? 1 : 0]);
      if (t0 + len > info.length) info.length = t0 + len;
      info.clips++;
      continue;
    }
    if (c1 === 80 && startsAt(b, i, P.plug)) { const m = valueAfter(b, i); if (m) info.plugins[m.v] = (info.plugins[m.v] || 0) + 1; continue; }
    if (c1 === 65 && startsAt(b, i, P.au) || c1 === 86 && startsAt(b, i, P.vst3)) {
      for (let k = i; k < i + 600; k++) if (b[k] === 60 && startsAt(b, k, P.name)) { const m = valueAfter(b, k); if (m) info.plugins[m.v] = (info.plugins[m.v] || 0) + 1; break; }
      continue;
    }
  }
  // set-level fields live after the tracks: scan the tail once (cheap)
  const tailStart = Math.max(0, n - 6000000);
  for (let i = tailStart; i < n; i++) {
    if (b[i] !== 60) continue;
    if (startsAt(b, i, P.scale)) { const r = valueAfter(b, i, 200), nm = r && valueAfter(b, r.at, 200); lastScale = [r ? +r.v : 0, nm ? +nm.v : 0]; }
    else if (startsAt(b, i, P.inKey)) { const m = valueAfter(b, i); if (m && m.v === "true" && lastScale) info.key = lastScale; }
    else if (startsAt(b, i, P.locator)) {
      let t = null, nm = ""; for (let k = i; k < i + 600; k++) if (b[k] === 60) { if (t === null && startsAt(b, k, P.time)) t = +valueAfter(b, k).v; else if (!nm && startsAt(b, k, P.name)) nm = valueAfter(b, k).v; }
      if (t !== null) info.locators.push([t, nm]);
    }
  }
  if (!sawSig) info.sig = [4, 4];
  if (!info.tempo) info.tempo = 120;
  // drop empty tracks from the map but keep counts
  return info;
}


var PAL = ["FF94A6","FFA529","CC9927","F7F47C","BFFB00","1AFF2F","25FFA8","5CFFE8","8BC5FF","5480E4","92A7FF","D86CE4","E553A0","FFFFFF",
 "FF3636","F66C03","99724B","FFF034","87FF67","3DC300","00BFAF","19E9FF","10A4EE","007DC0","886CE4","B677C6","FF39D4","D0D0D0",
 "E2675A","FFA374","D3AD71","EDFFAE","D2E498","BAD074","9BC48D","D4FDE1","CDF1F8","B9C1E3","CDBBE4","AE98E5","E5DCE1","A9A9A9",
 "C6928B","B78256","99836A","BFBA69","A6BE00","7DB04D","88C2BA","9BB3C4","85A5C2","8393CC","A595B5","BF9FBE","BC7196","7B7B7B",
 "AF3333","A95131","724F41","DBC300","85961F","539F31","0A9C8E","236384","1A2F96","2F52A2","624BAD","A34BAD","CC2E6E","3C3C3C"];
function palRGBA(i) { var h = PAL[i] || "888888"; return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255, 1]; }
var KEYN = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"], SCALEN = ["Major","Minor","Dorian","Mixolydian","Lydian","Phrygian","Locrian"];

var PV = { item: null, state: "idle", pct: 0, info: null, err: "" }, pvCache = {}, pvGen = null, pvTask = null;
function* previewJob(path) {
    var f = new File(path, "read");
    if (!f.isopen) { f = new File("Macintosh HD:" + path, "read"); }
    if (!f.isopen) throw new Error("can't open");
    var size = f.eof, src = new Uint8Array(size), got = 0;
    while (got < size) {
        var chunk = f.readbytes(Math.min(65536, size - got));
        if (!chunk || !chunk.length) break;
        src.set(chunk, got); got += chunk.length;
        PV.pct = Math.round(10 * got / size); yield 0;
    }
    f.close();
    var key = path + "|" + size;
    if (pvCache[key]) return pvCache[key];
    var g = gunzipInfo(src), xml = src, total = got;
    if (g) {
        xml = new Uint8Array(g.size);
        var it = inflateGen(src, g.start, xml, 1 << 19), r;
        while (!(r = it.next()).done) { PV.pct = 10 + Math.round(45 * r.value / g.size); yield 0; }
        total = r.value; src = null;
    }
    var sc = scanGen(xml, total, 1 << 19), r2;
    while (!(r2 = sc.next()).done) { PV.pct = 55 + Math.round(45 * r2.value / total); yield 0; }
    var info = r2.value;
    pvCache[key] = info;
    return info;
}
function requestPreview(item) {
    if (!WIN) return;
    if (PV.item && PV.item.path === item.path && PV.state !== "error") return;
    PV.item = item; PV.info = null; PV.err = ""; PV.pct = 0;
    var m = META[item.path];
    if (m && m[1]) { PV.state = "offline"; pvGen = null; mgraphics.redraw(); return; }
    PV.state = "loading";
    try { pvGen = previewJob(item.path); } catch (e) { PV.state = "error"; PV.err = String(e); pvGen = null; }
    if (!pvTask) { pvTask = new Task(pvTick, this); pvTask.interval = 15; }
    pvTask.repeat();
    mgraphics.redraw();
}
function pvTick() {
    if (!pvGen) { pvTask.cancel(); return; }
    var t0 = new Date().getTime(), r;
    try {
        do { r = pvGen.next(); } while (!r.done && new Date().getTime() - t0 < 12);
    } catch (e) { PV.state = "error"; PV.err = String(e.message || e); pvGen = null; pvTask.cancel(); post("[HUB] preview ERR " + e + "\n"); mgraphics.redraw(); return; }
    if (r.done) { PV.info = r.value; PV.state = "ready"; pvGen = null; pvTask.cancel(); }
    mgraphics.redraw();
}
function mmss(sec) { var m = Math.floor(sec / 60), s = Math.round(sec % 60); if (s === 60) { m++; s = 0; } return m + ":" + (s < 10 ? "0" : "") + s; }
function paintPreview() {
    var X = 12, Y = LISTB - 4, PW = W - 24, PH = H - Y - 8 - (UPD ? 30 : 0);
    rect(X, Y, PW, PH, C.panel);
    var L = X + 12;
    if (!PV.item) { font(11, false); text("Select a set to see its tempo, length, tracks and arrangement.", X, Y + PH / 2 + 4, C.dim, "c", PW); return; }
    font(16, true); text(fit(PV.item.name, 226), L, Y + 26, C.txt);
    font(9.5, false); text(fit(PV.item.sub || "", 226), L, Y + 41, C.dim);
    var MX = X + 248, MY = Y + 20, MW = X + PW - 12 - MX, MH = PH - 32;
    rect(MX, MY, MW, MH, C.well);
    font(8.5, true); text("ARRANGEMENT", MX, MY - 6, C.dim);
    if (PV.state === "offline") { font(11, true); text("OFFLINE: this drive is not connected.", MX, MY + MH / 2 + 4, C.hi, "c", MW); return; }
    if (PV.state === "error") { font(10, false); text("Can't read this set.", MX, MY + MH / 2 + 4, C.dim, "c", MW); return; }
    if (PV.state === "loading") {
        font(10, false); text("reading set ... " + PV.pct + "%", MX, MY + MH / 2 - 4, C.dim, "c", MW);
        rect(MX + MW * 0.25, MY + MH / 2 + 6, MW * 0.5, 3, C.line); rect(MX + MW * 0.25, MY + MH / 2 + 6, MW * 0.5 * PV.pct / 100, 3, C.on);
        return;
    }
    var info = PV.info; if (!info) return;
    var tr = [], nA = 0, nM = 0, nR = 0;
    for (var i = 0; i < info.tracks.length; i++) { var t = info.tracks[i]; if (t.kind === "main") continue; tr.push(t); if (t.kind === "audio") nA++; else if (t.kind === "midi") nM++; else if (t.kind === "return") nR++; }
    var beats = info.length, secs = info.tempo ? beats / info.tempo * 60 : 0, bars = info.sig ? Math.round(beats / info.sig[0]) : 0;
    var rows = [["TEMPO", (Math.round(info.tempo * 100) / 100) + " BPM"], ["TIME", info.sig ? info.sig.join("/") : "-"],
        ["KEY", info.key ? KEYN[info.key[0]] + " " + (SCALEN[info.key[1]] || "") : "—"],
        ["LENGTH", beats ? mmss(secs) + "  (" + bars + " bars)" : "empty"],
        ["TRACKS", tr.length + "  (" + nA + " audio · " + nM + " midi" + (nR ? " · " + nR + " ret" : "") + ")"]];
    var pl = []; for (var k in info.plugins) pl.push(k);
    rows.push(["PLUG-INS", pl.length ? pl.slice(0, 3).join(", ") + (pl.length > 3 ? "  +" + (pl.length - 3) : "") : "none"]);
    for (var r = 0; r < rows.length; r++) {
        font(8.5, true); text(rows[r][0], L, Y + 64 + r * 17, C.dim);
        font(11, false); text(fit(rows[r][1], 168), L + 54, Y + 64 + r * 17, C.txt);
    }
    // 미니 편곡 맵
    var lanes = []; for (i = 0; i < tr.length; i++) if (tr[i].kind !== "group" && tr[i].kind !== "return" && tr[i].clips.length) lanes.push(tr[i]);
    font(8.5, true); text(lanes.length + " lanes · " + info.clips + " clips", MX + MW, MY - 6, C.dim, "r");
    if (!beats || !lanes.length) { font(10, false); text("No clips in the arrangement.", MX, MY + MH / 2 + 4, C.dim, "c", MW); return; }
    var sx = MW / beats, rh = Math.max(1.5, Math.min(9, (MH - 12) / lanes.length)), barB = info.sig ? info.sig[0] : 4;
    for (var b = 0; b * barB <= beats; b += 8) rect(MX + b * barB * sx, MY, 1, MH, C.line);
    font(7.5, false); for (b = 0; b * barB <= beats; b += 16) text(String(b + 1), MX + b * barB * sx + 2, MY + MH - 3, C.dim);
    for (i = 0; i < lanes.length; i++) {
        var y = MY + 3 + i * rh, cl = lanes[i].clips;
        for (var j = 0; j < cl.length; j++) {
            var c = cl[j]; rect(MX + c[0] * sx, y, Math.max(1, (c[1] - c[0]) * sx - 0.5), Math.max(1, rh - 0.6), palRGBA(c[2]));
        }
    }
    for (i = 0; i < info.locators.length; i++) { var lx = MX + info.locators[i][0] * sx; rect(lx, MY, 1, MH, BRAND); font(7.5, true); text(fit(info.locators[i][1], 60), lx + 2, MY + 9, BRAND); }
}

// ---------- actions ----------
function pick(id, item) {
    var now = new Date().getTime();
    var dbl = lastClick.col === id && lastClick.path === item.path && now - lastClick.t < 450;
    lastClick = { t: now, col: id, path: item.path };
    sel = { col: id, path: item.path };
    requestPreview(item);
    if (dbl) openSel();
}
// 최근 세트 = 그대로 열기 / 템플릿 = 복사본으로 새 프로젝트 (원본 보호)
function openSel() {
    var it = selItem(); if (!it) return;
    if (sel.col === "tpl") { statusTxt = "creating new project from " + it.name + " ..."; cmd("newfrom", encodeURIComponent(it.path)); }
    else { statusTxt = "opening " + it.name + " ..."; cmd("openset", encodeURIComponent(it.path)); }
}
function openOrig() {
    var it = selItem(); if (!it) return;
    statusTxt = "opening template itself: " + it.name + " ...";
    cmd("openset", encodeURIComponent(it.path));
}
function revealSel() {
    var it = selItem(); if (!it) { statusTxt = "select a row first"; return; }
    cmd("revealset", encodeURIComponent(it.path));
}

// ---------- mouse ----------
function onclick(x, y, but, cmdk, shift) {
    for (var i = hits.length - 1; i >= 0; i--) {
        var h = hits[i];
        if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) { h.fn(); mgraphics.redraw(); return; }
    }
}
onclick.local = 1;
function onwheel(x, y, wx, wy) {
    for (var i = 0; i < COLS.length; i++) {
        var c = COLS[i];
        if (x >= c.x && x <= c.x + c.w) { scroll[c.id] = Math.max(0, Math.min(scrollMax[c.id], scroll[c.id] - wy * 30)); mgraphics.redraw(); return; }
    }
}
onwheel.local = 1;
function bang() { mgraphics.redraw(); }

// 디바이스 뷰: 로드 직후 엔진과 동기화
if (!WIN) { var bootTask = new Task(function () { cmd("init"); }, this); bootTask.schedule(700); }
