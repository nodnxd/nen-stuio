// HUB — UI (v8ui) v1.4. jsarguments: "compact" (디바이스 뷰: OPEN 버튼) | "window" (플로팅 창: 큰 Recent / Templates 리스트)
// 리스트는 hub_engine.js가 에이블톤 파일에서 읽어 보내고, 클릭은 다시 엔진으로 간다.
//   window  : outlet 0 → thispatcher(창 플래그), outlet 1 → 엔진 명령
//   compact : outlet 0 → 엔진 명령
// 입력 메시지: recent / templates / meta / root / status / setfilter(검색창) / openurl(포털 링크) / showwin
autowatch = 1; inlets = 1; outlets = 2;
mgraphics.init(); mgraphics.relative_coords = 0; mgraphics.autofill = 0;
var g = mgraphics;
var MODE = (jsarguments.length > 1) ? String(jsarguments[1]) : "compact";
var WIN = (MODE === "window");
var PAT = this.patcher;
var SELF_BOX = this.box;     // 로드 시점에 잡아둠 (Task 콜백 안에선 this가 달라짐)

// ---------- theme (Set Monitor / Strip Silence 톤) ----------
var C = { bg: [0.165, 0.165, 0.165, 1], panel: [0.13, 0.13, 0.13, 1], well: [0.09, 0.09, 0.09, 1], line: [0.27, 0.27, 0.27, 1],
    dim: [0.55, 0.55, 0.55, 1], txt: [0.88, 0.88, 0.88, 1], hi: [0.96, 0.65, 0.14, 1], on: [0.96, 0.77, 0.09, 1], black: [0.07, 0.07, 0.07, 1] };

// ---------- layout ----------
var W, H, TOP, HEAD, ROWH, BOT, NAMEF, SUBF, COLS;
if (WIN) {
    W = 692; H = 560; TOP = 96; HEAD = 32; ROWH = 30; BOT = 12; NAMEF = 15; SUBF = 10;
    COLS = [{ id: "recent", title: "RECENT", x: 12, w: 330 }, { id: "tpl", title: "TEMPLATES", x: 350, w: 330 }];
} else {
    W = 330; H = 169; TOP = 0; HEAD = 0; ROWH = 0; BOT = 0; NAMEF = 0; SUBF = 0; COLS = [];
}

// ---------- state ----------
var DATA = { recent: [], tpl: [] };
var META = {};                 // path -> [mtimeMs, offline(0/1)]
var ROOT = "";                 // 새 프로젝트 저장 폴더
var FILTER = [];               // 검색어 토큰(소문자)
var sel = null;                // { col, path }
var scroll = { recent: 0, tpl: 0 }, scrollMax = { recent: 0, tpl: 0 };
var lastClick = { t: 0, col: "", path: "" };
var statusTxt = "starting...";
var PATCHOK = 0, patchTask = null;   // 패치가 보내는 'patchok 2' — 없으면 세트 안에 옛 디바이스가 남은 것
function patchok(v) { PATCHOK = Number(v) || 1; mgraphics.redraw(); }
var hits = [];

function cmd() { outlet(WIN ? 1 : 0, Array.prototype.slice.call(arguments)); }

// ---------- data ----------
function nfc(s) { try { return String(s).normalize("NFC"); } catch (e) { return String(s); } }
function mk(path, isDef) {
    var parts = path.split("/"), file = parts[parts.length - 1], name = file.replace(/\.als$/i, "");
    var par = parts[parts.length - 2] || "", gp = parts[parts.length - 3] || "", sub = par;
    var m = par.match(/^(.*) Project(?:-\d+)?$/);
    if (m) sub = (m[1] === name || m[1] === "Untitled") ? gp : m[1];
    return { name: nfc(name).replace(/^\s+|\s+$/g, ""), sub: isDef ? "DEFAULT" : nfc(sub), path: path, def: !!isDef };
}
function parse(s) { try { return JSON.parse(decodeURIComponent(String(s))); } catch (e) { return null; } }
function keepSel(id) {
    if (!sel || sel.col !== id) return;
    for (var i = 0; i < DATA[id].length; i++) if (DATA[id][i].path === sel.path) return;
    sel = null;
}
function recent(s) {
    var a = parse(s); if (!a || !a.map) return;
    DATA.recent = a.map(function (p) { return mk(p, false); });
    scroll.recent = 0; keepSel("recent"); mgraphics.redraw();
}
function templates(s) {
    var o = parse(s); if (!o) return;
    var out = [];
    if (o.def) out.push(mk(o.def, true));
    (o.list || []).forEach(function (p) { out.push(mk(p, false)); });
    DATA.tpl = out; scroll.tpl = 0; keepSel("tpl"); mgraphics.redraw();
}
function meta(s) { var o = parse(s); if (!o) return; META = o; mgraphics.redraw(); }
function root(s) { try { ROOT = decodeURIComponent(String(s)); } catch (e) { ROOT = ""; } mgraphics.redraw(); }
function status() {
    var s = Array.prototype.slice.call(arguments).join(" ");
    try { s = decodeURIComponent(s); } catch (e) {}
    statusTxt = s; mgraphics.redraw();
}
// 검색창([textedit] → route text → prepend setfilter)에서 온다. 빈 문자열이면 bang이 붙어 온다.
function setfilter() {
    var a = Array.prototype.slice.call(arguments);
    if (a.length && String(a[0]) === "bang") a = [];
    var q = nfc(a.join(" ")).toLowerCase().split(/\s+/);
    FILTER = q.filter(function (t) { return t.length > 0; });
    scroll.recent = 0; scroll.tpl = 0;
    mgraphics.redraw();
}
function view(id) {
    var arr = DATA[id];
    if (!FILTER.length) return arr;
    return arr.filter(function (it) {
        var h = (it.name + " " + it.sub).toLowerCase();
        for (var k = 0; k < FILTER.length; k++) if (h.indexOf(FILTER[k]) < 0) return false;
        return true;
    });
}
function ago(t) {
    var d = (new Date().getTime() - t) / 1000;
    if (d < 0) d = 0;
    if (d < 3600) return Math.max(1, Math.floor(d / 60)) + "m";
    if (d < 86400) return Math.floor(d / 3600) + "h";
    if (d < 86400 * 14) return Math.floor(d / 86400) + "d";
    if (d < 86400 * 60) return Math.floor(d / 604800) + "w";
    if (d < 86400 * 730) return Math.floor(d / 2592000) + "mo";
    return Math.floor(d / 31536000) + "y";
}

// ---------- window setup (window instance only) ----------
// 포털(jweb)은 창을 처음 열 때 만든다 — 디바이스 로드 때마다 브라우저 엔진이 뜨지 않게
var PORTAL_URL = "https://nen-stuio.vercel.app/hub/?src=hub", web = null, webTask = null;
function makePortal() {
    if (web) return;
    try {
        web = PAT.newdefault(W + 4, 4, "jweb");
        var rect = [W + 4, 4, 1100 - W - 8, H - 8];
        try { web.setboxattr("presentation", 1); web.setboxattr("presentation_rect", rect); } catch (e1) {}
        try { web.message("url", PORTAL_URL); } catch (e2) {}
        // 포털 페이지의 링크 클릭(window.max.outlet("openurl", url)) → 이 UI → 엔진 → 기본 브라우저
        try { PAT.connect(web, 0, SELF_BOX, 0); } catch (e3) { post("[HUB] portal link connect ERR " + e3 + "\n"); }
    } catch (e) { post("[HUB] portal ERR " + e + "\n"); }
}
function openurl() {
    var u = Array.prototype.slice.call(arguments).join(" ");
    if (u) cmd("openurl", encodeURIComponent(u));
}
function showwin() {
    if (!WIN) return;
    try { PAT.locked = 1; } catch (e) {}
    outlet(0, "window", "flags", "float");
    outlet(0, "window", "flags", "nogrow");
    outlet(0, "window", "exec");
    outlet(0, "front");
    mgraphics.redraw();
    if (!patchTask) { patchTask = new Task(function () { mgraphics.redraw(); }, this); patchTask.schedule(2500); }
    if (!web && !webTask) { webTask = new Task(makePortal, this); webTask.schedule(800); }   // 리스트 먼저, 포털은 나중에
}

// ---------- drawing helpers ----------
function col(c) { g.set_source_rgba(c[0], c[1], c[2], c[3]); }
function rect(x, y, w, h, c) { col(c); g.rectangle(x, y, w, h); g.fill(); }
function frame(x, y, w, h, c) { col(c); g.set_line_width(1); g.rectangle(x + 0.5, y + 0.5, w - 1, h - 1); g.stroke(); }
function font(sz, b) { g.select_font_face(b ? "Arial Bold" : "Arial"); g.set_font_size(sz); }
function tw(s) { return g.text_measure(s)[0]; }
function text(s, x, y, c, al, w) { col(c); var xx = x; if (al === "r") xx = x - tw(s); else if (al === "c") xx = x + (w - tw(s)) / 2; g.move_to(xx, y); g.show_text(String(s)); }
function fit(s, w) { s = String(s); if (tw(s) <= w) return s; while (s.length > 1 && tw(s + "…") > w) s = s.slice(0, -1); return s + "…"; }
function glow(s, x, y, c) { var a = [c[0], c[1], c[2], 0.16]; text(s, x - 1, y, a); text(s, x + 1, y, a); text(s, x, y - 1, a); text(s, x, y + 1, a); text(s, x, y, c); }
function hit(x, y, w, h, fn) { hits.push({ x: x, y: y, w: w, h: h, fn: fn }); }
function button(label, x, y, w, h, on, fn, fs, big) {
    if (on) rect(x, y, w, h, C.on); else frame(x, y, w, h, C.dim);
    font(fs, big || on);
    text(label, x, y + h / 2 + fs * 0.36, on ? C.black : C.txt, "c", w);
    hit(x, y, w, h, fn);
}
function wrap(s, x, y, w, lh, maxLines, fs, c) {
    font(fs, false);
    var words = String(s).split(" "), line = "", ly = y, lines = 0;
    for (var i = 0; i < words.length && lines < maxLines; i++) {
        var t = line ? line + " " + words[i] : words[i];
        if (tw(t) > w && line) { text(line, x, ly, c); ly += lh; lines++; line = words[i]; } else line = t;
    }
    if (line && lines < maxLines) text(fit(line, w), x, ly, c);
}

// ---------- paint ----------
function paint() {
    hits = [];
    rect(0, 0, W, H, C.bg);
    if (WIN) paintWindow(); else paintCompact();
}
function selItem() {
    if (!sel) return null;
    var arr = DATA[sel.col] || [];
    for (var i = 0; i < arr.length; i++) if (arr[i].path === sel.path) return arr[i];
    return null;
}

function paintCompact() {
    var PAPER = [0.925, 0.92, 0.906, 1], AMBER = [0.957, 0.651, 0.165, 1], INK = [0.055, 0.055, 0.055, 1], MUTE = [0.55, 0.54, 0.52, 1];
    rect(0, 0, W, H, INK);
    // 로고 칸 + 이름
    rect(14, 14, 34, 34, PAPER);
    font(11, true); text("NEN", 14, 14 + 17 + 4, INK, "c", 34);
    font(30, true); text("HUB", 58, 44, PAPER);
    // 한 줄 상태 (길면 두 줄까지)
    wrap(statusTxt, 14, 66, W - 28, 11, 2, 9, MUTE);
    // 주 버튼: 호박색 판
    rect(14, 98, W - 28, 46, AMBER);
    font(21, true); text("Open HUB", 14, 98 + 23 + 7.5, INK, "c", W - 28);
    hit(14, 98, W - 28, 46, function () { cmd("openwin"); });
    font(8, false); text("Opens when Live starts and on new sets", 14, 160, MUTE);
}

function paintWindow() {
    // top bar
    rect(0, 0, W, TOP - 8, C.panel);
    font(58, true); glow("HUB", 22, 72, C.hi);
    font(8, true); text("NEN AUDIO", 24, 86, C.dim);
    font(8.5, true); text("FILTER", 200, 26, C.dim);                      // [textedit]이 x=250에 얹힌다
    if (!PATCHOK && patchTask) {
        wrap("OLD HUB DEVICE: delete HUB from the track, drag it in again, then Save Current Set as Default.", 200, 44, 215, 12, 3, 9.5, C.hi);
    } else wrap(statusTxt, 200, 50, 215, 13, 2, 9.5, C.dim);
    var rootTxt = ROOT ? ROOT.replace(/^\/Users\/[^\/]+/, "~") : "not set";
    font(8.5, false);
    text(fit("NEW PROJECTS → " + rootTxt + "   [CHANGE]", 215), 200, 82, ROOT ? C.dim : C.hi);
    hit(200, 70, 215, 16, function () { cmd("chooseroot"); });
    button("REVEAL", 422, 14, 108, 26, false, function () { revealSel(); }, 10, false);
    button("REFRESH", 422, 46, 108, 30, false, function () { statusTxt = "scanning..."; cmd("rescan"); }, 11, false);
    var it = selItem(), isTpl = !!it && sel.col === "tpl";
    button(isTpl ? "NEW" : "OPEN", 542, 10, 138, 50, !!it, function () { openSel(); }, 24, true);
    if (isTpl) button("OPEN ORIGINAL", 542, 64, 138, 20, false, function () { openOrig(); }, 9, false);
    for (var i = 0; i < COLS.length; i++) paintCol(COLS[i]);
}
function paintCol(c) {
    var items = view(c.id), total = DATA[c.id].length, y0 = TOP + HEAD, lh = H - y0 - BOT, n = items.length;
    scrollMax[c.id] = Math.max(0, n * ROWH - lh);
    scroll[c.id] = Math.max(0, Math.min(scrollMax[c.id], scroll[c.id]));
    rect(c.x, y0, c.w, lh, C.well);
    if (!n) { font(11, false); text(total ? "no match" : "none found", c.x, y0 + lh / 2 + 4, C.dim, "c", c.w); }
    for (var i = 0; i < n; i++) {
        var it = items[i], ry = y0 + i * ROWH - scroll[c.id];
        if (ry + ROWH < y0 || ry > y0 + lh) continue;
        var on = sel && sel.col === c.id && sel.path === it.path;
        var m = META[it.path], off = !!(m && m[1]);
        if (on) rect(c.x, ry, c.w, ROWH, C.on); else if (i % 2) rect(c.x, ry, c.w, ROWH, [C.panel[0], C.panel[1], C.panel[2], 0.45]);
        var nameC = on ? C.black : (off ? C.dim : C.txt);
        var dateTxt = off ? "OFFLINE" : (m && m[0] ? ago(m[0]) : "");
        var dateW = 46, dateX = c.x + c.w - 14;
        if (dateTxt) { font(SUBF - 1, off); text(dateTxt, dateX, ry + ROWH / 2 + SUBF * 0.34, on ? C.black : (off ? C.hi : C.dim), "r"); }
        font(SUBF, it.def);
        var subMax = c.w * 0.3, subW = it.sub ? Math.min(tw(it.sub) + 2, subMax) : 0;
        if (it.sub) { font(SUBF, it.def); text(fit(it.sub, subMax), dateX - dateW - 4, ry + ROWH / 2 + SUBF * 0.34, on ? C.black : (it.def ? C.hi : C.dim), "r"); }
        font(NAMEF, it.def || on);
        text(fit(it.name, c.w - subW - dateW - 38), c.x + 10, ry + ROWH / 2 + NAMEF * 0.34, nameC);
        var hy = Math.max(ry, y0), hb = Math.min(ry + ROWH, y0 + lh);
        if (hb - hy > 8) hit(c.x, hy, c.w - 8, hb - hy, (function (id, item) { return function () { pick(id, item); }; })(c.id, it));
    }
    // 위/아래로 삐져나온 행 가리기 + 헤더
    rect(c.x, TOP - 8, c.w, HEAD + 8, C.bg);
    rect(c.x, H - BOT, c.w, BOT, C.bg);
    rect(c.x, TOP, c.w, HEAD - 4, C.panel);
    font(11, true); text(c.title, c.x + 10, TOP + 18, C.txt);
    font(10, false); text(FILTER.length ? (n + "/" + total) : String(total), c.x + c.w - 10, TOP + 18, C.dim, "r");
    if (scrollMax[c.id] > 0) { var sh = lh * lh / (lh + scrollMax[c.id]); rect(c.x + c.w - 6, y0 + (lh - sh) * scroll[c.id] / scrollMax[c.id], 4, sh, C.dim); }
}

// ---------- actions ----------
function pick(id, item) {
    var now = new Date().getTime();
    var dbl = lastClick.col === id && lastClick.path === item.path && now - lastClick.t < 450;
    lastClick = { t: now, col: id, path: item.path };
    sel = { col: id, path: item.path };
    if (dbl) openSel();
}
// 최근 세트 = 그대로 열기 / 템플릿 = 복사본으로 새 프로젝트 (원본 보호)
function openSel() {
    var it = selItem(); if (!it) return;
    if (sel.col === "tpl") { statusTxt = "creating new project from " + it.name + " ..."; cmd("newfrom", encodeURIComponent(it.path)); }
    else { statusTxt = "opening " + it.name + " ..."; cmd("openset", encodeURIComponent(it.path)); }
}
function openOrig() {
    var it = selItem(); if (!it) return;
    statusTxt = "opening template itself: " + it.name + " ...";
    cmd("openset", encodeURIComponent(it.path));
}
function revealSel() {
    var it = selItem(); if (!it) { statusTxt = "select a row first"; return; }
    cmd("revealset", encodeURIComponent(it.path));
}

// ---------- mouse ----------
function onclick(x, y, but, cmdk, shift) {
    for (var i = hits.length - 1; i >= 0; i--) {
        var h = hits[i];
        if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) { h.fn(); mgraphics.redraw(); return; }
    }
}
onclick.local = 1;
function onwheel(x, y, wx, wy) {
    for (var i = 0; i < COLS.length; i++) {
        var c = COLS[i];
        if (x >= c.x && x <= c.x + c.w) { scroll[c.id] = Math.max(0, Math.min(scrollMax[c.id], scroll[c.id] - wy * 30)); mgraphics.redraw(); return; }
    }
}
onwheel.local = 1;
function bang() { mgraphics.redraw(); }

// 디바이스 뷰: 로드 직후 엔진과 동기화
if (!WIN) { var bootTask = new Task(function () { cmd("init"); }, this); bootTask.schedule(700); }
