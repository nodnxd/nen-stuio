// HUB — engine (classic js, ES5)  v1.4
// 에이블톤이 직접 저장해둔 파일에서 Recent / Templates를 긁어오고, 선택한 세트를 연다.
//  - Recent   : ~/Library/Preferences/Ableton/Live x.y.z/Preferences.cfg (RecentDocs) + 이번 실행의 Log.txt
//  - Templates: User Library/Templates/*.als + Library.cfg의 DefaultTemplateSet
// 출력 outlet 0: "recent <enc>", "templates <enc>", "status <enc>"  (enc = encodeURIComponent(JSON)) → [s ---hub_data]
//      outlet 1: "open"     → pcontrol (플로팅 창 열기)
//      outlet 2: "showwin"  → 창 패치 (창 플래그 세팅)
//      outlet 3: "bang"     → [opendialog fold] (새 프로젝트 저장 폴더 고르기)
// 입력: init / rescan / openwin / openset / newfrom / revealset / openurl / chooseroot / setroot
// 새 세트(= 기본 템플릿 로드)로 시작하면 init 1.5초 뒤 창을 자동으로 띄운다.
autowatch = 1; inlets = 1; outlets = 5;

var PAT = this.patcher;
var MAXREC = 25;
var LIVE = null, TPLDIR = "", bootTask = null, frontTask = null, autoDone = false;
var VERSION = "1.8.1";
var ROOT = "", LISTED = [], metaTask = null, PENDING = "", settingsLoaded = false;

function log(s) { post("[HUB] " + s + "\n"); }
function status(s) { log(s); var e = encodeURIComponent(String(s)); if (typeof CACHE != "undefined") CACHE.status = e; outlet(0, "status", e); }
function posix(p) { return String(p || "").replace(/^[^\/]*:/, ""); }
function fexists(p) { try { var f = new File(p, "read"); var ok = f.isopen; f.close(); return !!ok; } catch (e) { return false; } }

function readBytes(p, tail) {
    try {
        var f = new File(p, "read");
        if (!f.isopen) return null;
        var total = f.eof, start = (tail && total > tail) ? total - tail : 0, n = total - start, out = new Array(n), k = 0, got, i;
        f.position = start;
        while (k < n) {
            got = f.readbytes(Math.min(16384, n - k));
            if (typeof got == "number") got = [got];
            if (!got || !got.length) break;
            for (i = 0; i < got.length; i++) out[k++] = got[i];
        }
        f.close();
        out.length = k;
        return out;
    } catch (e) { log("read ERR " + p + ": " + e); return null; }
}

function utf8(b) {
    var parts = [], i = 0, n = b.length, c, cp, chunk = [];
    while (i < n) {
        c = b[i++];
        if (c < 0x80) cp = c;
        else if (c >= 0xC0 && c < 0xE0 && i < n) cp = ((c & 0x1F) << 6) | (b[i++] & 0x3F);
        else if (c >= 0xE0 && c < 0xF0 && i + 1 < n) { cp = ((c & 0x0F) << 12) | ((b[i] & 0x3F) << 6) | (b[i + 1] & 0x3F); i += 2; }
        else if (c >= 0xF0 && i + 2 < n) { cp = ((c & 0x07) << 18) | ((b[i] & 0x3F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F); i += 3; }
        else cp = 0xFFFD;
        if (cp > 0xFFFF) { cp -= 0x10000; chunk.push(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)); }
        else chunk.push(cp);
        if (chunk.length >= 4096) { parts.push(String.fromCharCode.apply(null, chunk)); chunk = []; }
    }
    if (chunk.length) parts.push(String.fromCharCode.apply(null, chunk));
    return parts.join("");
}

function unxml(s) { return s.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&"); }

function modTime(f) {
    try { var m = f.moddate; if (m && m.length >= 6) return new Date(m[0], m[1] - 1, m[2], m[3], m[4], m[5]).getTime(); } catch (e) {}
    return 0;
}
function mtimeIn(dir, fname) {
    var t = 0;
    try { var f = new Folder(dir); while (!f.end) { if (f.filename == fname) { t = modTime(f); break; } f.next(); } f.close(); } catch (e) {}
    return t;
}
function listDirs(dir) {
    var out = [];
    try { var f = new Folder(dir); while (!f.end) { if (f.filetype == "fold") out.push(f.filename); f.next(); } f.close(); } catch (e) {}
    return out;
}
function scanDir(dir, depth, out) {
    var f = new Folder(dir);
    while (!f.end) {
        var name = f.filename;
        if (f.filetype == "fold") {
            if (depth > 0 && name.toLowerCase() != "backup") scanDir(dir + "/" + name, depth - 1, out);
        } else if (/\.als$/i.test(name)) {
            out.push(dir + "/" + name);
        }
        f.next();
    }
    f.close();
}

function findHome() {
    var m = posix(PAT.filepath).match(/^(\/Users\/[^\/]+)\//);
    if (m) return m[1];
    var c = [], d = listDirs("/Users");
    for (var i = 0; i < d.length; i++) if (d[i] != "Shared" && d[i] != "Guest" && d[i].charAt(0) != ".") c.push(d[i]);
    return c.length == 1 ? "/Users/" + c[0] : "";
}

// 지금 돌아가는(= Log.txt가 가장 최근인) 라이브 버전의 설정 폴더
function pickLive(home) {
    var base = home + "/Library/Preferences/Ableton", names = listDirs(base), best = null, bt = -1;
    for (var i = 0; i < names.length; i++) {
        if (!/^Live \d+(\.\d+)*$/.test(names[i])) continue;
        var d = base + "/" + names[i];
        var t = mtimeIn(d, "Log.txt") || mtimeIn(d, "Preferences.cfg");
        if (t > bt) { bt = t; best = { dir: d, name: names[i] }; }
    }
    return best;
}

// Preferences.cfg 안의 RecentDocsList 뒤 UTF-16LE 경로들 (저장 순서 = 최근 순). 필요한 개수만 모으고 멈춘다.
function prefsRecents(prefPath, want) {
    var b = readBytes(prefPath);
    if (!b) return [];
    var n = b.length, key = "RecentDocsList", base = 0, i, j, out = [], seen = {};
    for (i = 0; i + key.length <= n; i++) {
        if (b[i] != 82) continue; // 'R'
        for (j = 1; j < key.length; j++) if (b[i + j] != key.charCodeAt(j)) break;
        if (j == key.length) base = i;          // 마지막 RecentDocsList
    }
    for (i = base; i + 8 <= n && out.length < want; i++) {
        // ".als" = 2e 00 61 00 6c 00 73 00
        if (b[i] != 0x2e || b[i + 1] != 0 || b[i + 2] != 0x61 || b[i + 3] != 0 || b[i + 4] != 0x6c || b[i + 5] != 0 || b[i + 6] != 0x73 || b[i + 7] != 0) continue;
        var k = i, cu = [];
        while (k >= 2 && cu.length < 1024) {
            var c = b[k - 2] | (b[k - 1] << 8);
            if (c == 0) break;
            cu.push(c); k -= 2;
        }
        cu.reverse();
        var str = String.fromCharCode.apply(null, cu), sl = str.indexOf("/");
        if (sl >= 0) {
            str = str.substring(sl) + ".als";
            if (!seen[str]) { seen[str] = 1; out.push(str); }
        }
        i += 7;
    }
    return out;
}

// 이번 실행에서 연 세트 (새것 먼저)
var LOGTAIL = 131072;
function isAux(p) { return /\/User Library\/Defaults\//.test(p); }   // 트랙 생성 시 로드되는 Default Audio/MIDI Track.als
function logLoads(logPath) {
    var b = readBytes(logPath, LOGTAIL);
    if (!b) return [];
    var txt = utf8(b), re = /Loading document "([^"]+\.als)"/g, m, out = [];
    while ((m = re.exec(txt))) if (!isAux(m[1])) out.push(m[1]);
    out.reverse();
    LASTLOADS = out.slice(0);
    return out;
}

function uniq(list) {
    var seen = {}, out = [];
    for (var i = 0; i < list.length; i++) if (!seen[list[i]]) { seen[list[i]] = 1; out.push(list[i]); }
    return out;
}

var CACHE = {}, scannedAt = 0, LASTLOADS = null;
function send(sel, obj, listKey) {
    var s = encodeURIComponent(JSON.stringify(obj));
    var arr = listKey ? obj[listKey] : obj;
    while (s.length > 28000 && arr.length > 1) { arr.pop(); s = encodeURIComponent(JSON.stringify(obj)); }
    CACHE[sel] = s;
    outlet(0, sel, s);
}
function resend() {
    if (CACHE.templates) outlet(0, "templates", CACHE.templates);
    if (CACHE.recent) outlet(0, "recent", CACHE.recent);
    resendBig("folders");
    outlet(0, "lefttab", LEFTTAB); outlet(0, "foldsort", FSORT);
    if (CACHE.root !== undefined) outlet(0, "root", CACHE.root);
    if (CACHE.meta) outlet(0, "meta", CACHE.meta);
    if (CACHE.pins) outlet(0, "pins", CACHE.pins);
    outlet(0, "theme", THEME);
    if (CACHE.status) outlet(0, "status", CACHE.status);
    if (HUBUPD) outlet(0, "hubupd", HUBUPD.v, encodeURIComponent(HUBUPD.url));
    if (CACHE.nen !== undefined) outlet(0, "nen", CACHE.nen || "none");
}

// ---------- 경로 도우미 ----------
function dirname(p) { return String(p).replace(/\/[^\/]*$/, ""); }
function basename(p) { return String(p).substring(String(p).lastIndexOf("/") + 1); }
function dirExists(d) { try { var f = new Folder(d); var ok = !f.end; f.close(); return ok; } catch (e) { return false; } }
// Max의 HFS 스타일 경로("Macintosh HD:/Users/.." / "NOD_4TB:/..")를 POSIX로. 부팅 디스크가 아니면 /Volumes/<이름>
var BOOTTOP = { Users: 1, Applications: 1, Library: 1, System: 1, Volumes: 1, "private": 1, opt: 1, usr: 1, tmp: 1 };
function hfsToPosix(p) {
    p = String(p || "");
    var m = p.match(/^([^:\/]+):(\/.*)$/);
    if (!m) return p;
    var top = m[2].split("/")[1];
    return BOOTTOP[top] ? m[2] : "/Volumes/" + m[1] + m[2];
}
function yymmdd() {
    var d = new Date(), z = function (n) { return (n < 10 ? "0" : "") + n; };
    return String(d.getFullYear()).slice(2) + z(d.getMonth() + 1) + z(d.getDate());
}

// ---------- 설정 (새 프로젝트 저장 폴더) : 디바이스 옆 hub_settings.txt 첫 줄 ----------
var USERLIB = "", SKIPVER = "", PINS = [], THEME = "dark", FOLDERS = [], LEFTTAB = "recent", DLGMODE = "root", FSORT = "date";     // PINS: 즐겨찾기(★) 세트 경로
function settingsPath() { return (USERLIB || dirname(posix(PAT.filepath))) + "/hub_settings.txt"; }
function loadSettings() {
    if (settingsLoaded) return;
    settingsLoaded = true;
    try {
        var b = readBytes(settingsPath());
        if (b && b.length) {
            var lines = utf8(b).split(/[\r\n]+/);
            ROOT = (lines[0] || "").replace(/^\s+|\s+$/g, "");
            PINS = []; FOLDERS = [];
            for (var li = 1; li < lines.length; li++) {
                var sm = lines[li].match(/^skip=(.+)$/); if (sm) SKIPVER = sm[1].replace(/\s+$/, "");
                var pm = lines[li].match(/^pin=(.+)$/); if (pm) PINS.push(pm[1].replace(/\s+$/, ""));
                var tm = lines[li].match(/^theme=(light|dark)/); if (tm) THEME = tm[1];
                var fm = lines[li].match(/^folder=(.+)$/), fp = fm ? fm[1].replace(/[\r\n]+$/, "") : ""; if (fp && !hasFolder(fp)) FOLDERS.push(fp);   // 폴더 이름 끝 공백 유지
                var tb = lines[li].match(/^tab=(recent|fold)/); if (tb) LEFTTAB = tb[1];
                var fs = lines[li].match(/^fsort=(-?(?:date|name))/); if (fs) FSORT = fs[1];
            }
        }
    } catch (e) { log("settings read ERR " + e); }
}
function saveSettings() {
    try {
        var f = new File(settingsPath(), "write", "TEXT");
        if (f.isopen) { try { f.eof = 0; f.position = 0; } catch (e1) {} f.writestring(ROOT + "\n" + (SKIPVER ? "skip=" + SKIPVER + "\n" : "") + "theme=" + THEME + "\n" + "tab=" + LEFTTAB + "\n" + "fsort=" + FSORT + "\n" + PINS.map(function (p) { return "pin=" + p + "\n"; }).join("") + FOLDERS.map(function (p) { return "folder=" + p + "\n"; }).join("")); f.close(); }
        else log("settings not writable: " + settingsPath());
    } catch (e) { log("settings write ERR " + e); }
}
// ---------- 즐겨찾기(★): 최근 25개에서 밀려나도 RECENT 맨 위에 남는다 ----------
// ---------- 라이트/다크 (오른쪽 패널과 같은 NEN 색) ----------
function theme(m) {
    m = String(m) === "light" ? "light" : "dark";
    var changed = m !== THEME; THEME = m; CACHE.theme = m;
    if (changed) saveSettings();
    outlet(0, "theme", m);
}
function sendPins() { var e = encodeURIComponent(JSON.stringify(PINS)); CACHE.pins = e; outlet(0, "pins", e); }
function pin(enc) {
    var p = ""; try { p = decodeURIComponent(String(enc)); } catch (x) { return; }
    if (!p) return;
    var i = PINS.indexOf(p);
    if (i >= 0) PINS.splice(i, 1); else { PINS.unshift(p); if (LISTED.indexOf(p) < 0) LISTED.push(p); }
    saveSettings(); sendPins();
    if (metaTask) metaTask.schedule(50);
}
function sendRoot() { var e = encodeURIComponent(ROOT); CACHE.root = e; outlet(0, "root", e); }
function chooseroot() { DLGMODE = "root"; outlet(3, "bang"); }
function setroot() {
    var raw = Array.prototype.slice.call(arguments).join(" ");
    var mode = DLGMODE; DLGMODE = "root";
    if (!raw) return;                                // 대화상자 취소
    var p = hfsToPosix(raw).replace(/\/+$/, "");
    if (mode === "folder") { addFolderPath(p); return; }
    ROOT = p; saveSettings(); sendRoot();
    log("setroot raw=[" + raw + "] -> " + p);
    status("new projects -> " + p);
    if (PENDING) { var t = PENDING; PENDING = ""; newfrom(encodeURIComponent(t)); }
}

// ---------- FOLDERS 탭 (v1.8.1): 사용자가 추가한 프로젝트 폴더 안의 세트 전부, 최신순 ----------
var FOLDSKIP = /^(backup|samples|ableton project info|presets|_to_delete|\..*)$/i, MAXFOLD = 400;
function addfolder() { DLGMODE = "folder"; outlet(3, "bang"); }
function hasFolder(p) { for (var i = 0; i < FOLDERS.length; i++) if (rootKey(FOLDERS[i]) === rootKey(p)) return true; return false; }
function addFolderPath(p) {
    if (!p) return;
    if (hasFolder(p)) { LEFTTAB = "fold"; outlet(0, "lefttab", LEFTTAB); status("already in FOLDERS: " + p); return; }
    FOLDERS.push(p);
    LEFTTAB = "fold"; saveSettings(); outlet(0, "lefttab", LEFTTAB);
    status("folder added: " + p); rescan();
}
function delfolder(enc) {
    var p = ""; try { p = decodeURIComponent(String(enc)); } catch (x) { return; }
    var i = FOLDERS.indexOf(p); if (i < 0) return;
    FOLDERS.splice(i, 1); saveSettings(); rescan();
}
function foldsort(v) { v = String(v); FSORT = /^-?(date|name)$/.test(v) ? v : "date"; saveSettings(); }
function lefttab(v) { LEFTTAB = String(v) === "fold" ? "fold" : "recent"; saveSettings(); CACHE.lefttab = LEFTTAB; }
// 트리: { n:이름(루트는 전체 경로), k:[하위 폴더], s:[[파일 상대이름, mtime], ...], t:가장 최근, c:세트 수 }
// "X Project" 폴더는 펼치지 않고 그 안의 .als를 부모 폴더의 세트로 붙인다 ("X Project/X.als")
var PROJRE = / Project(-\d+)?$/i, FOLDCNT = 0, MAXSETS = 12000;
// 외장 디스크: Max의 Folder가 "/Volumes/X/.." 를 못 읽으면 "X:/.." 로 다시 시도
var VOLMODE = {};     // 외장 디스크마다 POSIX 경로가 통하는지 한 번만 확인
function openFolder(dir) {
    var f = null, m = String(dir).match(/^\/Volumes\/([^\/]+)(\/.*)?$/), vm = m ? VOLMODE[m[1]] : "";
    if (vm !== "hfs") { try { f = new Folder(dir); if (!f.end) { if (m) VOLMODE[m[1]] = "posix"; return f; } f.close(); } catch (e) {} }
    if (m && vm !== "posix") { try { var g = new Folder(m[1] + ":" + (m[2] || "/")); if (!g.end) { VOLMODE[m[1]] = "hfs"; return g; } g.close(); } catch (e2) {} }
    return null;
}
// 저장된 경로가 실제 이름과 공백 등으로 어긋나면 부모 폴더를 훑어 진짜 이름을 찾는다 ("_ Ableton Projects " 처럼 끝에 공백)
function fixDir(d) {
    if (openFolder(d)) return d;
    var i = d.lastIndexOf("/"); if (i <= 0) return d;
    var par = fixDir(d.substring(0, i)), want = d.substring(i + 1).replace(/^\s+|\s+$/g, "").toLowerCase();
    var f = openFolder(par); if (!f) return d;
    var hit = "";
    while (!f.end) { if (f.filetype == "fold" && String(f.filename).replace(/^\s+|\s+$/g, "").toLowerCase() == want) { hit = par + "/" + f.filename; break; } f.next(); }
    f.close();
    return hit || d;
}
function dirOk(d) { var f = openFolder(d); if (!f) return false; f.close(); return true; }
var FOLDERR = "";
function scanProj(dir, rel, node, budget) {
    try {
        var f = openFolder(dir); if (!f) return;
        while (!f.end && budget.n > 0) {
            budget.n--;
            var name = f.filename;
            if (f.filetype != "fold" && /\.als$/i.test(name) && name.charAt(0) != "." && FOLDCNT < MAXSETS) { node.s.push([rel + "/" + name, modTime(f)]); FOLDCNT++; }
            f.next();
        }
        f.close();
    } catch (e) {}
}
function scanTree(dir, name, depth, budget) {
    var node = { n: name, k: [], s: [], t: 0, c: 0 }, subs = [];
    try {
        var f = openFolder(dir); if (!f) { if (depth === 6) FOLDERR = "can't read " + dir; return node; }
        while (!f.end && budget.n > 0) {
            budget.n--;
            var nm = f.filename;
            if (f.filetype == "fold") { if (!FOLDSKIP.test(nm)) subs.push(nm); }
            else if (/\.als$/i.test(nm) && nm.charAt(0) != "." && FOLDCNT < MAXSETS) { node.s.push([nm, modTime(f)]); FOLDCNT++; }
            f.next();
        }
        f.close();
    } catch (e) {}
    for (var i = 0; i < subs.length; i++) {
        var sp = dir + "/" + subs[i];
        if (TPLDIR && (sp == TPLDIR || sp.indexOf(TPLDIR + "/") == 0)) continue;
        if (depth <= 0) { if (PROJRE.test(subs[i])) scanProj(sp, subs[i], node, budget); continue; }
        var ch = scanTree(sp, subs[i], depth - 1, budget);
        if (!ch.c) continue;
        if (PROJRE.test(subs[i]) && !ch.k.length) { for (var j = 0; j < ch.s.length; j++) node.s.push([subs[i] + "/" + ch.s[j][0], ch.s[j][1]]); }   // "X Project" (하위 폴더 없음) = 세트를 부모에 바로
        else node.k.push(ch);
    }
    node.s.sort(function (a, b) { return b[1] - a[1]; });
    node.k.sort(function (a, b) { return b.t - a.t; });
    node.c = node.s.length; node.t = node.s.length ? node.s[0][1] : 0;
    for (i = 0; i < node.k.length; i++) { node.c += node.k[i].c; if (node.k[i].t > node.t) node.t = node.k[i].t; }
    return node;
}
function scanFolders() {
    var out = [], budget = { n: 40000 }, i;
    FOLDCNT = 0; FOLDERR = "";
    for (i = 0; i < FOLDERS.length; i++) {
        var d = FOLDERS[i];
        if (d.indexOf("/Volumes/") == 0 && !dirOk(d.split("/").slice(0, 3).join("/"))) { out.push({ n: d, k: [], s: [], t: 0, c: 0, off: 1 }); continue; }   // 꺼진 외장 디스크
        var rd = fixDir(d.replace(/\/+$/, ""));
        out.push(scanTree(rd, rd, 6, budget));
    }
    if (budget.n <= 0) log("folders: stopped after 40000 entries");
    log("folders: " + FOLDCNT + " sets" + (FOLDERR ? " / " + FOLDERR : ""));
    return out;
}
// ---------- 폴더 스캔은 뒤에서 조금씩 (로드를 막지 않게) + 지난 결과 캐시 ----------
// 켜질 때: hub_folders.txt(지난 결과)를 바로 보내고, 몇 초 뒤 실제 스캔을 8 ms씩 나눠서 돈다.
var FSCAN = null, fscanTask = null, FSTATUS = null;
function folderCachePath() { return (USERLIB || dirname(posix(PAT.filepath))) + "/hub_folders.txt"; }
function loadFolderCache() {
    try {
        var b = readBytes(folderCachePath()); if (!b || !b.length) return null;
        var o = JSON.parse(decodeURIComponent(utf8(b)));
        if (!o || !o.tree) return null;
        return o;
    } catch (e) { return null; }
}
function saveFolderCache(tree, n) {
    try {
        var s = encodeURIComponent(JSON.stringify({ dirs: FOLDERS, tree: tree, n: n }));
        var f = new File(folderCachePath(), "write", "TEXT");
        if (!f.isopen) return;
        try { f.eof = 0; f.position = 0; } catch (e1) {}
        for (var i = 0; i < s.length; i += 16000) f.writestring(s.substring(i, i + 16000));
        f.close();
    } catch (e) { log("folder cache write ERR " + e); }
}
function rootKey(p) { return String(p).replace(/\/+$/, "").replace(/^\s+|\s+$/g, "").toLowerCase(); }
// 캐시에서 지금 폴더 목록에 맞는 것만 골라 보여준다. 없는(새로 추가한) 폴더는 "읽는 중"
function cachedView(fc) {
    var by = {}, out = [], n = 0, i;
    var tr = (fc && fc.tree) || [];
    for (i = 0; i < tr.length; i++) by[rootKey(tr[i].n)] = tr[i];
    for (i = 0; i < FOLDERS.length; i++) {
        var r = by[rootKey(FOLDERS[i])];
        if (r && !r.off) { out.push(r); n += r.c || 0; } else out.push({ n: FOLDERS[i].replace(/\/+$/, ""), k: [], s: [], t: 0, c: 0, loading: 1 });
    }
    return { tree: out, n: n };
}
var FSIG = "";
function startFolderScan(delay) {
    var sig = JSON.stringify(FOLDERS);
    if (FSCAN && FSIG === sig) return;          // 같은 폴더 목록을 이미 훑는 중이면 그대로 둔다 (창 열 때마다 처음부터 다시 하지 않게)
    FSIG = sig;
    if (fscanTask) fscanTask.cancel();
    FSCAN = null;
    if (!FOLDERS.length) { FOLDCNT = 0; FOLDERR = ""; sendBig("folders", { dirs: FOLDERS, tree: [] }); return; }
    fscanTask = new Task(folderStep, this); fscanTask.interval = 4;
    FSCAN = { pending: true };
    var t = new Task(function () { beginFolderScan(); fscanTask.repeat(); }, this); t.schedule(delay || 0);
    FSCAN.starter = t;
}
function beginFolderScan() {
    var roots = [], q = [];
    FOLDCNT = 0; FOLDERR = "";
    for (var i = 0; i < FOLDERS.length; i++) {
        var d = FOLDERS[i];
        if (d.indexOf("/Volumes/") == 0 && !dirOk(d.split("/").slice(0, 3).join("/"))) { roots.push({ n: d, k: [], s: [], t: 0, c: 0, off: 1 }); continue; }   // 꺼진 외장 디스크
        var rd = fixDir(d.replace(/\/+$/, ""));
        var r = { n: rd, k: [], s: [], t: 0, c: 0, dir: rd, depth: 6, root: 1 };
        roots.push(r); q.push(r);
    }
    FSCAN = { roots: roots, q: q, n: 200000, t0: new Date().getTime() };
}
function folderDir(it) {
    var f = openFolder(it.dir);
    if (!f) { if (it.root) FOLDERR = "can't read " + it.dir; return; }
    while (!f.end && FSCAN.n > 0) {
        FSCAN.n--;
        var nm = f.filename;
        if (f.filetype == "fold") {
            if (it.depth > 0 || (it.depth === 0 && PROJRE.test(nm))) {
                if (!FOLDSKIP.test(nm)) {
                    var sp = it.dir + "/" + nm;
                    if (!(TPLDIR && (sp == TPLDIR || sp.indexOf(TPLDIR + "/") == 0))) { var ch = { n: nm, k: [], s: [], t: 0, c: 0, dir: sp, depth: it.depth - 1 }; it.k.push(ch); FSCAN.q.push(ch); }
                }
            }
        } else if (/\.als$/i.test(nm) && nm.charAt(0) != "." && FOLDCNT < MAXSETS) { it.s.push([nm, modTime(f)]); FOLDCNT++; }
        f.next();
    }
    f.close();
}
function folderFinish(node) {
    var k = [], i, j;
    for (i = 0; i < node.k.length; i++) {
        var ch = node.k[i]; folderFinish(ch);
        if (!ch.c) continue;
        if (PROJRE.test(ch.n) && !ch.k.length) { for (j = 0; j < ch.s.length; j++) node.s.push([ch.n + "/" + ch.s[j][0], ch.s[j][1]]); }   // "X Project" = 세트를 부모에 바로
        else k.push(ch);
    }
    node.k = k;
    node.s.sort(function (a, b) { return b[1] - a[1]; });
    node.k.sort(function (a, b) { return b.t - a.t; });
    node.c = node.s.length; node.t = node.s.length ? node.s[0][1] : 0;
    for (i = 0; i < node.k.length; i++) { node.c += node.k[i].c; if (node.k[i].t > node.t) node.t = node.k[i].t; }
    delete node.dir; delete node.depth; delete node.root;
}
function folderStep() {
    if (!FSCAN || !FSCAN.q) return;
    var t0 = new Date().getTime();
    try {
        while (FSCAN.q.length && FSCAN.n > 0 && new Date().getTime() - t0 < 14) folderDir(FSCAN.q.shift());
    } catch (e) { log("folders ERR " + e); FSCAN.q = []; }
    if (FSCAN.q.length && FSCAN.n > 0) return;
    fscanTask.cancel();
    var roots = FSCAN.roots;
    for (var i = 0; i < roots.length; i++) if (!roots[i].off) folderFinish(roots[i]);
    log("folders: " + FOLDCNT + " sets in " + (new Date().getTime() - FSCAN.t0) + " ms" + (FOLDERR ? " / " + FOLDERR : ""));
    FSCAN = null;
    sendBig("folders", { dirs: FOLDERS, tree: roots });
    saveFolderCache(roots, FOLDCNT);
    if (FSTATUS) FSTATUS();
}

// 큰 데이터는 조각으로 (Max 메시지 한 개 한도). 숫자로 읽히지 않게 앞에 x
function sendBig(sel, obj) {
    var s = encodeURIComponent(JSON.stringify(obj)), n = Math.max(1, Math.ceil(s.length / 20000)), parts = [];
    for (var i = 0; i < n; i++) parts.push("x" + s.substring(i * 20000, (i + 1) * 20000));
    CACHE["big_" + sel] = parts;
    for (i = 0; i < n; i++) outlet(0, "chunk", sel, i, n, parts[i]);
}
function resendBig(sel) { var parts = CACHE["big_" + sel]; if (!parts) return; for (var i = 0; i < parts.length; i++) outlet(0, "chunk", sel, i, parts.length, parts[i]); }

// ---------- 날짜 / 외장 디스크 상태 (리스트를 먼저 보낸 뒤 따로 계산해서 보낸다) ----------
function listMtimes(d) {
    var out = {};
    try { var f = new Folder(d); while (!f.end) { if (/\.als$/i.test(f.filename)) out[f.filename] = modTime(f); f.next(); } f.close(); } catch (e) {}
    return out;
}
function computeMeta() {
    try {
        var res = {}, dirs = {}, mounted = {}, i, p, off, t, d, root;
        for (i = 0; i < LISTED.length; i++) {
            p = LISTED[i]; off = false; t = 0;
            if (p.indexOf("/Volumes/") == 0) {
                root = p.split("/").slice(0, 3).join("/");
                if (mounted[root] === undefined) mounted[root] = dirExists(root);
                off = !mounted[root];
            }
            var miss = false;
            if (!off) { d = dirname(p); if (!dirs[d]) dirs[d] = listMtimes(d); t = dirs[d][basename(p)] || 0; miss = !t && !fexists(p); }
            res[p] = [t, off ? 1 : (miss ? 2 : 0)];     // 2 = 파일이 없어짐 (★ 고정해둔 세트를 지웠거나 옮김)
        }
        send("meta", res, null);
    } catch (e) { log("meta ERR " + e); }
}

// 저장해 둔 폴더가 없으면: 가장 최근 프로젝트가 들어 있는 폴더의 상위 폴더를 기본값으로 (창에서 CHANGE로 바꾸면 그걸 저장)
function autoRoot(rec) {
    for (var i = 0; i < rec.length; i++) {
        var d = dirname(rec[i]);
        if (/ Project(-\d+)?$/.test(basename(d)) || basename(d) == "Project") d = dirname(d);
        if (!d || /\/Backup(\/|$)/.test(d)) continue;
        if (rec[i].indexOf("/Volumes/") == 0 && !dirExists(rec[i].split("/").slice(0, 3).join("/"))) continue;
        if (dirExists(d)) return d;
    }
    return "";
}

// ---------- 템플릿 → 새 프로젝트 (복사본을 만들어서 연다. 원본은 건드리지 않음) ----------
function newfrom(enc) {
    var src;
    try { src = decodeURIComponent(String(enc)); } catch (e) { status("bad path"); return; }
    if (!fexists(src)) { status("template not found"); return; }
    loadSettings();
    if (!ROOT) { PENDING = src; status("choose a folder for new projects"); chooseroot(); return; }
    var base = basename(src).replace(/\.als$/i, ""), name = base + " " + yymmdd(), dest = ROOT + "/" + name + ".als", n = 2;
    while (fexists(dest) && n < 100) { dest = ROOT + "/" + name + " " + n + ".als"; n++; }
    var data = readBytes(src);
    if (!data || !data.length) { status("could not read template"); return; }
    try {
        var f = new File(dest, "write", "TEXT");
        if (!f.isopen) { status("cannot write: " + dest); return; }
        for (var i = 0; i < data.length; i += 16384) f.writebytes(data.slice(i, i + 16384));
        f.close();
    } catch (e) { status("copy failed: " + e); return; }
    var chk = null;
    try { chk = new File(dest, "read"); var sz = chk.isopen ? chk.eof : -1; chk.close(); if (sz !== data.length) { status("copy failed (size " + sz + " of " + data.length + ")"); return; } }
    catch (e2) { status("copy check failed: " + e2); return; }
    log("new project: " + dest);
    openset(encodeURIComponent(dest));
}

// ---------- Finder에서 보기 ----------
function revealset(enc) {
    var p;
    try { p = decodeURIComponent(String(enc)); } catch (e) { return; }
    var d = dirname(p);
    if (!dirExists(d)) { status("folder not found (disk offline?)"); return; }
    try { max.launchbrowser(toFileUrl(d)); } catch (e2) { status("reveal failed: " + e2); }
}

function scan() {
    var home = findHome();
    if (!home) { status("home folder not found"); return; }
    var live = pickLive(home);
    LIVE = live;
    var def = "", userLib = "";
    if (live) {
        var lb = readBytes(live.dir + "/Library.cfg");
        if (lb) { var mm = utf8(lb).match(/<DefaultTemplateSet Value="([^"]*)"/); if (mm) def = unxml(mm[1]); }
    }
    var ul = def.match(/^(.*\/User Library)\//);
    if (ul) userLib = ul[1];
    else { var pm = posix(PAT.filepath).match(/^(.*\/User Library)\//); userLib = pm ? pm[1] : home + "/Music/Ableton/User Library"; }
    USERLIB = userLib; settingsLoaded = false; loadSettings();
    var tplDir = userLib + "/Templates";
    TPLDIR = tplDir;

    // templates
    var tpls = [];
    try { scanDir(tplDir, 2, tpls); } catch (e) { log("templates scan ERR " + e); }
    tpls = uniq(tpls).filter(function (p) { return p != def; });
    tpls.sort(function (a, b) { return a.toLowerCase() < b.toLowerCase() ? -1 : 1; });
    var defOk = def && fexists(def) ? def : "";
    send("templates", { def: defOk, list: tpls }, "list");

    // recent
    var rec = [];
    if (live) {
        LASTLOADS = null;
        rec = logLoads(live.dir + "/Log.txt").concat(prefsRecents(live.dir + "/Preferences.cfg", MAXREC * 3));
    }
    rec = uniq(rec).filter(function (p) {
        if (p.indexOf(tplDir + "/") == 0) return false;
        if (/\/Backup\//.test(p)) return false;
        if (isAux(p)) return false;
        if (p.indexOf("/Volumes/") == 0) return true;
        return fexists(p);
    }).slice(0, MAXREC);
    send("recent", rec, "");
    var fc = loadFolderCache(), cv = cachedView(fc);
    if (!FSCAN || FSIG !== JSON.stringify(FOLDERS)) { FOLDCNT = cv.n; FOLDERR = ""; sendBig("folders", { dirs: FOLDERS, tree: cv.tree }); }
    startFolderScan(scannedAt ? 200 : 4000);        // 처음 켤 때는 저장된 목록을 먼저 보여주고 4초 뒤 새로 훑음        // 처음 켤 때는 캐시를 먼저 보여주고 4초 뒤 새로 훑음
    CACHE.lefttab = LEFTTAB; outlet(0, "lefttab", LEFTTAB); outlet(0, "foldsort", FSORT);
    LISTED = rec.concat(tpls, defOk ? [defOk] : [], PINS);
    sendPins(); outlet(0, "theme", THEME);
    if (!ROOT) { ROOT = autoRoot(rec); if (ROOT) log("default new-project folder: " + ROOT); }
    sendRoot();
    if (!metaTask) metaTask = new Task(computeMeta, this);
    metaTask.schedule(80);

    FSTATUS = function () { status("v" + VERSION + " · " + rec.length + " recent · " + (FOLDERS.length ? (FSCAN ? (FOLDCNT ? FOLDCNT + " in folders (updating)" : "reading folders...") : FOLDCNT + " in folders" + (FOLDERR ? " (" + FOLDERR + ")" : "")) + " · " : "") + (tpls.length + (defOk ? 1 : 0)) + " templates" + (live ? " · " + live.name : " · live prefs not found")); };
    FSTATUS();
}

function init() {
    if (scannedAt) { resend(); return; }           // UI가 늦게 붙어도 다시 스캔하지 않음
    rescan();
    if (!bootTask) { bootTask = new Task(autoopen, this); bootTask.schedule(1200); }
    if (!verTask) { verTask = new Task(startVersionChecks, this); verTask.schedule(8000); }   // 로드 8초 뒤 한 번만
}
function rescan() {
    var t0 = new Date().getTime();
    try { scan(); } catch (e) { status("scan error: " + e); }
    scannedAt = new Date().getTime();
    log("scan " + (scannedAt - t0) + " ms");
}

// 방금 로드된 세트가 기본 템플릿/템플릿에서 시작한 새 세트인가? (Log.txt의 마지막 "Loading document")
// 판단 불가면 true (= 창을 띄우는 쪽으로)
function isNewSet() {
    try {
        if (!LIVE) return true;
        var loads = LASTLOADS || logLoads(LIVE.dir + "/Log.txt");
        if (!loads.length) return true;
        var last = loads[0];
        return (TPLDIR && last.indexOf(TPLDIR + "/") == 0) || /\/Templates\/[^\/]*\.als$/i.test(last);
    } catch (e) { return true; }
}
function autoopen() {
    if (autoDone) return;
    autoDone = true;
    if (isNewSet()) {
        log("new set -> opening HUB window"); openwin();
        frontTask = new Task(function () { outlet(2, "showwin"); }, this); frontTask.schedule(3000);
    }
    else log("existing set -> window stays closed");
}
function openwin() {
    outlet(2, "showwin");
    outlet(1, "open");
    if (!scannedAt || new Date().getTime() - scannedAt > 30000) rescan(); else resend();
}

function toFileUrl(p) {
    var segs = p.split("/");
    for (var i = 0; i < segs.length; i++) segs[i] = encodeURIComponent(segs[i]);
    return "file://" + segs.join("/");
}
function openset(enc) {
    var p;
    try { p = decodeURIComponent(String(enc)); } catch (e) { status("bad path"); return; }
    if (!fexists(p)) { status("missing (moved or deleted): " + basename(p)); return; }
    try { max.launchbrowser(toFileUrl(p)); status("opening " + p.substring(p.lastIndexOf("/") + 1)); }
    catch (e) { status("open failed: " + e); }
}

// ======================= 업데이트 알림 + 내 컴퓨터의 NEN 디바이스 버전 =======================
// 버전 파일: https://nen-versions.netlify.app/<id>/version.json  →  {"latest":"x.y.z","url":"..."}
// [maxurl](인자 없음)에 "get <주소>"를 하나씩 보내고, 응답(dictionary)을 받으면 다음 것을 보낸다.
// 사용자 정보는 보내지 않는다. 설치 버전은 패널 주소의 # 뒤(서버로 안 감)로만 넘긴다.
var VERBASE = "https://nen-versions.netlify.app/";
var NEN_DEVS = [
    { id: "setmonitor",   re: /^set ?monitor(?!.*legacy).*\.amxd$/i },
    { id: "stripsilence", re: /^strip ?silence.*\.amxd$/i },
    { id: "drumslicer",   re: /^drum ?slicer.*\.amxd$/i },
    { id: "elsewhere",    re: /^elsewhere.*\.amxd$/i },
    { id: "elsewhen",     re: /^elsewhen.*\.amxd$/i },
    { id: "handoff",      re: /^handoff.*\.amxd$/i },
    { id: "tracknamer",   re: /^track ?namer.*\.amxd$/i },
    { id: "nametag",      re: /^name ?tag.*\.amxd$/i }
];
var VERFILES = { hub: 1, setmonitor: 1, stripsilence: 1, drumslicer: 1, elsewhere: 1, elsewhen: 1, nametag: 1 };   // nen-versions에 version.json이 있는 것만
var vtoTask = null;
var verTask = null, VQ = [], VCUR = null, HAVE = {}, LATEST = {}, HUBUPD = null;
function bytesToStr(b) { var s = "", i; for (i = 0; i < b.length; i += 8192) s += String.fromCharCode.apply(null, b.slice(i, i + 8192)); return s; }
function verIn(s) {
    var m = s.match(/NEN_VERSION[ :=]+\\?"?([0-9][0-9a-z.]*)/) || s.match(/VERSION\s*=\s*\\?"v?([0-9][0-9a-z.]*)\\?"/);
    return m ? m[1] : "";
}
function deviceVersion(path) {
    var b = readBytes(path); if (!b) return "";
    var s = bytesToStr(b), v = verIn(s);            // Freeze된 디바이스는 JS가 .amxd 안에 들어 있다
    if (v) return v;
    var js = s.match(/"[^"\/]*?([A-Za-z0-9_\-]+\.js)"/g) || [], dir = dirname(path), seen = {};
    for (var i = 0; i < js.length; i++) {
        var n = js[i].replace(/^".*?([A-Za-z0-9_\-]+\.js)"$/, "$1");
        if (seen[n]) continue; seen[n] = 1;
        var jb = readBytes(dir + "/" + n); if (!jb) continue;
        v = verIn(bytesToStr(jb)); if (v) return v;
    }
    return "?";                                     // 설치는 돼 있지만 버전 표기가 없음
}
// 파일/폴더 이름에서 버전 ("Set Monitor v4.11.1", "Elsewhen 1.0b9", "Track Namer 1.0.2")
function nameVersion(path) {
    var m = String(path).match(/[ _v-]v?(\d+\.\d+(?:\.\d+)?(?:b\d+)?)(?=[ \/._)-]|$)/gi);
    if (!m) return "";
    return m[m.length - 1].replace(/^[ _v-]v?/i, "");
}
function vlt(a, b) {                                 // a < b ?  ("?" 는 가장 낮게)
    if (a == "?" || !a) return !(b == "?" || !b);
    if (b == "?" || !b) return false;
    return vnum(a) < vnum(b);
}
function findDevices(dir, depth) {
    try {
        var f = new Folder(dir);
        while (!f.end) {
            var n = f.filename;
            if (f.filetype == "fold") {
                if (depth > 0 && !/^(backup|claude outputs|_old.*|_to_delete|tmp|\.venv)$/i.test(n)) findDevices(dir + "/" + n, depth - 1);
            } else if (/\.amxd$/i.test(n) && !/(debug|legacy|backup|copy|복사본)/i.test(n)) {
                for (var k = 0; k < NEN_DEVS.length; k++) if (NEN_DEVS[k].re.test(n)) {
                    var id = NEN_DEVS[k].id, path = dir + "/" + n, v = deviceVersion(path);
                    if (v == "?" || !v) v = nameVersion(path) || "?";
                    if (!HAVE[id] || vlt(HAVE[id], v)) HAVE[id] = v;   // 여러 개 깔려 있으면 가장 높은 버전
                }
            }
            f.next();
        }
        f.close();
    } catch (e) { log("device scan ERR " + e); }
}
function startVersionChecks() {
    HAVE = {};
    if (USERLIB) findDevices(USERLIB + "/Presets", 6);
    log("installed NEN devices: " + JSON.stringify(HAVE));
    sendNen();                                      // 설치 버전은 바로 패널로 (최신 버전 확인을 기다리지 않음)
    VQ = ["hub"]; for (var k in HAVE) if (VERFILES[k]) VQ.push(k);
    nextVersion();
}
function nextVersion() {
    if (!VQ.length) { if (vtoTask) vtoTask.cancel(); VCUR = null; sendNen(); return; }
    VCUR = VQ.shift();
    if (!vtoTask) vtoTask = new Task(function () { log("version timeout " + VCUR); nextVersion(); }, this);
    vtoTask.cancel(); vtoTask.schedule(8000);       // 응답이 없어도 줄이 멈추지 않게
    outlet(4, "get", VERBASE + VCUR + "/version.json");
}
// [maxurl] 응답: "dictionary <name>"
function urlres() {
    var a = arrayfromargs(arguments), id = VCUR;
    if (vtoTask) vtoTask.cancel();
    if (!id) return;
    try {
        if (a[0] == "dictionary" && id) {
            var d = new Dict(String(a[1])), latest = d.get("latest"), url = d.get("url"), body = d.get("body");
            if (!latest && body) { try { var j = JSON.parse(String(body)); latest = j.latest; url = j.url; } catch (e1) {} }
            if (latest) LATEST[id] = { v: String(latest), url: url ? String(url) : "https://app.gumroad.com/library" };
            if (id == "hub") hubUpdate();
        }
    } catch (e) { log("version read ERR " + id + ": " + e); }
    nextVersion();
}
function vnum(s) { var p = String(s).replace(/^v/, "").split("."); return (parseInt(p[0], 10) || 0) * 1e6 + (parseInt(p[1], 10) || 0) * 1e3 + (parseInt(p[2], 10) || 0); }
function hubUpdate() {
    var L = LATEST.hub;
    if (L && vnum(L.v) > vnum(VERSION) && L.v != SKIPVER) { HUBUPD = L; outlet(0, "hubupd", L.v, encodeURIComponent(L.url)); log("update " + L.v + " available"); }
    else { HUBUPD = null; outlet(0, "hubupd", "none"); }
}
function skipver(v) { SKIPVER = String(v); saveSettings(); HUBUPD = null; outlet(0, "hubupd", "none"); log("skipping " + SKIPVER); }
// 패널로: id:설치버전:최신버전 목록 (UI가 jweb 주소의 # 뒤에 붙임)
function sendNen() {
    var parts = [];
    for (var i = 0; i < NEN_DEVS.length; i++) {
        var id = NEN_DEVS[i].id; if (!HAVE[id]) continue;
        parts.push(id + ":" + HAVE[id] + ":" + (LATEST[id] ? LATEST[id].v : ""));
    }
    CACHE.nen = parts.join(",");
    outlet(0, "nen", CACHE.nen || "none");
}

// 포털 링크: https만 허용, 기본 브라우저로 연다
function openurl(enc) {
    var u;
    try { u = decodeURIComponent(String(enc)); } catch (e) { return; }
    if (!/^https:\/\/[^\s]+$/i.test(u)) { log("blocked url: " + u); return; }
    try { max.launchbrowser(u); } catch (e) { log("openurl failed: " + e); }
}
function bang() { rescan(); }

