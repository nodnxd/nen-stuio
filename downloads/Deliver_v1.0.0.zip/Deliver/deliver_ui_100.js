// Deliver — UI (v8ui / mgraphics) — NEN AUDIO
// jsarguments[1] = "device" (compact strip in the device chain) | "window" (floating editor)

autowatch = 0;
inlets = 1;
outlets = 3;   // 0 engine, 1 thispatcher (window), 2 deferlow -> textedit "dl_edit"

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

var MODE = (typeof jsarguments !== "undefined" && jsarguments.length > 1) ? String(jsarguments[1]) : "window";

var st = null;
var scroll = 0;
var hits = [];
var listRows = 18;

var C = {
	bg: [0.071, 0.071, 0.071, 1],
	panel: [0.105, 0.105, 0.105, 1],
	panel2: [0.086, 0.086, 0.086, 1],
	line: [0.17, 0.17, 0.17, 1],
	text: [0.93, 0.918, 0.894, 1],
	dim: [0.54, 0.53, 0.5, 1],
	faint: [0.3, 0.3, 0.3, 1],
	amber: [0.91, 0.686, 0.302, 1],
	amberDk: [0.91, 0.686, 0.302, 0.28],
	yellow: [0.95, 0.83, 0.23, 1],
	black: [0.07, 0.07, 0.07, 1],
	red: [0.9, 0.36, 0.31, 1]
};
var RC = {
	INST: [0.55, 0.55, 0.55, 1],
	LEAD: [0.91, 0.686, 0.302, 1],
	CHORUS: [0.85, 0.55, 0.37, 1],
	ADLIB: [0.72, 0.66, 0.85, 1],
	GUIDE: [0.5, 0.7, 0.78, 1],
	OFF: [0.2, 0.2, 0.2, 1],
	MIX: [0.33, 0.33, 0.33, 1]
};
var SHORT = { INST: "INST", LEAD: "LEAD", CHORUS: "CHO", ADLIB: "ADLIB", GUIDE: "GUIDE", OFF: "OFF", MIX: "MIX" };
var MONO = "Menlo";
var SANS = "Ableton Sans Bold";

function state(s) {
	try { st = JSON.parse(decodeURIComponent(s)); } catch (e) { return; }
	clampScroll();
	mgraphics.redraw();
}

function clampScroll() {
	var n = st && st.tr ? visibleRows().length : 0;
	scroll = Math.max(0, Math.min(scroll, Math.max(0, n - listRows)));
}

// ---------------------------------------------------------------- helpers

function col(g, c) { g.set_source_rgba(c[0], c[1], c[2], c[3]); }
function rect(g, x, y, w, h, c) { col(g, c); g.rectangle(x, y, w, h); g.fill(); }
function rrect(g, x, y, w, h, r, c) { col(g, c); g.rectangle_rounded(x, y, w, h, r, r); g.fill(); }
function stroke(g, x, y, w, h, r, c) { col(g, c); g.set_line_width(1); g.rectangle_rounded(x + 0.5, y + 0.5, w - 1, h - 1, r, r); g.stroke(); }
function hline(g, x1, x2, y, c) { col(g, c); g.set_line_width(1); g.move_to(x1, y + 0.5); g.line_to(x2, y + 0.5); g.stroke(); }
function vline(g, x, y1, y2, c) { col(g, c); g.set_line_width(1); g.move_to(x + 0.5, y1); g.line_to(x + 0.5, y2); g.stroke(); }
function font(g, f, s) { g.select_font_face(f); g.set_font_size(s); }
function tw(g, s) { return g.text_measure(String(s))[0]; }
function text(g, s, x, y, c) { col(g, c); g.move_to(x, y); g.show_text(String(s)); }
function ctext(g, s, cx, y, c) { text(g, s, cx - tw(g, s) / 2, y, c); }
function rtext(g, s, rx, y, c) { text(g, s, rx - tw(g, s), y, c); }
function fit(g, s, w) {
	s = String(s);
	if (tw(g, s) <= w) return s;
	while (s.length > 1 && tw(g, s + "…") > w) s = s.substring(0, s.length - 1);
	return s + "…";
}
function fitLeft(g, s, w) {
	s = String(s);
	if (tw(g, s) <= w) return s;
	while (s.length > 1 && tw(g, "…" + s) > w) s = s.substring(1);
	return "…" + s;
}
function hit(x, y, w, h, fn) { hits.push({ x: x, y: y, w: w, h: h, fn: fn }); }
function isActive(i) {
	if (!st.run || !st.prog || !st.prog.vi) return false;
	var v = st.prog.vi;
	if (v && typeof v === "object" && typeof v.length === "number") { for (var k = 0; k < v.length; k++) if (v[k] === i) return true; return false; }
	return v === i;
}
function folderShort() { return st.folder ? st.folder.replace(/^\/Users\/[^\/]+/, "~") : ""; }
function planText() {
	if (!st.files) return "no files";
	var s = st.files + (st.files === 1 ? " FILE" : " FILES");
	if (st.stems && st.nstems) s += " + " + st.nstems + " STEMS";
	s += " · " + st.passes + (st.passes === 1 ? " PASS" : " PASSES");
	return s;
}
function statusLine() {
	if (st.run && st.prog) {
		var p = st.prog;
		var ph = { seek: "PREPARING", arm: "PREPARING", play: "RECORDING", tail: "TAIL", write: "WRITING", gap: "WRITING", wait: "RETRYING" }[p.ph] || "";
		return { s: (p.k + 1) + "/" + p.n + "  " + p.v.toUpperCase() + "  ·  " + ph + "  " + p.t, c: C.text };
	}
	if (st.warn) return { s: "⚠ " + st.warn, c: C.red };
	if (st.msg) return { s: st.msg, c: /^Done/.test(st.msg) ? C.text : C.red };
	return null;
}

// ---------------------------------------------------------------- paint

function paint() {
	var g = mgraphics;
	var r = this.box.rect;
	var W = r[2] - r[0], H = r[3] - r[1];
	hits = [];
	rect(g, 0, 0, W, H, C.bg);
	if (MODE === "device") paintDevice(g, W, H);
	else paintWindow(g, W, H);
}

// ---------------------------------------------------------------- compact device strip

function paintDevice(g, W, H) {
	font(g, SANS, 13);
	text(g, "DELIVER", 10, 17, C.text);
	font(g, MONO, 8);
	text(g, "LIVE → VERSIONS", 82, 16, C.amber);
	hline(g, 0, W, 24, C.line);
	if (!st) { text(g, "loading…", 10, 44, C.dim); return; }

	font(g, MONO, 8.5);
	text(g, "VERSIONS", 10, 42, C.dim);
	text(g, planText(), 76, 42, C.text);
	text(g, "FOLDER", 10, 57, C.dim);
	text(g, st.folder ? fitLeft(g, folderShort(), W - 86) : "—", 76, 57, st.folder ? C.text : C.faint);
	text(g, "RANGE", 10, 72, C.dim);
	text(g, st.range === "LOOP" ? "LOOP" : "ALL SONG", 76, 72, C.text);

	// OPEN
	var oy = 86, oh = 56;
	stroke(g, 10, oy, 92, oh, 3, C.dim);
	font(g, SANS, 11);
	ctext(g, "OPEN", 56, oy + 26, C.text);
	font(g, MONO, 7.5);
	ctext(g, "EDIT ROLES", 56, oy + 40, C.dim);
	hit(10, oy, 92, oh, function () { outlet(0, "openwin"); });

	drawMainButton(g, 108, oy, W - 8 - 108, oh, 12);
	drawFooter(g, W, H, 153);
}

function drawMainButton(g, bx, by, bw, bh, fs) {
	var run = st.run;
	if (!run) {
		var ok = st.files > 0;
		rrect(g, bx, by, bw, bh, 3, ok ? C.amber : C.faint);
		font(g, SANS, fs);
		ctext(g, "DELIVER", bx + bw / 2, by + bh / 2 + 1, C.black);
		font(g, MONO, 7.5);
		ctext(g, st.files + (st.files === 1 ? " FILE" : " FILES") + (st.stems && st.nstems ? " + " + st.nstems + " STEMS" : ""), bx + bw / 2, by + bh / 2 + 13, [0.07, 0.07, 0.07, 0.7]);
	} else {
		rrect(g, bx, by, bw, bh, 3, C.panel);
		var p = st.prog;
		var frac = p ? (p.k + p.f) / Math.max(1, p.n) : 0;
		rrect(g, bx, by, Math.max(4, bw * Math.min(1, frac)), bh, 3, C.amberDk);
		stroke(g, bx, by, bw, bh, 3, C.amber);
		font(g, SANS, fs);
		ctext(g, "CANCEL", bx + bw / 2, by + bh / 2 + 4, C.text);
	}
	hit(bx, by, bw, bh, function () { outlet(0, run ? "cancel" : "deliver"); });
}

function drawFooter(g, W, H, y) {
	if (st.upd) {
		rect(g, 0, y, W, H - y, C.yellow);
		font(g, MONO, 8);
		var compact = W < 500;
		var sx = W - 8 - (compact ? 64 : 118), dx = sx - 6 - (compact ? 74 : 82);
		text(g, compact ? "v" + st.upd + " is out" : "UPDATE v" + st.upd + " is available", 10, y + 11, C.black);
		stroke(g, dx, y + 2, compact ? 74 : 82, 12, 2, C.black);
		ctext(g, "DOWNLOAD ↗", dx + (compact ? 37 : 41), y + 11, C.black);
		hit(dx, y + 2, compact ? 74 : 82, 12, function () { outlet(0, "upd_download"); });
		stroke(g, sx, y + 2, compact ? 64 : 118, 12, 2, C.black);
		ctext(g, compact ? "SKIP" : "SKIP THIS VERSION", sx + (compact ? 32 : 59), y + 11, C.black);
		hit(sx, y + 2, compact ? 64 : 118, 12, function () { outlet(0, "upd_skip"); });
		return;
	}
	hline(g, 0, W, y - 1, C.line);
	var sl = statusLine();
	font(g, MONO, 8);
	var stampW = W < 500 ? 60 : 110;
	if (sl) text(g, fit(g, sl.s, W - stampW - 20), 10, y + 11, sl.c);
	font(g, MONO, 7);
	rtext(g, W < 500 ? "NEN AUDIO" : "NEN AUDIO · v" + (st.ver || ""), W - 8, y + 11, C.faint);
}

// ---------------------------------------------------------------- floating window

function paintWindow(g, W, H) {
	font(g, SANS, 20);
	text(g, "DELIVER", 20, 32, C.text);
	font(g, MONO, 9);
	text(g, "LIVE → VERSIONS", 122, 31, C.amber);
	rtext(g, "ESC  close", W - 20, 31, C.faint);
	hline(g, 0, W, 46, C.line);
	if (!st) { font(g, MONO, 10); text(g, "loading…", 20, 80, C.dim); return; }
	var run = st.run;
	drawTrackList(g, run, 20, 58, 340, 412);
	vline(g, 378, 58, 470, C.line);
	drawMatrix(g, run, 394, 58, W - 20);
	drawSettings(g, run, 394, 296, W - 20);
	drawFooterWin(g, W, H);
}

var folded = {};
function visibleRows() {
	var out = [], hideBelow = -1;
	if (!st || !st.tr) return out;
	for (var i = 0; i < st.tr.length; i++) {
		var t = st.tr[i], d = t[2];
		if (hideBelow >= 0 && d > hideBelow) continue;
		hideBelow = -1;
		out.push(i);
		if (t[3] && folded[i + ":" + t[0]]) hideBelow = d;
	}
	return out;
}

function drawTrackList(g, run, x0, y0, w, h) {
	var vis = visibleRows();
	font(g, MONO, 9);
	text(g, "TRACKS", x0, y0 + 12, C.dim);
	text(g, String(st.tr.length), x0 + 50, y0 + 12, C.faint);
	text(g, "ROLE", x0 + 80, y0 + 12, C.faint);
	text(g, "↻", x0 + w - 44, y0 + 12, C.dim);
	hit(x0 + w - 50, y0, 18, 16, function () { outlet(0, "rescan"); });
	text(g, "▲", x0 + w - 26, y0 + 12, scroll > 0 ? C.dim : C.faint);
	hit(x0 + w - 30, y0, 14, 16, function () { scroll--; clampScroll(); mgraphics.redraw(); });
	text(g, "▼", x0 + w - 12, y0 + 12, scroll < vis.length - listRows ? C.dim : C.faint);
	hit(x0 + w - 16, y0, 16, 16, function () { scroll++; clampScroll(); mgraphics.redraw(); });

	var ry = y0 + 24, rh = 21;
	listRows = Math.floor((h - 24 - 18) / rh);
	if (!st.tr.length) { text(g, "No tracks in this Set", x0, ry + 14, C.faint); }
	for (var k = 0; k < listRows; k++) {
		var idx = vis[scroll + k];
		if (idx === undefined) break;
		var t = st.tr[idx];
		var y = ry + k * rh;
		var name = t[0], role = t[1], depth = Math.min(t[2], 5), isG = t[3];
		if (k % 2 === 0) rect(g, x0, y, w, rh, C.panel2);
		var cx = x0 + 4 + depth * 12;
		var rc = RC[role] || RC.INST;
		if (isG) stroke(g, cx, y + 3, 54, 15, 3, rc);
		else rrect(g, cx, y + 3, 54, 15, 3, rc);
		font(g, MONO, 8);
		ctext(g, SHORT[role] || role, cx + 27, y + 14, isG ? rc : (role === "OFF" ? C.dim : C.black));
		var nx = cx + 62;
		var fkey = idx + ":" + name;
		if (isG) {
			font(g, MONO, 9);
			text(g, folded[fkey] ? "▸" : "▾", nx, y + 15, C.dim);
			nx += 14;
		} else if (depth > 0) {
			vline(g, cx - 7, y, y + rh, C.line);
		}
		font(g, MONO, 10);
		text(g, fit(g, name, x0 + w - nx - 4), nx, y + 15, role === "OFF" ? C.faint : (isG ? C.dim : C.text));
		(function (i, gkey, grp, chipX) {
			if (grp) {
				hit(x0, y, chipX + 58 - x0, rh, function (opt) { if (!run) outlet(0, "role", i, opt ? -1 : 1); });
				hit(chipX + 58, y, x0 + w - chipX - 58, rh, function () { folded[gkey] = !folded[gkey]; clampScroll(); mgraphics.redraw(); });
			} else {
				hit(x0, y, w, rh, function (opt) { if (!run) outlet(0, "role", i, opt ? -1 : 1); });
			}
		})(idx, fkey, isG, cx);
	}
	font(g, MONO, 8);
	text(g, "click = next role · alt = back · group tag = all inside · ▾ = fold", x0, y0 + h - 2, C.faint);
}

function drawMatrix(g, run, x0, y0, x1) {
	var vs = st.v, roles = st.roles;
	var cx0 = x0 + 64;
	var n = vs.length;
	var cw = Math.min(64, (x1 - cx0) / Math.max(1, n));
	var rowY = y0 + 66, rh = 26;
	var bottom = rowY + roles.length * rh;

	font(g, MONO, 9);
	text(g, "VERSIONS", x0, y0 + 12, C.dim);
	rtext(g, planText(), x1, y0 + 12, C.text);

	for (var c = 0; c < n; c++) {
		var x = cx0 + c * cw;
		if (c === st.sel) rect(g, x + 1, y0 + 20, cw - 2, bottom - y0 - 18, C.panel);
		if (isActive(c)) stroke(g, x + 1, y0 + 20, cw - 2, bottom - y0 - 18, 3, C.amber);
	}
	for (var ri = 0; ri < roles.length; ri++) {
		font(g, MONO, 9);
		text(g, SHORT[roles[ri]], x0, rowY + ri * rh + 16, RC[roles[ri]]);
	}
	for (c = 0; c < n; c++) {
		var v = vs[c];
		x = cx0 + c * cw;
		var on = v.on;
		var bx = x + cw / 2 - 5;
		if (on) rrect(g, bx, y0 + 24, 10, 10, 2, C.amber);
		else stroke(g, bx, y0 + 24, 10, 10, 2, C.dim);
		(function (i) { hit(x, y0 + 20, cw, 16, function () { if (!run) outlet(0, "vtoggle", i); }); })(c);
		font(g, MONO, 9);
		ctext(g, fit(g, v.n, cw - 4), x + cw / 2, y0 + 48, c === st.sel ? C.text : (on ? C.dim : C.faint));
		var d = st.dup ? st.dup[c] : -1;
		font(g, MONO, 7.5);
		if (on && d >= 0 && vs[d]) ctext(g, fit(g, "= " + vs[d].n, cw - 4), x + cw / 2, y0 + 60, C.amber);
		else if (on && d === -2) ctext(g, "EMPTY", x + cw / 2, y0 + 60, C.red);
		(function (i) { hit(x, y0 + 36, cw, 28, function () { if (!run) outlet(0, "vsel", i); }); })(c);
		for (ri = 0; ri < roles.length; ri++) {
			var yy = rowY + ri * rh;
			var lit = v.r[roles[ri]];
			var cc = RC[roles[ri]];
			if (lit) rrect(g, x + 6, yy + 5, cw - 12, 16, 3, on ? cc : [cc[0] * 0.4, cc[1] * 0.4, cc[2] * 0.4, 1]);
			else stroke(g, x + 6, yy + 5, cw - 12, 16, 3, C.line);
			(function (i, k) { hit(x, yy, cw, rh, function () { if (!run) outlet(0, "cell", i, k); }); })(c, ri);
		}
	}
	// version buttons + name field (textedit sits at 560,200..)
	var by = bottom + 14;
	var btn = function (bx, w, label, enabled, msgname) {
		stroke(g, bx, by, w, 20, 3, enabled ? C.dim : C.faint);
		font(g, MONO, label.length > 2 ? 8 : 11);
		ctext(g, label, bx + w / 2, by + (label.length > 2 ? 13 : 14), enabled ? C.text : C.faint);
		hit(bx, by, w, 20, function () { if (!run && enabled) outlet(0, msgname); });
	};
	btn(x0, 26, "+", n < 10, "vadd");
	btn(x0 + 30, 26, "−", n > 1, "vdel");
	btn(x0 + 60, 50, "RESET", true, "vreset");
	font(g, MONO, 9);
	text(g, "NAME", x0 + 122, by + 14, C.dim);
	rect(g, x0 + 160, by, x1 - x0 - 160, 20, C.panel);
	var selv = vs[st.sel];
	if (selv && !editing("vname")) { font(g, MONO, 9); text(g, fit(g, selv.n, x1 - x0 - 172), x0 + 166, by + 14, C.text); }
	hit(x0 + 160, by, x1 - x0 - 160, 20, function () { if (!run && selv) edOpen("vname", selv.n); });
}

function drawSettings(g, run, x0, y0, x1) {
	var FX = x0 + 64, FW = x1 - FX;
	hline(g, x0, x1, y0 - 8, C.line);
	font(g, MONO, 9);
	text(g, "SONG", x0, y0 + 14, C.dim);
	rect(g, FX, y0, FW, 20, C.panel);
	if (!editing("song")) {
		if (st.song) text(g, fit(g, st.song, FW - 12), FX + 6, y0 + 14, C.text);
		else text(g, st.auto ? st.auto + "   (Set name — click to change)" : "Click to type the song title", FX + 6, y0 + 14, C.faint);
	}
	hit(FX, y0, FW, 20, function () { if (!run) edOpen("song", st.song || ""); });
	text(g, "FILE", x0, y0 + 40, C.dim);
	rect(g, FX, y0 + 26, FW, 20, C.panel);
	if (!editing("tmpl")) text(g, fit(g, st.tmpl || "{song}_{version}", FW - 12), FX + 6, y0 + 40, C.text);
	hit(FX, y0 + 26, FW, 20, function () { if (!run) edOpen("tmpl", st.tmpl || "{song}_{version}"); });
	font(g, MONO, 8);
	text(g, fit(g, "→ " + (st.example || "") + "     tokens {song} {version} {bpm} {key} {date}", FW), FX, y0 + 58, C.faint);

	font(g, MONO, 9);
	text(g, "FOLDER", x0, y0 + 80, C.dim);
	rect(g, FX, y0 + 66, FW, 20, C.panel);
	if (st.folder) text(g, fitLeft(g, folderShort(), FW - 12), FX + 6, y0 + 80, C.text);
	else text(g, "Choose a folder…", FX + 6, y0 + 80, C.amber);
	hit(FX, y0 + 66, FW, 20, function () { if (!run) outlet(0, "choosefolder"); });

	text(g, "RANGE", x0, y0 + 106, C.dim);
	var half = 110;
	var all = st.range !== "LOOP";
	if (all) rrect(g, FX, y0 + 92, half, 20, 3, C.amber); else stroke(g, FX, y0 + 92, half, 20, 3, C.dim);
	if (!all) rrect(g, FX + half + 6, y0 + 92, half, 20, 3, C.amber); else stroke(g, FX + half + 6, y0 + 92, half, 20, 3, C.dim);
	font(g, MONO, 8.5);
	ctext(g, "ALL SONG", FX + half / 2, y0 + 106, all ? C.black : C.dim);
	ctext(g, "LOOP BRACE", FX + half + 6 + half / 2, y0 + 106, !all ? C.black : C.dim);
	hit(FX, y0 + 92, half, 20, function () { if (!run) outlet(0, "range", "ALL"); });
	hit(FX + half + 6, y0 + 92, half, 20, function () { if (!run) outlet(0, "range", "LOOP"); });
	font(g, MONO, 9);
	var khz0 = st.sr ? (Math.round(st.sr / 100) / 10) : 48;
	text(g, "WAV · 24-bit · " + khz0 + " kHz", FX + 2 * half + 20, y0 + 106, C.dim);

	drawMainButton(g, x0, y0 + 124, x1 - x0, 46, 15);
}

function drawFooterWin(g, W, H) {
	var y = H - 30;
	if (st.upd) {
		rect(g, 0, y, W, 30, C.yellow);
		font(g, MONO, 9);
		text(g, "UPDATE v" + st.upd + " is available", 20, y + 19, C.black);
		var sx = W - 20 - 140, dx = sx - 8 - 100;
		stroke(g, dx, y + 6, 100, 18, 3, C.black);
		ctext(g, "DOWNLOAD ↗", dx + 50, y + 19, C.black);
		hit(dx, y + 6, 100, 18, function () { outlet(0, "upd_download"); });
		stroke(g, sx, y + 6, 140, 18, 3, C.black);
		ctext(g, "SKIP THIS VERSION", sx + 70, y + 19, C.black);
		hit(sx, y + 6, 140, 18, function () { outlet(0, "upd_skip"); });
		return;
	}
	hline(g, 0, W, y, C.line);
	var sl = statusLine();
	font(g, MONO, 9);
	var khz = st.sr ? (Math.round(st.sr / 100) / 10) : 48;
	var s = sl ? sl.s : "Renders in real time from the Master · versions that sound the same render once";
	text(g, fit(g, s + (st.run ? "   — don't touch the Set" : ""), W - 180), 20, y + 19, sl ? sl.c : C.faint);
	font(g, MONO, 8);
	rtext(g, "FREE · NEN AUDIO · v" + (st.ver || ""), W - 20, y + 19, C.faint);
}

// ---------------------------------------------------------------- inline editor (Name Tag method: one hidden textedit moved over the field)
var ED_RECT = { song: [460, 298, 418, 16], tmpl: [460, 324, 418, 16], vname: [556, 270, 322, 16] };
var ed = null, edPending = null;
function clean(s) { return String(s || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
function edOpen(kind, init) {
	if (ed) edCommit();
	ed = { kind: kind };
	var r = ED_RECT[kind];
	outlet(1, "script", "sendbox", "dl_edit", "presentation_rect", r[0], r[1], r[2], r[3]);
	outlet(1, "script", "show", "dl_edit");
	var words = clean(init) ? clean(init).split(" ") : [];
	outlet(2, ["set"].concat(words));
	outlet(2, "select");
	mgraphics.redraw();
}
function edHide() {
	outlet(1, "script", "hide", "dl_edit");
	outlet(1, "script", "sendbox", "dl_edit", "presentation_rect", -600, -600, 40, 16);
	outlet(2, "set");
}
function edCommit() { if (!ed) return; edPending = ed; ed = null; outlet(2, "bang"); }
function edCancel() { ed = null; edPending = null; edHide(); mgraphics.redraw(); }
function edtext() {
	var a = arrayfromargs(arguments), s = "";
	if (a.length === 1 && a[0] === "bang") a = [];   // empty field: [route text] sends a bare bang
	for (var i = 0; i < a.length; i++) s += (i ? " " : "") + a[i];
	s = clean(s);
	var e = edPending || ed;
	edPending = null; ed = null;
	edHide();
	if (!e) return;
	outlet(0, e.kind, s);
	mgraphics.redraw();
}
function keydown(k) {
	if (k === 27) { if (ed || edPending) { edCancel(); return; } outlet(0, "esc"); }
}
function editing(kind) { return ed && ed.kind === kind; }

// ---------------------------------------------------------------- mouse

function onclick(x, y, but, cmd, shift, capslock, option, ctrl) {
	if (ed) edCommit();
	for (var i = hits.length - 1; i >= 0; i--) {
		var h = hits[i];
		if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) { h.fn(option || ctrl); return; }
	}
}

function onwheel(x, y, wx, wy) {
	if (MODE !== "device" && x < 378 && st) {
		scroll += wy > 0 ? -1 : 1;
		clampScroll();
		mgraphics.redraw();
	}
}

function onresize() { mgraphics.redraw(); }

if (typeof module !== "undefined") module.exports = {};
