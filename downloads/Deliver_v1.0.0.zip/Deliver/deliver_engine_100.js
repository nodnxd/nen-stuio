// Deliver — engine (v8) — NEN AUDIO
// Renders mute-combination versions (Full / Inst / Acapella / TV ...) of the
// Arrangement in real time from the Master track and writes 24-bit WAV files.

autowatch = 0;
inlets = 1;
outlets = 1;

var VERSION = "1.0.0";
var VERSION_URL = "https://nen-versions.netlify.app/deliver/version.json";
var LIBRARY_URL = "https://nen-stuio.vercel.app/plug-ins/m4l/deliver";   // free device: the update button opens its page
var AD_URL = "https://nen-stuio.vercel.app/hub/?src=deliver";

var ROLES = ["INST", "LEAD", "CHORUS", "ADLIB", "GUIDE"];
var TRACK_ROLES = ["INST", "LEAD", "CHORUS", "ADLIB", "GUIDE", "OFF"];
var MAX_VERSIONS = 10;
var TAIL_MAX = 10000;      // ms, longest tail after the end point
var QUIET_HOLD = 500;      // ms of silence that ends the tail
var QUIET_LEVEL = 0.0001;  // -80 dBFS
var NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

var PATCHER = null;
try { PATCHER = this.patcher; } catch (e) { PATCHER = null; }

// ---------------------------------------------------------------- state

function mkVersion(n, on, list) {
	var o = { n: n, on: on, r: {} };
	for (var i = 0; i < ROLES.length; i++) o.r[ROLES[i]] = list.indexOf(ROLES[i]) >= 0 ? 1 : 0;
	return o;
}

function defaultVersions() {
	return [
		mkVersion("Full", 1, ["INST", "LEAD", "CHORUS", "ADLIB"]),
		mkVersion("Inst", 1, ["INST"]),
		mkVersion("Acapella", 1, ["LEAD", "CHORUS", "ADLIB"]),
		mkVersion("TV", 1, ["INST", "CHORUS"]),
		mkVersion("Guide", 1, ["INST", "GUIDE", "CHORUS", "ADLIB"]),
		mkVersion("No Lead", 1, ["INST", "CHORUS", "ADLIB"]),
		mkVersion("No Chorus", 1, ["INST", "LEAD", "ADLIB"])
	];
}

var S = {
	roles: {},          // track name -> role
	versions: defaultVersions(),
	sel: 0,
	song: "",
	tmpl: "{song}_{version}",
	range: "ALL",
	folder: "",         // Max path, ends with "/"
	stems: 0            // also record every track (ALL INDIVIDUAL TRACKS)
};

var tracks = [];        // scanned: {i, id, name, g, gid, depth}
var ready = false;
var sr = 48000;
var lastCnt = 0, lastSidx = -1, lastP0 = 0, level = 0;
var job = null;
var task = null;
var msg = "";
var warn = "";
var upd = null;
var skipVer = "";
var pendingRestore = null;
var lastSend = 0;

// ---------------------------------------------------------------- helpers

function str(v) {
	if (v === undefined || v === null) return "";
	if (v instanceof Array) return v.join(" ");
	return String(v);
}
function num(v) {
	if (v instanceof Array) v = v[0];
	var n = Number(v);
	return isNaN(n) ? 0 : n;
}
function args(a) {
	var out = [];
	for (var i = 0; i < a.length; i++) out.push(a[i]);
	return out.join(" ");
}

function guessRole(name, parents) {
	var n = (" " + String(name).toLowerCase() + " ").replace(/[_\-\.]/g, " ");
	var p = parents ? (" " + parents.join(" ").toLowerCase() + " ").replace(/[_\-\.]/g, " ") : " ";
	if (/\s(ref|reference|click|metronome|metro)[\s\d]/.test(n)) return "OFF";
	if (/guide|가이드/.test(n)) return "GUIDE";
	if (/\sad\s?lib|adlib|애드립/.test(n)) return "ADLIB";
	if (/\s(cho|chorus|chrs|bgv|bgvs|bv|bvs|bvox|backing|harm|harmony|harmonies|dbl|double|doubles|stack|stacks)[\s\d]|코러스|화음/.test(n)) return "CHORUS";
	if (/\sv\s+(g|gd|guide)[\s\d]/.test(n)) return "GUIDE";
	if (/\sv\s+(ad|adl|adlib)[\s\d]/.test(n)) return "ADLIB";
	if (/\sv\s+(c|ch|cho|h|hm|harm|bg|bv)[\s\d]/.test(n)) return "CHORUS";
	if (/\sv\s+(l|ld|lead|main|m)[\s\d]/.test(n)) return "LEAD";
	var vocal = /\s(vox|vocal|vocals|vo|vx)[\s\d]|보컬|메인/.test(n);
	var leadWord = /\s(lead|main|ld)[\s\d]/.test(n);
	var instWord = /synth|syn\s|gtr|guitar|keys|piano|pad|pluck|bass|arp|lead\s?(synth|gtr)/.test(n);
	if (vocal) return "LEAD";
	if (leadWord && !instWord) return "LEAD";
	// unnamed track inside a vocal group
	if (/\s(vox|vocal|vocals|vo|vx)[\s\d]|보컬/.test(p)) {
		if (/\s(cho|chorus|bgv|harm|harmony|backing)[\s\d]|코러스/.test(p)) return "CHORUS";
		return "LEAD";
	}
	return "INST";
}

function sanitize(s) {
	return String(s).replace(/[\/\\:\*\?"<>\|]/g, "-").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

function pad2(n) { return (n < 10 ? "0" : "") + n; }

function buildName(tmpl, song, version, bpm, key, date) {
	var t = tmpl && /\S/.test(tmpl) ? tmpl : "{song}_{version}";
	var out = t
		.replace(/\{song\}/gi, song && /\S/.test(song) ? song : "Untitled")
		.replace(/\{version\}/gi, version)
		.replace(/\{bpm\}/gi, String(bpm))
		.replace(/\{key\}/gi, key)
		.replace(/\{date\}/gi, date);
	out = sanitize(out);
	if (!/\S/.test(out)) out = "Deliver";
	return out;
}

function keyName(root, scale) {
	var r = NOTES[((root % 12) + 12) % 12];
	var s = String(scale || "");
	if (s === "Major" || s === "") return r;
	if (s === "Minor") return r + "m";
	return r + " " + s;
}

function newer(a, b) {
	var x = String(a).split("."), y = String(b).split(".");
	for (var i = 0; i < Math.max(x.length, y.length); i++) {
		var p = Number(x[i] || 0), q = Number(y[i] || 0);
		if (p > q) return true;
		if (p < q) return false;
	}
	return false;
}

function posix(p) {
	var m = String(p).match(/^([^:\/]+):(\/.*)$/);
	if (!m) return String(p);
	var rest = m[2];
	if (/^\/(Users|Applications|Library|Volumes|private|tmp|System)(\/|$)/.test(rest)) return rest;
	return "/Volumes/" + m[1] + rest;
}

function fileExists(path) {
	try {
		var f = new File(path, "read");
		var ok = f.isopen;
		if (ok) f.close();
		return ok;
	} catch (e) { return false; }
}

function uniquePath(folder, base) {
	var p = folder + base + ".wav";
	var k = 2;
	while (fileExists(p) && k < 100) { p = folder + base + " (" + k + ").wav"; k++; }
	return p;
}

// ---------------------------------------------------------------- current Set name (from Live's Log.txt, like HUB)

var autoSong = "";

function readBytes(p, tail) {
	try {
		var f = new File(p, "read");
		if (!f.isopen) return null;
		var total = f.eof, start = (tail && total > tail) ? total - tail : 0, n = total - start, out = new Array(n), k = 0, got, i;
		f.position = start;
		while (k < n) {
			got = f.readbytes(Math.min(16384, n - k));
			if (typeof got == "number") got = [got];
			if (!got || !got.length) break;
			for (i = 0; i < got.length; i++) out[k++] = got[i];
		}
		f.close();
		out.length = k;
		return out;
	} catch (e) { return null; }
}
function utf8(b) {
	var parts = [], i = 0, n = b.length, c, cp, chunk = [];
	while (i < n) {
		c = b[i++];
		if (c < 0x80) cp = c;
		else if (c >= 0xC0 && c < 0xE0 && i < n) cp = ((c & 0x1F) << 6) | (b[i++] & 0x3F);
		else if (c >= 0xE0 && c < 0xF0 && i + 1 < n) { cp = ((c & 0x0F) << 12) | ((b[i] & 0x3F) << 6) | (b[i + 1] & 0x3F); i += 2; }
		else if (c >= 0xF0 && i + 2 < n) { cp = ((c & 0x07) << 18) | ((b[i] & 0x3F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F); i += 3; }
		else cp = 0xFFFD;
		if (cp > 0xFFFF) { cp -= 0x10000; chunk.push(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)); }
		else chunk.push(cp);
		if (chunk.length >= 4096) { parts.push(String.fromCharCode.apply(null, chunk)); chunk = []; }
	}
	if (chunk.length) parts.push(String.fromCharCode.apply(null, chunk));
	return parts.join("");
}
function modTime(f) {
	try { var m = f.moddate; if (m && m.length >= 6) return new Date(m[0], m[1] - 1, m[2], m[3], m[4], m[5]).getTime(); } catch (e) {}
	return 0;
}
function liveDir() {
	var fp = posix(PATCHER ? PATCHER.filepath : "");
	var m = fp.match(/^(\/Users\/[^\/]+)\//);
	if (!m) return "";
	var base = m[1] + "/Library/Preferences/Ableton", best = "", bt = -1;
	try {
		var f = new Folder(base);
		while (!f.end) {
			if (f.filetype == "fold" && /^Live \d+(\.\d+)*$/.test(f.filename)) {
				var d = base + "/" + f.filename, t = 0;
				try { var g = new Folder(d); while (!g.end) { if (g.filename == "Log.txt") { t = modTime(g); break; } g.next(); } g.close(); } catch (e2) {}
				if (t > bt) { bt = t; best = d; }
			}
			f.next();
		}
		f.close();
	} catch (e) {}
	return best;
}
function setNameFromText(txt) {
	var re = /(?:Loading|Saving|Saved)[^"\n]*document "([^"]+\.als)"/g, m, last = "";
	while ((m = re.exec(txt))) if (!/\/User Library\/Defaults\//.test(m[1])) last = m[1];
	if (!last) return "";
	return last.substring(last.lastIndexOf("/") + 1).replace(/\.als$/i, "");
}
function findSetName() {
	var d = liveDir();
	if (!d) return "";
	var b = readBytes(d + "/Log.txt", 131072);
	return b ? setNameFromText(utf8(b)) : "";
}

// ---------------------------------------------------------------- debug log (deliver_log.txt next to the .amxd)
var LOGBUF = [];
function dlog(s) {
	var line = new Date().toISOString() + " " + s;
	try { post("[Deliver] " + s + "\n"); } catch (e0) {}
	LOGBUF.push(line);
	if (LOGBUF.length > 400) LOGBUF.shift();
	var p = settingsPath();
	if (!p) return;
	p = p.replace(/deliver_settings\.json$/, "deliver_log.txt");
	writeText(p, LOGBUF.join("\n") + "\n");
}

// ---------------------------------------------------------------- settings file (next to the .amxd)

function settingsPath() {
	try {
		var fp = PATCHER ? PATCHER.filepath : "";
		if (!fp) return "";
		var i = fp.lastIndexOf("/");
		if (i < 0) return "";
		return fp.substring(0, i + 1) + "deliver_settings.json";
	} catch (e) { return ""; }
}

function readText(path) {
	try {
		var f = new File(path, "read");
		if (!f.isopen) return null;
		var s = "";
		var guard = 0;
		while (f.position < f.eof && guard < 1000) { s += f.readstring(1024); guard++; }
		f.close();
		return s;
	} catch (e) { return null; }
}

function writeText(path, s) {
	try {
		var f = new File(path, "write");
		if (!f.isopen) return false;
		f.position = 0;
		f.writestring(s);
		f.eof = f.position;
		f.close();
		return true;
	} catch (e) { return false; }
}

function loadSettings() {
	var p = settingsPath();
	if (!p) return;
	var t = readText(p);
	if (!t) return;
	try {
		var o = JSON.parse(t);
		if (o.skip) skipVer = String(o.skip);
		if (!S.folder && o.folder) S.folder = String(o.folder);
		if (o.tmpl && S.tmpl === "{song}_{version}") S.tmpl = String(o.tmpl).replace(/^(text\s+)+(?=\{)/, "") || "{song}_{version}";
	} catch (e) {}
}

function saveSettings() {
	var p = settingsPath();
	if (!p) return;
	writeText(p, JSON.stringify({ folder: S.folder, tmpl: S.tmpl, skip: skipVer }));
}

// ---------------------------------------------------------------- persistence in the Set (pattr blob)

function save() {
	outlet(0, ["store", "set", encodeURIComponent(JSON.stringify(S))]);
	saveSettings();
}

function restore() {
	var s = args(arguments);
	var o = null;
	try { o = JSON.parse(decodeURIComponent(s)); } catch (e) { o = null; }
	if (!o) return;
	if (!o.versions && !o.roles) return;
	restoredEver = true;
	if (!ready) { pendingRestore = o; return; }
	applyRestore(o);
	scan();
	pushTexts();
	send(true);
}

function applyRestore(o) {
	if (o.roles && typeof o.roles === "object") S.roles = o.roles;
	if (o.versions && o.versions.length) {
		var vs = [];
		for (var i = 0; i < o.versions.length && i < MAX_VERSIONS; i++) {
			var v = o.versions[i];
			var nv = { n: sanitize(v.n || ("Version " + (i + 1))) || ("Version " + (i + 1)), on: v.on ? 1 : 0, r: {} };
			for (var k = 0; k < ROLES.length; k++) nv.r[ROLES[k]] = v.r && v.r[ROLES[k]] ? 1 : 0;
			vs.push(nv);
		}
		S.versions = vs;
	}
	if (typeof o.sel === "number") S.sel = Math.max(0, Math.min(S.versions.length - 1, o.sel));
	if (typeof o.song === "string") S.song = o.song.replace(/^(text(\s+|$))+/, "");
	if (typeof o.tmpl === "string" && o.tmpl) S.tmpl = o.tmpl.replace(/^(text\s+)+(?=\{)/, "") || "{song}_{version}";
	if (o.range === "LOOP" || o.range === "ALL") S.range = o.range;
	if (typeof o.stems === "number") S.stems = o.stems ? 1 : 0;
	if (typeof o.folder === "string" && o.folder) S.folder = o.folder;
}

// ---------------------------------------------------------------- init

function init() {
	ready = true;
	if (pendingRestore) { applyRestore(pendingRestore); pendingRestore = null; }
	loadSettings();
	autoSong = findSetName();
	try { var lft = deleteRecTracks("init leftovers"); if (lft) msg = "Removed " + lft + " leftover DELIVER REC track" + (lft === 1 ? "" : "s"); } catch (eL) { dlog("init cleanup error " + eL); }
	scan();
	watchSong();
	watchNames();
	checkPlacement();
	pushTexts();
	send(true);
	// a freshly inserted device (nothing stored in the Set) opens its window
	var t = new Task(function () { if (!restoredEver) openwin(); }, this);
	t.schedule(1200);
}

function srate(v) { var n = Number(v); if (n > 1000) { sr = n; send(true); } }
function cnt(v) { lastCnt = v; }
function sidx(v) { lastSidx = v; }
function phase0(v) { lastP0 = v; }
function lvl(v) { level = v; }

function pushTexts() {
	outlet(0, ["tsong", "set", S.song]);
	outlet(0, ["ttmpl", "set", S.tmpl]);
	var v = S.versions[S.sel];
	outlet(0, ["tvname", "set", v ? v.n : ""]);
}

// ---------------------------------------------------------------- Live

function songApi() { return new LiveAPI("live_set"); }

function scan() {
	if (!ready) return;
	var api = songApi();
	var n = api.getcount("tracks");
	var list = [];
	var byId = {};
	for (var i = 0; i < n; i++) {
		api.path = "live_set tracks " + i;
		var id = String(api.id);
		var gt = api.get("group_track");
		var gid = (gt && gt.length > 1) ? String(gt[1]) : "0";
		var t = { i: i, id: id, name: str(api.get("name")), g: num(api.get("is_foldable")) === 1, gid: gid, depth: 0 };
		list.push(t);
		byId[id] = t;
	}
	var seen = {};
	for (var q = 0; q < list.length; q++) {
		var nm = list[q].name;
		seen[nm] = (seen[nm] || 0) + 1;
		list[q].key = seen[nm] > 1 ? nm + "#" + seen[nm] : nm;
	}
	for (var j = 0; j < list.length; j++) {
		var d = 0, cur = list[j], parents = [];
		while (cur && cur.gid !== "0" && byId[cur.gid] && d < 16) { cur = byId[cur.gid]; parents.push(cur.name); d++; }
		list[j].depth = d;
		list[j].parents = parents;
	}
	for (var k = 0; k < list.length; k++) {
		var tk = list[k];
		if (!tk.g && S.roles[tk.key] === undefined) S.roles[tk.key] = guessRole(tk.name, tk.parents);
	}
	tracks = list;
}

var obsSong = null, obsNames = [], rescanTask = null;
function trackSig() {
	var out = [];
	for (var i = 0; i < tracks.length; i++) out.push(tracks[i].id + ":" + tracks[i].name + ":" + tracks[i].gid);
	return out.join("|");
}
function queueRescan() {
	if (job) return;
	if (!rescanTask) rescanTask = new Task(function () {
		var before = trackSig();
		scan();
		if (trackSig() !== before) { watchNames(); send(true); }
	}, this);
	rescanTask.cancel();
	rescanTask.schedule(150);
}
function watchSong() {
	try {
		obsSong = new LiveAPI(function (a) { if (a && a[0] === "tracks") queueRescan(); }, "live_set");
		obsSong.property = "tracks";
	} catch (e) {}
}
function watchNames() {
	for (var i = 0; i < obsNames.length; i++) { try { obsNames[i].property = ""; } catch (e) {} }
	obsNames = [];
	for (var k = 0; k < tracks.length; k++) {
		try {
			var o = new LiveAPI(function (a) { if (a && a[0] === "name") queueRescan(); }, "live_set tracks " + k);
			o.property = "name";
			obsNames.push(o);
		} catch (e) {}
	}
}

function checkPlacement() {
	warn = "";
	try {
		var dev = new LiveAPI("this_device");
		var par = new LiveAPI("this_device canonical_parent");
		var mt = new LiveAPI("live_set master_track");
		if (String(par.id) !== String(mt.id)) { warn = "Put Deliver on the MASTER track"; return false; }
		var devs = mt.get("devices");
		var last = devs && devs.length ? String(devs[devs.length - 1]) : "";
		if (last !== String(dev.id)) { warn = "Move Deliver to the LAST slot of the Master"; return false; }
	} catch (e) { warn = ""; }
	return true;
}

function leavesOf(i) {
	var out = [];
	var d = tracks[i].depth;
	for (var j = i + 1; j < tracks.length && tracks[j].depth > d; j++) if (!tracks[j].g) out.push(j);
	return out;
}

function groupRole(i) {
	var ls = leavesOf(i);
	if (!ls.length) return "INST";
	var r0 = S.roles[tracks[ls[0]].key] || "INST";
	for (var k = 1; k < ls.length; k++) if ((S.roles[tracks[ls[k]].key] || "INST") !== r0) return "MIX";
	return r0;
}

function nextRole(r, dir) {
	var i = TRACK_ROLES.indexOf(r);
	if (i < 0) return dir < 0 ? "OFF" : "INST";
	return TRACK_ROLES[(i + (dir < 0 ? TRACK_ROLES.length - 1 : 1)) % TRACK_ROLES.length];
}

// ---------------------------------------------------------------- UI messages

function role(i, dir) {
	if (job) return;
	var t = tracks[i];
	if (!t) return;
	if (t.g) {
		var cur = groupRole(i);
		var nr = nextRole(cur === "MIX" ? (dir < 0 ? "INST" : "OFF") : cur, dir);
		var ls = leavesOf(i);
		for (var k = 0; k < ls.length; k++) S.roles[tracks[ls[k]].key] = nr;
	} else {
		S.roles[t.key] = nextRole(S.roles[t.key] || "INST", dir);
	}
	save();
	send(true);
}

function cell(v, ri) {
	if (job) return;
	var ver = S.versions[v];
	if (!ver || !ROLES[ri]) return;
	ver.r[ROLES[ri]] = ver.r[ROLES[ri]] ? 0 : 1;
	S.sel = v;
	pushTexts();
	save();
	send(true);
}

function vtoggle(v) {
	if (job) return;
	var ver = S.versions[v];
	if (!ver) return;
	ver.on = ver.on ? 0 : 1;
	save();
	send(true);
}

function vsel(v) {
	if (job) return;
	if (!S.versions[v]) return;
	S.sel = v;
	pushTexts();
	save();
	send(true);
}

function vadd() {
	if (job || S.versions.length >= MAX_VERSIONS) return;
	var base = S.versions[S.sel] || S.versions[0];
	var nv = { n: "Version " + (S.versions.length + 1), on: 1, r: {} };
	for (var k = 0; k < ROLES.length; k++) nv.r[ROLES[k]] = base ? base.r[ROLES[k]] : 1;
	S.versions.push(nv);
	S.sel = S.versions.length - 1;
	pushTexts();
	save();
	send(true);
}

function vdel() {
	if (job || S.versions.length <= 1) return;
	S.versions.splice(S.sel, 1);
	S.sel = Math.max(0, Math.min(S.sel, S.versions.length - 1));
	pushTexts();
	save();
	send(true);
}

function vreset() {
	if (job) return;
	S.versions = defaultVersions();
	S.sel = 0;
	pushTexts();
	save();
	send(true);
}

function vname() {
	var t = sanitize(args(arguments));
	var v = S.versions[S.sel];
	if (!v || !t) { pushTexts(); return; }
	v.n = t;
	save();
	send(true);
}

function song() { var t = args(arguments).replace(/^\s+|\s+$/g, ""); S.song = t === "bang" ? "" : t; save(); send(true); }
function tmpl() {
	var t = args(arguments).replace(/^\s+|\s+$/g, "");
	S.tmpl = t || "{song}_{version}";
	if (!t) pushTexts();
	save();
	send(true);
}

function stems() {}
function range(r) { if (job) return; S.range = r === "LOOP" ? "LOOP" : "ALL"; save(); send(true); }
function choosefolder() { if (job) return; outlet(0, ["dlg", "bang"]); }
function folder() {
	var p = args(arguments);
	if (!p) return;
	if (p.charAt(p.length - 1) !== "/") p += "/";
	S.folder = p;
	msg = "";
	save();
	send(true);
}
function rescan() { if (job) return; scan(); checkPlacement(); send(true); }

function openwin() {
	outlet(0, ["web", "url", AD_URL]);
	outlet(0, ["win", "front"]);
}
function esc() { outlet(0, ["win", "wclose"]); outlet(0, ["web", "url", "about:blank"]); }
function openurl(u) {
	u = String(u || "");
	if (/^https:\/\/([a-z0-9-]+\.)*(gumroad\.com|nen-stuio\.vercel\.app|maxforlive\.com)(\/|$)/i.test(u)) max.launchbrowser(u);
}
var restoredEver = false;

// ---------------------------------------------------------------- update check

function checkupdate() { outlet(0, ["url", "get", VERSION_URL]); }

function findLatest(o, depth) {
	if (!o || depth > 4) return null;
	if (typeof o === "string") { try { return findLatest(JSON.parse(o), depth + 1); } catch (e) { return null; } }
	if (typeof o !== "object") return null;
	if (o.latest) return o;
	for (var k in o) { var r = findLatest(o[k], depth + 1); if (r) return r; }
	return null;
}

function urlresp(a, b) {
	var name = (a === "dictionary") ? b : a;
	var j = null;
	try {
		var d = new Dict(name);
		var raw = d.stringify ? d.stringify() : null;
		j = findLatest(raw, 0);
		if (!j) {
			var body = d.get("body");
			if (body && typeof body === "object" && body.stringify) body = body.stringify();
			j = findLatest(body, 0);
		}
	} catch (e) { j = null; }
	if (!j || !j.latest) return;
	if (newer(j.latest, VERSION) && String(j.latest) !== skipVer) {
		upd = { v: String(j.latest), url: String(j.url || LIBRARY_URL) };
		send(true);
	}
}

function upd_download() {
	var u = upd ? upd.url : LIBRARY_URL;
	if (!/^https:\/\/([a-z0-9-]+\.)*(gumroad\.com|nen-stuio\.vercel\.app)(\/|$)/i.test(u)) u = LIBRARY_URL;
	max.launchbrowser(u);
}

function upd_skip() {
	if (!upd) return;
	skipVer = upd.v;
	upd = null;
	saveSettings();
	send(true);
}

// ---------------------------------------------------------------- render job

function deliver() {
	if (job) { cancel(); return; }
	// pull the current text of the edit fields first
	outlet(0, ["tsong", "bang"]);
	outlet(0, ["ttmpl", "bang"]);
	var t = new Task(startJob, this);
	t.schedule(80);
}

function enabledVersions() {
	var q = [];
	for (var i = 0; i < S.versions.length; i++) if (S.versions[i].on) q.push(i);
	return q;
}

// versions that would sound identical share one render
function leafOn(ver) {
	var on = [];
	for (var i = 0; i < tracks.length; i++) {
		var t = tracks[i];
		if (t.g) continue;
		var r = S.roles[t.key] || "INST";
		if (r !== "OFF" && ver.r[r]) on.push(i);
	}
	return on;
}

function plan() {
	var groups = [], bySig = {}, dup = [];
	for (var i = 0; i < S.versions.length; i++) {
		dup.push(-1);
		var v = S.versions[i];
		if (!v.on) continue;
		var on = leafOn(v);
		if (!on.length) { dup[i] = -2; continue; }
		var sig = on.join(",");
		if (bySig[sig] === undefined) { bySig[sig] = groups.length; groups.push({ vers: [i] }); }
		else { var g = groups[bySig[sig]]; dup[i] = g.vers[0]; g.vers.push(i); }
	}
	var files = 0;
	for (var k = 0; k < groups.length; k++) files += groups[k].vers.length;
	var stemSrc = [];
	if (false) {
		var covered = {};
		for (var g = 0; g < groups.length; g++) {
			var onl = leafOn(S.versions[groups[g].vers[0]]);
			groups[g].on = onl;
			for (var m = 0; m < onl.length; m++) covered[onl[m]] = 1;
		}
		var left = [];
		for (var t = 0; t < tracks.length; t++) {
			if (tracks[t].g) {
				// a group stem = its children through the group's own devices; record it in the first pass where any child sounds
				stemSrc.push(t);
				continue;
			}
			if ((S.roles[tracks[t].key] || "INST") === "OFF") continue;
			stemSrc.push(t);
			if (!covered[t]) left.push(t);
		}
		if (left.length) groups.push({ vers: [], on: left, stemOnly: true });
	}
	return { groups: groups, dup: dup, files: files, stems: stemSrc };
}

// ---------------------------------------------------------------- ALL INDIVIDUAL TRACKS (temporary record tracks)

function dictProp(api, prop) {
	var raw = api.get(prop);
	if (raw instanceof Array) raw = raw.join(" ");
	try { var o = JSON.parse(String(raw)); return o && o[prop] !== undefined ? o[prop] : o; } catch (e) { return null; }
}
function setDict(api, prop, entry) {
	var o = {}; o[prop] = entry;
	api.set(prop, [JSON.stringify(o)]);
}
function stripNum(s) { return String(s).replace(/^\s*\d+\s*-\s*/, ""); }
function pickRouting(list, name, nth) {
	if (!list || !list.length) return null;
	var hits = [];
	for (var i = 0; i < list.length; i++) if (list[i].display_name === name) hits.push(list[i]);
	if (!hits.length) for (var j = 0; j < list.length; j++) if (stripNum(list[j].display_name) === stripNum(name)) hits.push(list[j]);
	if (!hits.length) return null;
	return hits[Math.min(nth, hits.length - 1)];
}

function setupStems(pl) {
	var api = songApi();
	try { if (num(api.get("count_in_duration")) > 0) return "Turn off Count-In (metronome menu) to record STEMS"; } catch (e) {}
	var tapi = new LiveAPI("live_set");
	// remember + clear record arms
	job.saved.arm = [];
	for (var i = 0; i < tracks.length; i++) {
		tapi.path = "live_set tracks " + i;
		var a = 0;
		try { if (num(tapi.get("can_be_armed"))) { a = num(tapi.get("arm")); if (a) tapi.set("arm", 0); } else a = -1; } catch (e2) { a = -1; }
		job.saved.arm.push(a);
	}
	job.saved.recordMode = num(api.get("record_mode"));
	var nameCount = {};
	job.stems = [];
	for (var k = 0; k < pl.stems.length; k++) {
		var src = tracks[pl.stems[k]];
		var nth = 0;
		for (var q = 0; q < pl.stems[k]; q++) if (tracks[q].name === src.name) nth++;
		api.call("create_audio_track", -1);
		var idx = api.getcount("tracks") - 1;
		tapi.path = "live_set tracks " + idx;
		try { tapi.set("name", "DELIVER REC " + (k + 1)); } catch (e3) {}
		var types = dictProp(tapi, "available_input_routing_types");
		var tp = pickRouting(types, src.name, nth);
		if (!tp) { dlog("routing: no input type for " + src.name + " in " + JSON.stringify(types)); job.stems.push({ src: pl.stems[k], idx: idx, name: src.name, pass: -1, file: "" }); return "Can't route \"" + src.name + "\" for STEMS"; }
		dlog("rec track " + idx + " <- " + tp.display_name + " (" + tp.identifier + ")");
		setDict(tapi, "input_routing_type", tp);
		var chans = dictProp(tapi, "available_input_routing_channels");
		var ch = null;
		if (chans) for (var c = 0; c < chans.length; c++) if (/post\s*mixer/i.test(chans[c].display_name)) ch = chans[c];
		if (!ch && chans) for (var c2 = 0; c2 < chans.length; c2++) if (/post\s*fx/i.test(chans[c2].display_name)) ch = chans[c2];
		if (ch) setDict(tapi, "input_routing_channel", ch);
		try { tapi.set("current_monitoring_state", 2); } catch (e4) {}
		job.stems.push({ src: pl.stems[k], idx: idx, name: src.name, pass: -1, file: "" });
	}
	// which pass records which track: the pass where the most of it sounds (groups: most children on)
	for (var s = 0; s < job.stems.length; s++) {
		var st0 = job.stems[s], best = -1, bestN = 0;
		var members = tracks[st0.src].g ? leavesOf(st0.src) : [st0.src];
		for (var g = 0; g < job.q.length; g++) {
			var on = job.q[g].on || [], n = 0;
			for (var mm = 0; mm < members.length; mm++) if (on.indexOf(members[mm]) >= 0) n++;
			if (n > bestN) { bestN = n; best = g; }
		}
		st0.pass = best;
		dlog("stem " + st0.name + " -> pass " + best + " (" + bestN + "/" + members.length + ")");
	}
	return true;
}

function armForPass(k) {
	if (!job.stems) return false;
	var tapi = new LiveAPI("live_set"), any = false;
	for (var s = 0; s < job.stems.length; s++) {
		var want = job.stems[s].pass === k ? 1 : 0;
		tapi.path = "live_set tracks " + job.stems[s].idx;
		try { tapi.set("arm", want); } catch (e) {}
		if (want) any = true;
	}
	return any;
}

function deleteRecTracks(reason) {
	var api = songApi(), tapi = new LiveAPI("live_set");
	var n = api.getcount("tracks"), removed = 0;
	for (var i = n - 1; i >= 0; i--) {
		tapi.path = "live_set tracks " + i;
		var nm = str(tapi.get("name"));
		if (!/^DELIVER REC \d+$/.test(nm)) continue;
		try { if (num(tapi.get("arm"))) tapi.set("arm", 0); } catch (e1) { dlog("disarm " + i + " failed: " + e1); }
		try { api.call("delete_track", i); removed++; } catch (e2) { dlog("delete_track " + i + " failed: " + e2); }
	}
	var after = api.getcount("tracks");
	dlog("cleanup (" + reason + "): tracks " + n + " -> " + after + ", asked " + removed);
	return n - after;
}

function removeStemTracks() {
	if (!job || !job.stems) return;
	deleteRecTracks("job end");
	job.stems = null;
}

function collectStemFiles() {
	var tapi = new LiveAPI("live_set");
	var out = [];
	for (var s = 0; s < job.stems.length; s++) {
		tapi.path = "live_set tracks " + job.stems[s].idx;
		var ids = tapi.get("arrangement_clips");
		var cid = (ids && ids.length > 1) ? ids[1] : 0;
		if (!cid) continue;
		var capi = new LiveAPI("id " + cid);
		var fp = str(capi.get("file_path"));
		dlog("stem " + job.stems[s].name + ": clip " + cid + " file " + fp);
		if (fp) out.push({ path: fp, name: job.stems[s].name });
	}
	return out;
}

function stemread() { if (job && job.phase === "stemwait") job.stemReady = 1; }

function startJob() {
	if (job) return;
	msg = "";
	if (!S.folder) { msg = "Choose a FOLDER first"; send(true); choosefolder(); return; }
	if (!enabledVersions().length) { msg = "Turn on at least one version"; send(true); return; }
	scan();
	var PL = plan();
	var q = PL.groups;
	if (!q.length) { msg = "Every version is empty — set track roles first"; send(true); return; }
	if (!checkPlacement()) { msg = warn; send(true); return; }

	var api = songApi();
	var start, end;
	if (S.range === "LOOP") {
		start = num(api.get("loop_start"));
		end = start + num(api.get("loop_length"));
	} else {
		start = 0;
		end = num(api.get("last_event_time"));
	}
	if (!(end > start + 0.01)) { msg = "Nothing to render in the Arrangement"; send(true); return; }

	var saved = {
		startTime: (function () { try { return num(api.get("start_time")); } catch (e) { return -1; } })(),
		loop: num(api.get("loop")),
		metronome: num(api.get("metronome")),
		pos: num(api.get("current_song_time")),
		tr: []
	};
	var tapi = new LiveAPI("live_set");
	for (var i = 0; i < tracks.length; i++) {
		tapi.path = "live_set tracks " + i;
		saved.tr.push({ mute: num(tapi.get("mute")), solo: num(tapi.get("solo")) });
	}

	if (num(api.get("is_playing"))) api.call("stop_playing");
	api.set("metronome", 0);
	api.set("loop", 0);
	try { api.set("back_to_arranger", 0); } catch (e) {}

	var root = 0, scale = "";
	try { root = num(api.get("root_note")); scale = str(api.get("scale_name")); } catch (e) {}
	var d = new Date();
	job = {
		q: q, k: 0, start: start, end: end,
		tempo: num(api.get("tempo")) || 120,
		key: keyName(root, scale),
		date: String(d.getFullYear()).substring(2) + pad2(d.getMonth() + 1) + pad2(d.getDate()),
		saved: saved, phase: "", t0: 0, size: 0, retry: 0, quiet: 0, pos: start, files: []
	};
	if (false) {
		var r = setupStems(PL);
		if (r !== true) { fail(r); return; }
	}
	if (task) task.cancel();
	task = new Task(tick, this);
	task.interval = 20;
	task.repeat();
	nextVersion();
}

function stopTransport(api) {
	if (num(api.get("is_playing"))) api.call("stop_playing");
	if (job && job.recording) { try { api.set("record_mode", 0); } catch (e) {} job.recording = false; }
}

function setPhase(p) { job.phase = p; job.t0 = Date.now(); }

function applyMutes(ver) {
	var tapi = new LiveAPI("live_set");
	for (var i = 0; i < tracks.length; i++) {
		var t = tracks[i];
		tapi.path = "live_set tracks " + i;
		var m = 0;
		if (!t.g) {
			var r = S.roles[t.key] || "INST";
			m = (r === "OFF") ? 1 : (ver.r[r] ? 0 : 1);
		}
		if (num(tapi.get("solo"))) tapi.set("solo", 0);
		if (num(tapi.get("mute")) !== m) tapi.set("mute", m);
	}
}

function applyOnly(list) {
	var tapi = new LiveAPI("live_set");
	for (var i = 0; i < tracks.length; i++) {
		var t = tracks[i];
		tapi.path = "live_set tracks " + i;
		var m = t.g ? 0 : (list.indexOf(i) >= 0 ? 0 : 1);
		if (num(tapi.get("solo"))) tapi.set("solo", 0);
		if (num(tapi.get("mute")) !== m) tapi.set("mute", m);
	}
}

function nextVersion() {
	if (!job) return;
	if (job.k >= job.q.length) {
		if (job.stems && job.stems.length) { job.stemList = null; setPhase("stemcollect"); return; }
		finish();
		return;
	}
	var grp = job.q[job.k];
	if (grp.stemOnly) applyOnly(grp.on);
	else applyMutes(S.versions[grp.vers[0]]);
	var secs = (job.end - job.start) * 60 / job.tempo;
	var N = Math.ceil((secs * 1.3 + TAIL_MAX / 1000 + 10) * sr * (job.retry ? 2.2 : 1));
	N = Math.min(N, Math.ceil(40 * 60 * sr));
	job.size = N;
	lastCnt = 0;
	lastSidx = -1;
	outlet(0, ["gen", "rmode", 0]);
	outlet(0, ["buf", "sizeinsamps", N]);
	outlet(0, ["buf", "clear"]);
	outlet(0, ["gen", "rguard", N - 1]);
	var sapi = songApi();
	try { sapi.set("start_time", job.start); } catch (eS) { dlog("start_time set failed " + eS); }
	sapi.set("current_song_time", job.start);
	setPhase("seek");
	send(true);
}

function tick() {
	if (!job) { if (task) task.cancel(); return; }
	var now = Date.now();
	var el = now - job.t0;
	var api;
	switch (job.phase) {
	case "seek":
		if (el > 350) { outlet(0, ["gen", "rmode", 1]); setPhase("arm"); }
		break;
	case "arm":
		if (el > 150) {
			api = songApi();
			try { if (Math.abs(num(api.get("start_time")) - job.start) > 0.001) api.set("start_time", job.start); } catch (eS2) {}
			job.recording = armForPass(job.k);
			if (job.recording) api.set("record_mode", 1);
			api.call("start_playing");
			job.inside = 0;
			setPhase("play");
		}
		break;
	case "play":
		api = songApi();
		job.pos = num(api.get("current_song_time"));
		if (lastSidx < 0 && el > 2500) { fail("No audio clock — is Deliver on the Master track?"); return; }
		if (lastCnt >= job.size - 2) {
			api.call("stop_playing");
			outlet(0, ["gen", "rmode", 0]);
			if (!job.retry) { job.retry = 1; var t = new Task(nextVersion, this); t.schedule(400); job.phase = "wait"; }
			else fail("Song longer than expected — buffer full");
			return;
		}
		if (!job.inside) {
			if (job.pos >= job.start - 0.01 && job.pos < job.end && el > 100) job.inside = 1;
			else if (el > 2000) { fail("Playback didn't start at the range start (pos " + job.pos.toFixed(2) + ", start " + job.start + ")"); return; }
			break;
		}
		if (job.pos >= job.end) {
			if (S.range === "LOOP") stopTransport(api);
			job.quiet = 0;
			setPhase("tail");
			break;
		}
		if (el > 800 && !num(api.get("is_playing"))) { fail("Stopped"); return; }
		break;
	case "tail":
		if (level < QUIET_LEVEL) { if (!job.quiet) job.quiet = now; } else job.quiet = 0;
		if ((job.quiet && now - job.quiet >= QUIET_HOLD && el > 600) || el >= TAIL_MAX) {
			stopTransport(songApi());
			outlet(0, ["gen", "rmode", 0]);
			setPhase("write");
		}
		break;
	case "write":
		if (el > 150) {
			if (!writeFile()) return;
			job.k++;
			job.retry = 0;
			setPhase("gap");
		}
		break;
	case "gap":
		if (el > 300) nextVersion();
		break;
	case "stemcollect":
		if (el > 1200) {            // let Live finish writing the recordings
			job.stemList = collectStemFiles();
			job.stemI = 0;
			if (!job.stemList.length) { fail("STEMS: Live made no recordings"); return; }
			setPhase("stemnext");
		}
		break;
	case "stemnext":
		if (job.stemI >= job.stemList.length) { finish(); return; }
		job.stemReady = 0;
		dlog("read " + job.stemList[job.stemI].path);
		outlet(0, ["bufs", "read", job.stemList[job.stemI].path]);
		setPhase("stemwait");
		break;
	case "stemwait":
		if (job.stemReady || el > 400) {
			if (!job.stemReady) dlog("no read bang for " + job.stemList[job.stemI].name + ", writing after 400 ms");
			var it = job.stemList[job.stemI];
			var base = buildName(S.tmpl, S.song || autoSong, it.name, Math.round(job.tempo), job.key, job.date);
			var path = uniquePath(S.folder, base);
			outlet(0, ["bufs", "samptype", "int24"]);
			outlet(0, ["bufs", "writewave", path]);
			job.files.push(path.substring(path.lastIndexOf("/") + 1));
			job.stemI++;
			setPhase("stemnext");
		} else if (el > 30000) { fail("STEMS: couldn't read " + job.stemList[job.stemI].name); return; }
		break;
	}
	if (now - lastSend > 100) send(false);
}

function writeFile() {
	var grp = job.q[job.k];
	if (grp.stemOnly) return true;
	var first = S.versions[grp.vers[0]];
	var n = lastCnt;
	if (n < sr * 0.1 || lastSidx < 0) { fail("Nothing was recorded for " + first.n); return false; }
	// exact start: the sample where the song position was job.start
	var spb = 60 / job.tempo * sr;
	var dlt = lastP0 - (job.start - Math.floor(job.start));
	dlt = dlt - Math.round(dlt);            // wrap to [-0.5, 0.5]
	var s0 = lastSidx - dlt * spb;
	if (s0 < 0) s0 = 0;
	job.offsets = job.offsets || [];
	job.offsets.push(Math.round(lastSidx) + "/" + dlt.toFixed(5));
	outlet(0, ["buf", "crop", s0 / sr * 1000, n / sr * 1000]);
	outlet(0, ["buf", "samptype", "int24"]);
	for (var k = 0; k < grp.vers.length; k++) {
		var ver = S.versions[grp.vers[k]];
		var base = buildName(S.tmpl, S.song || autoSong, ver.n, Math.round(job.tempo), job.key, job.date);
		var path = uniquePath(S.folder, base);
		outlet(0, ["buf", "writewave", path]);
		job.files.push(path.substring(path.lastIndexOf("/") + 1));
	}
	return true;
}

function restoreState() {
	if (!job) return;
	var sv = job.saved;
	try { var sa = songApi(); if (num(sa.get("record_mode"))) sa.set("record_mode", 0); } catch (e0) {}
	removeStemTracks();
	if (sv.arm) {
		var aapi = new LiveAPI("live_set");
		for (var ai = 0; ai < sv.arm.length && ai < tracks.length; ai++) {
			if (sv.arm[ai] < 1) continue;
			aapi.path = "live_set tracks " + ai;
			try { aapi.set("arm", 1); } catch (e1) {}
		}
	}
	var tapi = new LiveAPI("live_set");
	for (var i = 0; i < sv.tr.length && i < tracks.length; i++) {
		tapi.path = "live_set tracks " + i;
		if (num(tapi.get("mute")) !== sv.tr[i].mute) tapi.set("mute", sv.tr[i].mute);
		if (num(tapi.get("solo")) !== sv.tr[i].solo) tapi.set("solo", sv.tr[i].solo);
	}
	var api = songApi();
	api.set("loop", sv.loop);
	api.set("metronome", sv.metronome);
	api.set("current_song_time", sv.pos);
	if (sv.startTime >= 0) { try { api.set("start_time", sv.startTime); } catch (eS3) {} }
}

function stopAll() {
	try { var api = songApi(); if (num(api.get("is_playing"))) api.call("stop_playing"); } catch (e) {}
	outlet(0, ["gen", "rmode", 0]);
	if (task) task.cancel();
}

function finish() {
	var n = job.files.length;
	stopAll();
	restoreState();
	msg = "Done — " + n + " file" + (n === 1 ? "" : "s") + " → " + posix(S.folder);
	try { post("Deliver offsets: " + (job.offsets || []).join(", ") + "\n"); } catch (e) {}
	job = null;
	outlet(0, ["buf", "sizeinsamps", 1000]);
	outlet(0, ["bufs", "sizeinsamps", 1000]);
	send(true);
}

function fail(m) {
	dlog("FAIL " + m);
	stopAll();
	var done = job ? job.files.length : 0;
	restoreState();
	msg = m + (done ? " (" + done + " written)" : "");
	job = null;
	outlet(0, ["buf", "sizeinsamps", 1000]);
	send(true);
}

function cancel() { if (job) fail("Cancelled"); }

// ---------------------------------------------------------------- view

function send(force) {
	var now = Date.now();
	if (!force && now - lastSend < 100) return;
	lastSend = now;
	var tr = [];
	for (var i = 0; i < tracks.length; i++) {
		var t = tracks[i];
		tr.push([t.name, t.g ? groupRole(i) : (S.roles[t.key] || "INST"), t.depth, t.g ? 1 : 0]);
	}
	var prog = null;
	if (job) {
		var span = job.end - job.start;
		var frac = 0;
		if (job.phase === "play") frac = Math.max(0, Math.min(1, (job.pos - job.start) / span));
		else if (job.phase === "tail" || job.phase === "write" || job.phase === "gap") frac = 1;
		var grp = job.q[Math.min(job.k, job.q.length - 1)];
		var names = [];
		for (var gi = 0; gi < grp.vers.length; gi++) names.push(S.versions[grp.vers[gi]].n);
		if (grp.stemOnly) names.push("STEMS");
		if (/^stem/.test(job.phase)) names = ["STEMS " + Math.min((job.stemI || 0) + 1, job.stemList ? job.stemList.length : 0) + "/" + (job.stemList ? job.stemList.length : 0)];
		var secs = Math.max(0, (job.pos - job.start) * 60 / job.tempo);
		prog = {
			k: job.k, n: job.q.length, v: names.join(" + "), ph: job.phase, f: frac,
			t: Math.floor(secs / 60) + ":" + pad2(Math.floor(secs % 60)),
			vi: grp.vers
		};
	}
	var pl = plan();
	var view = {
		tr: tr, v: S.versions, sel: S.sel, roles: ROLES,
		folder: S.folder ? posix(S.folder) : "", range: S.range, sr: sr,
		run: job ? 1 : 0, prog: prog, msg: msg, warn: warn,
		upd: upd ? upd.v : "", ver: VERSION, on: enabledVersions().length,
		dup: pl.dup, passes: pl.groups.length, files: pl.files, stems: 0, nstems: 0,
		song: S.song, auto: autoSong, tmpl: S.tmpl,
		example: buildName(S.tmpl, S.song || autoSong, (S.versions[S.sel] || { n: "Full" }).n, 120, "Am", "261123") + ".wav"
	};
	outlet(0, ["ui", "state", encodeURIComponent(JSON.stringify(view))]);
}

function notifydeleted() { if (job) { stopAll(); try { restoreState(); } catch (e) {} job = null; } }

// node test hook
if (typeof module !== "undefined") {
	module.exports = { setNameFromText: setNameFromText, guessRole: guessRole, buildName: buildName, keyName: keyName, newer: newer, posix: posix, sanitize: sanitize, defaultVersions: defaultVersions, findLatest: findLatest };
}
