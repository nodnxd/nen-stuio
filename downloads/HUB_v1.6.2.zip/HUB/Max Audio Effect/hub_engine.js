// HUB — engine (classic js, ES5)  v1.4
// 에이블톤이 직접 저장해둔 파일에서 Recent / Templates를 긁어오고, 선택한 세트를 연다.
//  - Recent   : ~/Library/Preferences/Ableton/Live x.y.z/Preferences.cfg (RecentDocs) + 이번 실행의 Log.txt
//  - Templates: User Library/Templates/*.als + Library.cfg의 DefaultTemplateSet
// 출력 outlet 0: "recent <enc>", "templates <enc>", "status <enc>"  (enc = encodeURIComponent(JSON)) → [s ---hub_data]
//      outlet 1: "open"     → pcontrol (플로팅 창 열기)
//      outlet 2: "showwin"  → 창 패치 (창 플래그 세팅)
//      outlet 3: "bang"     → [opendialog fold] (새 프로젝트 저장 폴더 고르기)
// 입력: init / rescan / openwin / openset / newfrom / revealset / openurl / chooseroot / setroot
// 새 세트(= 기본 템플릿 로드)로 시작하면 init 1.5초 뒤 창을 자동으로 띄운다.
autowatch = 1; inlets = 1; outlets = 4;

var PAT = this.patcher;
var MAXREC = 25;
var LIVE = null, TPLDIR = "", bootTask = null, frontTask = null, autoDone = false;
var VERSION = "1.6.0";
var ROOT = "", LISTED = [], metaTask = null, PENDING = "", settingsLoaded = false;

function log(s) { post("[HUB] " + s + "\n"); }
function status(s) { log(s); var e = encodeURIComponent(String(s)); if (typeof CACHE != "undefined") CACHE.status = e; outlet(0, "status", e); }
function posix(p) { return String(p || "").replace(/^[^\/]*:/, ""); }
function fexists(p) { try { var f = new File(p, "read"); var ok = f.isopen; f.close(); return !!ok; } catch (e) { return false; } }

function readBytes(p, tail) {
    try {
        var f = new File(p, "read");
        if (!f.isopen) return null;
        var total = f.eof, start = (tail && total > tail) ? total - tail : 0, n = total - start, out = new Array(n), k = 0, got, i;
        f.position = start;
        while (k < n) {
            got = f.readbytes(Math.min(16384, n - k));
            if (typeof got == "number") got = [got];
            if (!got || !got.length) break;
            for (i = 0; i < got.length; i++) out[k++] = got[i];
        }
        f.close();
        out.length = k;
        return out;
    } catch (e) { log("read ERR " + p + ": " + e); return null; }
}

function utf8(b) {
    var parts = [], i = 0, n = b.length, c, cp, chunk = [];
    while (i < n) {
        c = b[i++];
        if (c < 0x80) cp = c;
        else if (c >= 0xC0 && c < 0xE0 && i < n) cp = ((c & 0x1F) << 6) | (b[i++] & 0x3F);
        else if (c >= 0xE0 && c < 0xF0 && i + 1 < n) { cp = ((c & 0x0F) << 12) | ((b[i] & 0x3F) << 6) | (b[i + 1] & 0x3F); i += 2; }
        else if (c >= 0xF0 && i + 2 < n) { cp = ((c & 0x07) << 18) | ((b[i] & 0x3F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F); i += 3; }
        else cp = 0xFFFD;
        if (cp > 0xFFFF) { cp -= 0x10000; chunk.push(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)); }
        else chunk.push(cp);
        if (chunk.length >= 4096) { parts.push(String.fromCharCode.apply(null, chunk)); chunk = []; }
    }
    if (chunk.length) parts.push(String.fromCharCode.apply(null, chunk));
    return parts.join("");
}

function unxml(s) { return s.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&"); }

function modTime(f) {
    try { var m = f.moddate; if (m && m.length >= 6) return new Date(m[0], m[1] - 1, m[2], m[3], m[4], m[5]).getTime(); } catch (e) {}
    return 0;
}
function mtimeIn(dir, fname) {
    var t = 0;
    try { var f = new Folder(dir); while (!f.end) { if (f.filename == fname) { t = modTime(f); break; } f.next(); } f.close(); } catch (e) {}
    return t;
}
function listDirs(dir) {
    var out = [];
    try { var f = new Folder(dir); while (!f.end) { if (f.filetype == "fold") out.push(f.filename); f.next(); } f.close(); } catch (e) {}
    return out;
}
function scanDir(dir, depth, out) {
    var f = new Folder(dir);
    while (!f.end) {
        var name = f.filename;
        if (f.filetype == "fold") {
            if (depth > 0 && name.toLowerCase() != "backup") scanDir(dir + "/" + name, depth - 1, out);
        } else if (/\.als$/i.test(name)) {
            out.push(dir + "/" + name);
        }
        f.next();
    }
    f.close();
}

function findHome() {
    var m = posix(PAT.filepath).match(/^(\/Users\/[^\/]+)\//);
    if (m) return m[1];
    var c = [], d = listDirs("/Users");
    for (var i = 0; i < d.length; i++) if (d[i] != "Shared" && d[i] != "Guest" && d[i].charAt(0) != ".") c.push(d[i]);
    return c.length == 1 ? "/Users/" + c[0] : "";
}

// 지금 돌아가는(= Log.txt가 가장 최근인) 라이브 버전의 설정 폴더
function pickLive(home) {
    var base = home + "/Library/Preferences/Ableton", names = listDirs(base), best = null, bt = -1;
    for (var i = 0; i < names.length; i++) {
        if (!/^Live \d+(\.\d+)*$/.test(names[i])) continue;
        var d = base + "/" + names[i];
        var t = mtimeIn(d, "Log.txt") || mtimeIn(d, "Preferences.cfg");
        if (t > bt) { bt = t; best = { dir: d, name: names[i] }; }
    }
    return best;
}

// Preferences.cfg 안의 RecentDocsList 뒤 UTF-16LE 경로들 (저장 순서 = 최근 순). 필요한 개수만 모으고 멈춘다.
function prefsRecents(prefPath, want) {
    var b = readBytes(prefPath);
    if (!b) return [];
    var n = b.length, key = "RecentDocsList", base = 0, i, j, out = [], seen = {};
    for (i = 0; i + key.length <= n; i++) {
        if (b[i] != 82) continue; // 'R'
        for (j = 1; j < key.length; j++) if (b[i + j] != key.charCodeAt(j)) break;
        if (j == key.length) base = i;          // 마지막 RecentDocsList
    }
    for (i = base; i + 8 <= n && out.length < want; i++) {
        // ".als" = 2e 00 61 00 6c 00 73 00
        if (b[i] != 0x2e || b[i + 1] != 0 || b[i + 2] != 0x61 || b[i + 3] != 0 || b[i + 4] != 0x6c || b[i + 5] != 0 || b[i + 6] != 0x73 || b[i + 7] != 0) continue;
        var k = i, cu = [];
        while (k >= 2 && cu.length < 1024) {
            var c = b[k - 2] | (b[k - 1] << 8);
            if (c == 0) break;
            cu.push(c); k -= 2;
        }
        cu.reverse();
        var str = String.fromCharCode.apply(null, cu), sl = str.indexOf("/");
        if (sl >= 0) {
            str = str.substring(sl) + ".als";
            if (!seen[str]) { seen[str] = 1; out.push(str); }
        }
        i += 7;
    }
    return out;
}

// 이번 실행에서 연 세트 (새것 먼저)
var LOGTAIL = 131072;
function isAux(p) { return /\/User Library\/Defaults\//.test(p); }   // 트랙 생성 시 로드되는 Default Audio/MIDI Track.als
function logLoads(logPath) {
    var b = readBytes(logPath, LOGTAIL);
    if (!b) return [];
    var txt = utf8(b), re = /Loading document "([^"]+\.als)"/g, m, out = [];
    while ((m = re.exec(txt))) if (!isAux(m[1])) out.push(m[1]);
    out.reverse();
    LASTLOADS = out.slice(0);
    return out;
}

function uniq(list) {
    var seen = {}, out = [];
    for (var i = 0; i < list.length; i++) if (!seen[list[i]]) { seen[list[i]] = 1; out.push(list[i]); }
    return out;
}

var CACHE = {}, scannedAt = 0, LASTLOADS = null;
function send(sel, obj, listKey) {
    var s = encodeURIComponent(JSON.stringify(obj));
    var arr = listKey ? obj[listKey] : obj;
    while (s.length > 28000 && arr.length > 1) { arr.pop(); s = encodeURIComponent(JSON.stringify(obj)); }
    CACHE[sel] = s;
    outlet(0, sel, s);
}
function resend() {
    if (CACHE.templates) outlet(0, "templates", CACHE.templates);
    if (CACHE.recent) outlet(0, "recent", CACHE.recent);
    if (CACHE.root !== undefined) outlet(0, "root", CACHE.root);
    if (CACHE.meta) outlet(0, "meta", CACHE.meta);
    if (CACHE.status) outlet(0, "status", CACHE.status);
}

// ---------- 경로 도우미 ----------
function dirname(p) { return String(p).replace(/\/[^\/]*$/, ""); }
function basename(p) { return String(p).substring(String(p).lastIndexOf("/") + 1); }
function dirExists(d) { try { var f = new Folder(d); var ok = !f.end; f.close(); return ok; } catch (e) { return false; } }
// Max의 HFS 스타일 경로("Macintosh HD:/Users/.." / "NOD_4TB:/..")를 POSIX로. 부팅 디스크가 아니면 /Volumes/<이름>
var BOOTTOP = { Users: 1, Applications: 1, Library: 1, System: 1, Volumes: 1, "private": 1, opt: 1, usr: 1, tmp: 1 };
function hfsToPosix(p) {
    p = String(p || "");
    var m = p.match(/^([^:\/]+):(\/.*)$/);
    if (!m) return p;
    var top = m[2].split("/")[1];
    return BOOTTOP[top] ? m[2] : "/Volumes/" + m[1] + m[2];
}
function yymmdd() {
    var d = new Date(), z = function (n) { return (n < 10 ? "0" : "") + n; };
    return String(d.getFullYear()).slice(2) + z(d.getMonth() + 1) + z(d.getDate());
}

// ---------- 설정 (새 프로젝트 저장 폴더) : 디바이스 옆 hub_settings.txt 첫 줄 ----------
var USERLIB = "";
function settingsPath() { return (USERLIB || dirname(posix(PAT.filepath))) + "/hub_settings.txt"; }
function loadSettings() {
    if (settingsLoaded) return;
    settingsLoaded = true;
    try {
        var b = readBytes(settingsPath());
        if (b && b.length) ROOT = utf8(b).split(/[\r\n]/)[0].replace(/^\s+|\s+$/g, "");
    } catch (e) { log("settings read ERR " + e); }
}
function saveSettings() {
    try {
        var f = new File(settingsPath(), "write", "TEXT");
        if (f.isopen) { try { f.eof = 0; f.position = 0; } catch (e1) {} f.writestring(ROOT + "\n"); f.close(); }
        else log("settings not writable: " + settingsPath());
    } catch (e) { log("settings write ERR " + e); }
}
function sendRoot() { var e = encodeURIComponent(ROOT); CACHE.root = e; outlet(0, "root", e); }
function chooseroot() { outlet(3, "bang"); }
function setroot() {
    var raw = Array.prototype.slice.call(arguments).join(" ");
    if (!raw) return;                                // 대화상자 취소
    var p = hfsToPosix(raw).replace(/\/+$/, "");
    ROOT = p; saveSettings(); sendRoot();
    log("setroot raw=[" + raw + "] -> " + p);
    status("new projects -> " + p);
    if (PENDING) { var t = PENDING; PENDING = ""; newfrom(encodeURIComponent(t)); }
}

// ---------- 날짜 / 외장 디스크 상태 (리스트를 먼저 보낸 뒤 따로 계산해서 보낸다) ----------
function listMtimes(d) {
    var out = {};
    try { var f = new Folder(d); while (!f.end) { if (/\.als$/i.test(f.filename)) out[f.filename] = modTime(f); f.next(); } f.close(); } catch (e) {}
    return out;
}
function computeMeta() {
    try {
        var res = {}, dirs = {}, mounted = {}, i, p, off, t, d, root;
        for (i = 0; i < LISTED.length; i++) {
            p = LISTED[i]; off = false; t = 0;
            if (p.indexOf("/Volumes/") == 0) {
                root = p.split("/").slice(0, 3).join("/");
                if (mounted[root] === undefined) mounted[root] = dirExists(root);
                off = !mounted[root];
            }
            if (!off) { d = dirname(p); if (!dirs[d]) dirs[d] = listMtimes(d); t = dirs[d][basename(p)] || 0; }
            res[p] = [t, off ? 1 : 0];
        }
        send("meta", res, null);
    } catch (e) { log("meta ERR " + e); }
}

// 저장해 둔 폴더가 없으면: 가장 최근 프로젝트가 들어 있는 폴더의 상위 폴더를 기본값으로 (창에서 CHANGE로 바꾸면 그걸 저장)
function autoRoot(rec) {
    for (var i = 0; i < rec.length; i++) {
        var d = dirname(rec[i]);
        if (/ Project(-\d+)?$/.test(basename(d)) || basename(d) == "Project") d = dirname(d);
        if (!d || /\/Backup(\/|$)/.test(d)) continue;
        if (rec[i].indexOf("/Volumes/") == 0 && !dirExists(rec[i].split("/").slice(0, 3).join("/"))) continue;
        if (dirExists(d)) return d;
    }
    return "";
}

// ---------- 템플릿 → 새 프로젝트 (복사본을 만들어서 연다. 원본은 건드리지 않음) ----------
function newfrom(enc) {
    var src;
    try { src = decodeURIComponent(String(enc)); } catch (e) { status("bad path"); return; }
    if (!fexists(src)) { status("template not found"); return; }
    loadSettings();
    if (!ROOT) { PENDING = src; status("choose a folder for new projects"); chooseroot(); return; }
    var base = basename(src).replace(/\.als$/i, ""), name = base + " " + yymmdd(), dest = ROOT + "/" + name + ".als", n = 2;
    while (fexists(dest) && n < 100) { dest = ROOT + "/" + name + " " + n + ".als"; n++; }
    var data = readBytes(src);
    if (!data || !data.length) { status("could not read template"); return; }
    try {
        var f = new File(dest, "write", "TEXT");
        if (!f.isopen) { status("cannot write: " + dest); return; }
        for (var i = 0; i < data.length; i += 16384) f.writebytes(data.slice(i, i + 16384));
        f.close();
    } catch (e) { status("copy failed: " + e); return; }
    var chk = null;
    try { chk = new File(dest, "read"); var sz = chk.isopen ? chk.eof : -1; chk.close(); if (sz !== data.length) { status("copy failed (size " + sz + " of " + data.length + ")"); return; } }
    catch (e2) { status("copy check failed: " + e2); return; }
    log("new project: " + dest);
    openset(encodeURIComponent(dest));
}

// ---------- Finder에서 보기 ----------
function revealset(enc) {
    var p;
    try { p = decodeURIComponent(String(enc)); } catch (e) { return; }
    var d = dirname(p);
    if (!dirExists(d)) { status("folder not found (disk offline?)"); return; }
    try { max.launchbrowser(toFileUrl(d)); } catch (e2) { status("reveal failed: " + e2); }
}

function scan() {
    var home = findHome();
    if (!home) { status("home folder not found"); return; }
    var live = pickLive(home);
    LIVE = live;
    var def = "", userLib = "";
    if (live) {
        var lb = readBytes(live.dir + "/Library.cfg");
        if (lb) { var mm = utf8(lb).match(/<DefaultTemplateSet Value="([^"]*)"/); if (mm) def = unxml(mm[1]); }
    }
    var ul = def.match(/^(.*\/User Library)\//);
    if (ul) userLib = ul[1];
    else { var pm = posix(PAT.filepath).match(/^(.*\/User Library)\//); userLib = pm ? pm[1] : home + "/Music/Ableton/User Library"; }
    USERLIB = userLib; settingsLoaded = false; loadSettings();
    var tplDir = userLib + "/Templates";
    TPLDIR = tplDir;

    // templates
    var tpls = [];
    try { scanDir(tplDir, 2, tpls); } catch (e) { log("templates scan ERR " + e); }
    tpls = uniq(tpls).filter(function (p) { return p != def; });
    tpls.sort(function (a, b) { return a.toLowerCase() < b.toLowerCase() ? -1 : 1; });
    var defOk = def && fexists(def) ? def : "";
    send("templates", { def: defOk, list: tpls }, "list");

    // recent
    var rec = [];
    if (live) {
        LASTLOADS = null;
        rec = logLoads(live.dir + "/Log.txt").concat(prefsRecents(live.dir + "/Preferences.cfg", MAXREC * 3));
    }
    rec = uniq(rec).filter(function (p) {
        if (p.indexOf(tplDir + "/") == 0) return false;
        if (/\/Backup\//.test(p)) return false;
        if (isAux(p)) return false;
        if (p.indexOf("/Volumes/") == 0) return true;
        return fexists(p);
    }).slice(0, MAXREC);
    send("recent", rec, "");
    LISTED = rec.concat(tpls, defOk ? [defOk] : []);
    if (!ROOT) { ROOT = autoRoot(rec); if (ROOT) log("default new-project folder: " + ROOT); }
    sendRoot();
    if (!metaTask) metaTask = new Task(computeMeta, this);
    metaTask.schedule(80);

    status("v" + VERSION + " · " + rec.length + " recent · " + (tpls.length + (defOk ? 1 : 0)) + " templates" + (live ? " · " + live.name : " · live prefs not found"));
}

function init() {
    if (scannedAt) { resend(); return; }           // UI가 늦게 붙어도 다시 스캔하지 않음
    rescan();
    if (!bootTask) { bootTask = new Task(autoopen, this); bootTask.schedule(1200); }
}
function rescan() {
    var t0 = new Date().getTime();
    try { scan(); } catch (e) { status("scan error: " + e); }
    scannedAt = new Date().getTime();
    log("scan " + (scannedAt - t0) + " ms");
}

// 방금 로드된 세트가 기본 템플릿/템플릿에서 시작한 새 세트인가? (Log.txt의 마지막 "Loading document")
// 판단 불가면 true (= 창을 띄우는 쪽으로)
function isNewSet() {
    try {
        if (!LIVE) return true;
        var loads = LASTLOADS || logLoads(LIVE.dir + "/Log.txt");
        if (!loads.length) return true;
        var last = loads[0];
        return (TPLDIR && last.indexOf(TPLDIR + "/") == 0) || /\/Templates\/[^\/]*\.als$/i.test(last);
    } catch (e) { return true; }
}
function autoopen() {
    if (autoDone) return;
    autoDone = true;
    if (isNewSet()) {
        log("new set -> opening HUB window"); openwin();
        frontTask = new Task(function () { outlet(2, "showwin"); }, this); frontTask.schedule(3000);
    }
    else log("existing set -> window stays closed");
}
function openwin() {
    outlet(2, "showwin");
    outlet(1, "open");
    if (!scannedAt || new Date().getTime() - scannedAt > 30000) rescan(); else resend();
}

function toFileUrl(p) {
    var segs = p.split("/");
    for (var i = 0; i < segs.length; i++) segs[i] = encodeURIComponent(segs[i]);
    return "file://" + segs.join("/");
}
function openset(enc) {
    var p;
    try { p = decodeURIComponent(String(enc)); } catch (e) { status("bad path"); return; }
    if (!fexists(p)) { status("not found: " + p); return; }
    try { max.launchbrowser(toFileUrl(p)); status("opening " + p.substring(p.lastIndexOf("/") + 1)); }
    catch (e) { status("open failed: " + e); }
}
// 포털 링크: https만 허용, 기본 브라우저로 연다
function openurl(enc) {
    var u;
    try { u = decodeURIComponent(String(enc)); } catch (e) { return; }
    if (!/^https:\/\/[^\s]+$/i.test(u)) { log("blocked url: " + u); return; }
    try { max.launchbrowser(u); } catch (e) { log("openurl failed: " + e); }
}
function bang() { rescan(); }
